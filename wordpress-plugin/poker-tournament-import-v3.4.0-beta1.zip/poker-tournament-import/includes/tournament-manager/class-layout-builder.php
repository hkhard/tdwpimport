<?php
/**
 * TD3 Integration: Layout Builder
 *
 * Handles drag-and-drop layout configurations for tournament displays.
 * Provides CSS Grid generation, component positioning, and responsive design.
 *
 * @package Poker_Tournament_Import
 * @subpackage Tournament_Manager
 * @since 3.4.0
 */

// Prevent direct file access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Layout Builder Class
 *
 * Manages drag-and-drop layout configurations for tournament displays.
 * Handles CSS Grid generation, component positioning, responsive breakpoints,
 * and layout validation for various screen sizes.
 *
 * @since 3.4.0
 */
class TDWP_Layout_Builder {

	/**
	 * Singleton instance
	 *
	 * @var TDWP_Layout_Builder|null
	 */
	private static $instance = null;

	/**
	 * Default grid configuration
	 *
	 * @var array
	 */
	private $default_grid_config = array(
		'columns' => 12,
		'rows' => 8,
		'gap' => '1rem',
		'padding' => '1rem',
	);

	/**
	 * Available breakpoints
	 *
	 * @var array
	 */
	private $breakpoints = array(
		'small' => array(
			'max_width' => '768px',
			'columns' => 6,
			'rows' => 12,
		),
		'medium' => array(
			'max_width' => '1024px',
			'columns' => 8,
			'rows' => 10,
		),
		'large' => array(
			'max_width' => '1440px',
			'columns' => 12,
			'rows' => 8,
		),
		'xlarge' => array(
			'max_width' => 'none',
			'columns' => 16,
			'rows' => 6,
		),
	);

	/**
	 * Available components
	 *
	 * @var array
	 */
	private $available_components = array(
		'tournament_name' => array(
			'name' => 'Tournament Name',
			'default_size' => array( 'width' => 6, 'height' => 1 ),
			'resizable' => true,
		),
		'clock_display' => array(
			'name' => 'Clock Display',
			'default_size' => array( 'width' => 4, 'height' => 2 ),
			'resizable' => true,
		),
		'current_blinds' => array(
			'name' => 'Current Blinds',
			'default_size' => array( 'width' => 3, 'height' => 1 ),
			'resizable' => true,
		),
		'time_remaining' => array(
			'name' => 'Time Remaining',
			'default_size' => array( 'width' => 3, 'height' => 1 ),
			'resizable' => true,
		),
		'player_count' => array(
			'name' => 'Player Count',
			'default_size' => array( 'width' => 2, 'height' => 1 ),
			'resizable' => true,
		),
		'prize_pool' => array(
			'name' => 'Prize Pool',
			'default_size' => array( 'width' => 4, 'height' => 1 ),
			'resizable' => true,
		),
		'rankings' => array(
			'name' => 'Rankings',
			'default_size' => array( 'width' => 6, 'height' => 4 ),
			'resizable' => true,
		),
		'seating_chart' => array(
			'name' => 'Seating Chart',
			'default_size' => array( 'width' => 8, 'height' => 6 ),
			'resizable' => true,
		),
		'next_blinds' => array(
			'name' => 'Next Blinds',
			'default_size' => array( 'width' => 3, 'height' => 1 ),
			'resizable' => true,
		),
		'custom_content' => array(
			'name' => 'Custom Content',
			'default_size' => array( 'width' => 4, 'height' => 2 ),
			'resizable' => true,
		),
	);

	/**
	 * Get singleton instance
	 *
	 * @since 3.4.0
	 * @return TDWP_Layout_Builder
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 *
	 * @since 3.4.0
	 */
	private function __construct() {
		// Initialize hooks and filters
		add_action( 'wp_ajax_tdwp_save_layout', array( $this, 'ajax_save_layout' ) );
		add_action( 'wp_ajax_tdwp_get_layout', array( $this, 'ajax_get_layout' ) );
		add_action( 'wp_ajax_tdwp_get_components', array( $this, 'ajax_get_components' ) );
		add_action( 'wp_ajax_tdwp_validate_layout', array( $this, 'ajax_validate_layout' ) );
	}

	/**
	 * Apply layout to content
	 *
	 * @since 3.4.0
	 * @param string $content Original content.
	 * @param array  $grid_config Grid configuration.
	 * @param array  $component_positions Component positions.
	 * @return string Layout-applied content.
	 */
	public function apply_layout( $content, $grid_config, $component_positions ) {
		$grid_config = wp_parse_args( $grid_config, $this->default_grid_config );

		// Generate CSS
		$css = $this->generate_css( $grid_config, $component_positions );

		// Wrap content in grid container
		$layout_html = '<div class="tdwp-layout-container" data-layout-id="' . esc_attr( uniqid() ) . '">';
		$layout_html .= '<style>' . $css . '</style>';
		$layout_html .= '<div class="tdwp-grid">' . $content . '</div>';
		$layout_html .= '</div>';

		return $layout_html;
	}

	/**
	 * Generate CSS for layout
	 *
	 * @since 3.4.0
	 * @param array $grid_config Grid configuration.
	 * @param array $component_positions Component positions.
	 * @return string Generated CSS.
	 */
	private function generate_css( $grid_config, $component_positions ) {
		$css = '.tdwp-grid {';
		$css .= 'display: grid;';
		$css .= 'grid-template-columns: repeat(' . $grid_config['columns'] . ', 1fr);';
		$css .= 'grid-template-rows: repeat(' . $grid_config['rows'] . ', minmax(60px, 1fr));';
		$css .= 'gap: ' . $grid_config['gap'] . ';';
		$css .= 'padding: ' . $grid_config['padding'] . ';';
		$css .= 'width: 100%;';
		$css .= 'height: 100vh;';
		$css .= '}';

		// Generate responsive styles
		$css .= $this->generate_responsive_css( $grid_config );

		// Generate component positioning styles
		if ( ! empty( $component_positions ) ) {
			$css .= $this->generate_component_css( $component_positions );
		}

		return $css;
	}

	/**
	 * Generate responsive CSS
	 *
	 * @since 3.4.0
	 * @param array $grid_config Grid configuration.
	 * @return string Responsive CSS.
	 */
	private function generate_responsive_css( $grid_config ) {
		$css = '';

		foreach ( $this->breakpoints as $breakpoint_name => $breakpoint_config ) {
			if ( $breakpoint_config['max_width'] !== 'none' ) {
				$css .= '@media (max-width: ' . $breakpoint_config['max_width'] . ') {';
				$css .= '.tdwp-grid {';
				$css .= 'grid-template-columns: repeat(' . $breakpoint_config['columns'] . ', 1fr);';
				$css .= 'grid-template-rows: repeat(' . $breakpoint_config['rows'] . ', minmax(60px, 1fr));';
				$css .= '}';
				$css .= '}';
			}
		}

		return $css;
	}

	/**
	 * Generate component positioning CSS
	 *
	 * @since 3.4.0
	 * @param array $component_positions Component positions.
	 * @return string Component CSS.
	 */
	private function generate_component_css( $component_positions ) {
		$css = '';

		foreach ( $component_positions as $component_id => $position ) {
			$css .= '.tdwp-component-' . $component_id . ' {';
			$css .= 'grid-column: ' . $position['column_start'] . ' / ' . ($position['column_start'] + $position['width']) . ';';
			$css .= 'grid-row: ' . $position['row_start'] . ' / ' . ($position['row_start'] + $position['height']) . ';';

			if ( isset( $position['z_index'] ) ) {
				$css .= 'z-index: ' . $position['z_index'] . ';';
			}

			$css .= '}';
		}

		return $css;
	}

	/**
	 * Validate layout configuration
	 *
	 * @since 3.4.0
	 * @param array $layout_config Layout configuration.
	 * @return array Validation result.
	 */
	public function validate_layout( $layout_config ) {
		$errors = array();
		$warnings = array();

		// Validate grid config
		if ( isset( $layout_config['grid_config'] ) ) {
			$grid_config = $layout_config['grid_config'];

			if ( ! isset( $grid_config['columns'] ) || $grid_config['columns'] < 1 || $grid_config['columns'] > 24 ) {
				$errors[] = 'Invalid column count. Must be between 1 and 24.';
			}

			if ( ! isset( $grid_config['rows'] ) || $grid_config['rows'] < 1 || $grid_config['rows'] > 20 ) {
				$errors[] = 'Invalid row count. Must be between 1 and 20.';
			}

			if ( isset( $grid_config['gap'] ) && ! $this->is_valid_css_size( $grid_config['gap'] ) ) {
				$errors[] = 'Invalid gap value. Must be a valid CSS size value.';
			}
		}

		// Validate component positions
		if ( isset( $layout_config['component_positions'] ) ) {
			$component_positions = $layout_config['component_positions'];
			$grid_columns = $layout_config['grid_config']['columns'] ?? 12;
			$grid_rows = $layout_config['grid_config']['rows'] ?? 8;

			foreach ( $component_positions as $component_id => $position ) {
				$component_errors = $this->validate_component_position( $position, $grid_columns, $grid_rows );

				if ( ! empty( $component_errors ) ) {
					$errors = array_merge( $errors, $component_errors );
				}
			}
		}

		// Check for overlapping components
		if ( ! empty( $layout_config['component_positions'] ) ) {
			$overlaps = $this->check_component_overlaps( $layout_config['component_positions'] );

			if ( ! empty( $overlaps ) ) {
				$warnings[] = 'Some components overlap: ' . implode( ', ', $overlaps );
			}
		}

		return array(
			'is_valid' => empty( $errors ),
			'errors' => $errors,
			'warnings' => $warnings,
		);
	}

	/**
	 * Validate component position
	 *
	 * @since 3.4.0
	 * @param array $position Component position.
	 * @param int   $max_columns Maximum columns.
	 * @param int   $max_rows Maximum rows.
	 * @return array Validation errors.
	 */
	private function validate_component_position( $position, $max_columns, $max_rows ) {
		$errors = array();

		// Check required fields
		$required_fields = array( 'column_start', 'row_start', 'width', 'height' );

		foreach ( $required_fields as $field ) {
			if ( ! isset( $position[ $field ] ) || ! is_numeric( $position[ $field ] ) ) {
				$errors[] = "Missing or invalid field: {$field}";
			}
		}

		if ( ! empty( $errors ) ) {
			return $errors;
		}

		// Check bounds
		if ( $position['column_start'] < 1 || $position['column_start'] > $max_columns ) {
			$errors[] = 'Column start out of bounds.';
		}

		if ( $position['row_start'] < 1 || $position['row_start'] > $max_rows ) {
			$errors[] = 'Row start out of bounds.';
		}

		if ( $position['width'] < 1 || ($position['column_start'] + $position['width'] - 1) > $max_columns ) {
			$errors[] = 'Component width out of bounds.';
		}

		if ( $position['height'] < 1 || ($position['row_start'] + $position['height'] - 1) > $max_rows ) {
			$errors[] = 'Component height out of bounds.';
		}

		return $errors;
	}

	/**
	 * Check for overlapping components
	 *
	 * @since 3.4.0
	 * @param array $component_positions Component positions.
	 * @return array Overlapping component IDs.
	 */
	private function check_component_overlaps( $component_positions ) {
		$overlaps = array();
		$occupied = array();

		foreach ( $component_positions as $component_id => $position ) {
			for ( $row = $position['row_start']; $row < $position['row_start'] + $position['height']; $row++ ) {
				for ( $col = $position['column_start']; $col < $position['column_start'] + $position['width']; $col++ ) {
					$cell_key = $row . '-' . $col;

					if ( isset( $occupied[ $cell_key ] ) ) {
						$overlaps[] = $component_id . ' overlaps with ' . $occupied[ $cell_key ];
					} else {
						$occupied[ $cell_key ] = $component_id;
					}
				}
			}
		}

		return $overlaps;
	}

	/**
	 * Validate CSS size value
	 *
	 * @since 3.4.0
	 * @param string $value CSS value.
	 * @return bool Valid status.
	 */
	private function is_valid_css_size( $value ) {
		// Basic validation for common CSS size values
		return preg_match( '/^(0|auto|inherit|initial|unset|\d+(\.\d+)?(px|em|rem|%|vh|vw|cm|mm|in|pt|pc|ex|ch|vmin|vmax)|calc\(.*\))$/', $value );
	}

	/**
	 * Get available components
	 *
	 * @since 3.4.0
	 * @return array Available components.
	 */
	public function get_available_components() {
		return $this->available_components;
	}

	/**
	 * Get breakpoints
	 *
	 * @since 3.4.0
	 * @return array Available breakpoints.
	 */
	public function get_breakpoints() {
		return $this->breakpoints;
	}

	/**
	 * Get default grid configuration
	 *
	 * @since 3.4.0
	 * @return array Default grid configuration.
	 */
	public function get_default_grid_config() {
		return $this->default_grid_config;
	}

	/**
	 * AJAX handler for saving layout
	 *
	 * @since 3.4.0
	 */
	public function ajax_save_layout() {
		// Verify nonce and capabilities
		if ( ! check_ajax_referer( 'tdwp_layout_nonce', 'nonce' ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Security check failed' );
		}

		$layout_data = json_decode( stripslashes( $_POST['layout_data'] ), true );

		if ( ! $layout_data ) {
			wp_send_json_error( 'Invalid layout data' );
		}

		// Validate layout
		$validation = $this->validate_layout( $layout_data );

		if ( ! $validation['is_valid'] ) {
			wp_send_json_error( array( 'validation_errors' => $validation['errors'] ) );
		}

		// Save layout
		global $wpdb;

		$result = $wpdb->insert(
			$wpdb->prefix . 'poker_display_layouts',
			array(
				'tournament_id' => intval( $layout_data['tournament_id'] ),
				'layout_name' => sanitize_text_field( $layout_data['layout_name'] ),
				'screen_size' => sanitize_text_field( $layout_data['screen_size'] ?? '' ),
				'grid_config' => json_encode( $layout_data['grid_config'] ),
				'component_positions' => json_encode( $layout_data['component_positions'] ),
				'breakpoints' => json_encode( $layout_data['breakpoints'] ?? array() ),
				'is_active' => isset( $layout_data['is_active'] ) ? (bool) $layout_data['is_active'] : true,
			),
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%d' )
		);

		if ( $result ) {
			wp_send_json_success( array(
				'layout_id' => $wpdb->insert_id,
				'validation_warnings' => $validation['warnings'],
			) );
		} else {
			wp_send_json_error( 'Failed to save layout' );
		}
	}

	/**
	 * AJAX handler for getting layout
	 *
	 * @since 3.4.0
	 */
	public function ajax_get_layout() {
		// Verify nonce and capabilities
		if ( ! check_ajax_referer( 'tdwp_layout_nonce', 'nonce' ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Security check failed' );
		}

		$layout_id = isset( $_GET['layout_id'] ) ? intval( $_GET['layout_id'] ) : 0;

		if ( $layout_id <= 0 ) {
			wp_send_json_error( 'Invalid layout ID' );
		}

		global $wpdb;

		$layout = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}poker_display_layouts WHERE layout_id = %d",
			$layout_id
		) );

		if ( ! $layout ) {
			wp_send_json_error( 'Layout not found' );
		}

		// Decode JSON fields
		$layout->grid_config = json_decode( $layout->grid_config, true );
		$layout->component_positions = json_decode( $layout->component_positions, true );
		$layout->breakpoints = json_decode( $layout->breakpoints, true );

		wp_send_json_success( $layout );
	}

	/**
	 * AJAX handler for getting components
	 *
	 * @since 3.4.0
	 */
	public function ajax_get_components() {
		// Verify nonce and capabilities
		if ( ! check_ajax_referer( 'tdwp_layout_nonce', 'nonce' ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Security check failed' );
		}

		wp_send_json_success( $this->get_available_components() );
	}

	/**
	 * AJAX handler for validating layout
	 *
	 * @since 3.4.0
	 */
	public function ajax_validate_layout() {
		// Verify nonce and capabilities
		if ( ! check_ajax_referer( 'tdwp_layout_nonce', 'nonce' ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Security check failed' );
		}

		$layout_data = json_decode( stripslashes( $_POST['layout_data'] ), true );

		if ( ! $layout_data ) {
			wp_send_json_error( 'Invalid layout data' );
		}

		$validation = $this->validate_layout( $layout_data );

		wp_send_json_success( $validation );
	}
}