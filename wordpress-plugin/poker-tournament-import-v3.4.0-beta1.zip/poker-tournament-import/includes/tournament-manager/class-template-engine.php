<?php
/**
 * TD3 Integration: Template Engine
 *
 * Extends existing formula tokenizer for {{token}} pattern recognition and rendering.
 * Handles dynamic content replacement in tournament display templates.
 *
 * @package Poker_Tournament_Import
 * @subpackage Tournament_Manager
 * @since 3.4.0
 */

// Prevent direct file access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Template Engine Class
 *
 * Extends the existing formula tokenizer to support {{token}} patterns for
 * dynamic tournament display content. Integrates with WordPress template system
 * and provides caching for performance optimization.
 *
 * @since 3.4.0
 */
class TDWP_Template_Engine {

	/**
	 * Singleton instance
	 *
	 * @var TDWP_Template_Engine|null
	 */
	private static $instance = null;

	/**
	 * Token registry
	 *
	 * @var array
	 */
	private $token_registry = array();

	/**
	 * Cache expiration time in seconds
	 *
	 * @var int
	 */
	private $cache_expiry = 300; // 5 minutes

	/**
	 * Get singleton instance
	 *
	 * @since 3.4.0
	 * @return TDWP_Template_Engine
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 *
	 * @since 3.4.0
	 */
	private function __construct() {
		$this->init_token_registry();
	}

	/**
	 * Initialize token registry
	 *
	 * @since 3.4.0
	 */
	private function init_token_registry() {
		global $wpdb;

		// Load tokens from database
		$db_tokens = $wpdb->get_results(
			"SELECT * FROM {$wpdb->prefix}poker_display_tokens WHERE is_active = 1 ORDER BY token_name"
		);

		foreach ( $db_tokens as $token ) {
			$this->token_registry[ $token->token_name ] = array(
				'description' => $token->token_description,
				'type' => $token->token_type,
				'data_source' => $token->data_source,
				'default_format' => $token->default_format,
			);
		}

		// Add built-in tokens if not in database
		$this->add_builtin_tokens();
	}

	/**
	 * Add built-in tokens
	 *
	 * @since 3.4.0
	 */
	private function add_builtin_tokens() {
		$builtin_tokens = array(
			'tournament_name' => array(
				'description' => 'Tournament name',
				'type' => 'tournament',
				'data_source' => 'get_tournament_name',
				'default_format' => '%s',
			),
			'current_blind' => array(
				'description' => 'Current blind level',
				'type' => 'blind',
				'data_source' => 'get_current_blind',
				'default_format' => '%s',
			),
			'next_blind' => array(
				'description' => 'Next blind level',
				'type' => 'blind',
				'data_source' => 'get_next_blind',
				'default_format' => '%s',
			),
			'time_remaining' => array(
				'description' => 'Time remaining in current level',
				'type' => 'time',
				'data_source' => 'get_time_remaining',
				'default_format' => '%s',
			),
			'players_remaining' => array(
				'description' => 'Number of players still in tournament',
				'type' => 'player',
				'data_source' => 'get_players_remaining',
				'default_format' => '%d',
			),
			'prize_pool' => array(
				'description' => 'Total prize pool',
				'type' => 'prize',
				'data_source' => 'get_prize_pool',
				'default_format' => '$%.2f',
			),
			'current_level' => array(
				'description' => 'Current blind level number',
				'type' => 'blind',
				'data_source' => 'get_current_level',
				'default_format' => '%d',
			),
			'total_levels' => array(
				'description' => 'Total number of blind levels',
				'type' => 'blind',
				'data_source' => 'get_total_levels',
				'default_format' => '%d',
			),
			'entries_count' => array(
				'description' => 'Total number of entries',
				'type' => 'player',
				'data_source' => 'get_entries_count',
				'default_format' => '%d',
			),
			'clock_status' => array(
				'description' => 'Clock status (running/paused/stopped)',
				'type' => 'time',
				'data_source' => 'get_clock_status',
				'default_format' => '%s',
			),
		);

		foreach ( $builtin_tokens as $token_name => $token_data ) {
			if ( ! isset( $this->token_registry[ $token_name ] ) ) {
				$this->token_registry[ $token_name ] = $token_data;
			}
		}
	}

	/**
	 * Render template with token replacement
	 *
	 * @since 3.4.0
	 * @param string $template Template content with {{tokens}}.
	 * @param int    $tournament_id Tournament ID.
	 * @return string Rendered content.
	 */
	public function render_template( $template, $tournament_id ) {
		// Check cache first
		$cache_key = "tdwp_template_{$tournament_id}_" . md5( $template );
		$cached_content = get_transient( $cache_key );

		if ( false !== $cached_content ) {
			return $cached_content;
		}

		// Find all tokens in template
		$tokens = $this->find_tokens( $template );

		if ( empty( $tokens ) ) {
			return $template;
		}

		// Replace tokens with actual values
		$rendered_content = $template;
		$token_values = $this->get_token_values( $tokens, $tournament_id );

		foreach ( $token_values as $token => $value ) {
			$rendered_content = str_replace( '{{' . $token . '}}', $value, $rendered_content );
		}

		// Cache the result
		set_transient( $cache_key, $rendered_content, $this->cache_expiry );

		return $rendered_content;
	}

	/**
	 * Find tokens in template
	 *
	 * @since 3.4.0
	 * @param string $template Template content.
	 * @return array Found tokens.
	 */
	private function find_tokens( $template ) {
		$tokens = array();

		// Match {{token_name}} pattern
		if ( preg_match_all( '/\{\{([a-zA-Z_][a-zA-Z0-9_]*)\}\}/', $template, $matches ) ) {
			$tokens = array_unique( $matches[1] );
		}

		return $tokens;
	}

	/**
	 * Get token values
	 *
	 * @since 3.4.0
	 * @param array $tokens Token names.
	 * @param int   $tournament_id Tournament ID.
	 * @return array Token values.
	 */
	private function get_token_values( $tokens, $tournament_id ) {
		$values = array();

		foreach ( $tokens as $token ) {
			if ( ! isset( $this->token_registry[ $token ] ) ) {
				continue;
			}

			$token_config = $this->token_registry[ $token ];
			$method_name = $token_config['data_source'];

			if ( method_exists( $this, $method_name ) ) {
				$value = $this->$method_name( $tournament_id );
				$values[ $token ] = $this->format_token_value( $value, $token_config['default_format'] );
			} else {
				$values[ $token ] = '[Unknown token: ' . $token . ']';
			}
		}

		return $values;
	}

	/**
	 * Format token value
	 *
	 * @since 3.4.0
	 * @param mixed  $value Raw value.
	 * @param string $format Format string.
	 * @return string Formatted value.
	 */
	private function format_token_value( $value, $format ) {
		if ( null === $value ) {
			return 'N/A';
		}

		if ( false === $value ) {
			return 'No';
		}

		if ( true === $value ) {
			return 'Yes';
		}

		// Use sprintf for formatting
		if ( ! empty( $format ) && is_string( $value ) || is_numeric( $value ) ) {
			return sprintf( $format, $value );
		}

		return (string) $value;
	}

	/**
	 * Get tournament name
	 *
	 * @since 3.4.0
	 * @param int $tournament_id Tournament ID.
	 * @return string Tournament name.
	 */
	private function get_tournament_name( $tournament_id ) {
		$post = get_post( $tournament_id );
		return $post ? $post->post_title : 'Unknown Tournament';
	}

	/**
	 * Get current blind level
	 *
	 * @since 3.4.0
	 * @param int $tournament_id Tournament ID.
	 * @return string Current blind level.
	 */
	private function get_current_blind( $tournament_id ) {
		if ( class_exists( 'TDWP_Tournament_Live' ) ) {
			$live_state = TDWP_Tournament_Live::get_instance( $tournament_id );
			$current_level = $live_state->get_current_level();
			return $current_level ? $current_level->get_blind_string() : 'Not started';
		}
		return 'Not available';
	}

	/**
	 * Get next blind level
	 *
	 * @since 3.4.0
	 * @param int $tournament_id Tournament ID.
	 * @return string Next blind level.
	 */
	private function get_next_blind( $tournament_id ) {
		if ( class_exists( 'TDWP_Tournament_Live' ) ) {
			$live_state = TDWP_Tournament_Live::get_instance( $tournament_id );
			$next_level = $live_state->get_next_level();
			return $next_level ? $next_level->get_blind_string() : 'Final level';
		}
		return 'Not available';
	}

	/**
	 * Get time remaining in current level
	 *
	 * @since 3.4.0
	 * @param int $tournament_id Tournament ID.
	 * @return string Time remaining.
	 */
	private function get_time_remaining( $tournament_id ) {
		if ( class_exists( 'TDWP_Tournament_Live' ) ) {
			$live_state = TDWP_Tournament_Live::get_instance( $tournament_id );
			$time_remaining = $live_state->get_time_remaining();
			return $time_remaining ? $this->format_time( $time_remaining ) : 'N/A';
		}
		return 'Not available';
	}

	/**
	 * Get players remaining
	 *
	 * @since 3.4.0
	 * @param int $tournament_id Tournament ID.
	 * @return int Number of players remaining.
	 */
	private function get_players_remaining( $tournament_id ) {
		if ( class_exists( 'TDWP_Tournament_Player_Manager' ) ) {
			$player_manager = TDWP_Tournament_Player_Manager::get_instance();
			return $player_manager->get_active_players_count( $tournament_id );
		}
		return 0;
	}

	/**
	 * Get prize pool
	 *
	 * @since 3.4.0
	 * @param int $tournament_id Tournament ID.
	 * @return float Prize pool amount.
	 */
	private function get_prize_pool( $tournament_id ) {
		if ( class_exists( 'TDWP_Tournament_Player_Manager' ) ) {
			$player_manager = TDWP_Tournament_Player_Manager::get_instance();
			return $player_manager->calculate_prize_pool( $tournament_id );
		}
		return 0.0;
	}

	/**
	 * Get current level number
	 *
	 * @since 3.4.0
	 * @param int $tournament_id Tournament ID.
	 * @return int Current level number.
	 */
	private function get_current_level( $tournament_id ) {
		if ( class_exists( 'TDWP_Tournament_Live' ) ) {
			$live_state = TDWP_Tournament_Live::get_instance( $tournament_id );
			return $live_state->get_current_level_number();
		}
		return 0;
	}

	/**
	 * Get total levels
	 *
	 * @since 3.4.0
	 * @param int $tournament_id Tournament ID.
	 * @return int Total number of levels.
	 */
	private function get_total_levels( $tournament_id ) {
		if ( class_exists( 'TDWP_Blind_Schedule' ) ) {
			$schedule = TDWP_Blind_Schedule::get_tournament_schedule( $tournament_id );
			return $schedule ? $schedule->get_level_count() : 0;
		}
		return 0;
	}

	/**
	 * Get entries count
	 *
	 * @since 3.4.0
	 * @param int $tournament_id Tournament ID.
	 * @return int Total entries count.
	 */
	private function get_entries_count( $tournament_id ) {
		if ( class_exists( 'TDWP_Tournament_Player_Manager' ) ) {
			$player_manager = TDWP_Tournament_Player_Manager::get_instance();
			return $player_manager->get_total_entries_count( $tournament_id );
		}
		return 0;
	}

	/**
	 * Get clock status
	 *
	 * @since 3.4.0
	 * @param int $tournament_id Tournament ID.
	 * @return string Clock status.
	 */
	private function get_clock_status( $tournament_id ) {
		if ( class_exists( 'TDWP_Tournament_Live' ) ) {
			$live_state = TDWP_Tournament_Live::get_instance( $tournament_id );
			return $live_state->get_clock_status();
		}
		return 'Not available';
	}

	/**
	 * Format time display
	 *
	 * @since 3.4.0
	 * @param int $seconds Time in seconds.
	 * @return string Formatted time (MM:SS).
	 */
	private function format_time( $seconds ) {
		if ( $seconds < 0 ) {
			return '00:00';
		}

		$minutes = floor( $seconds / 60 );
		$remaining_seconds = $seconds % 60;

		return sprintf( '%02d:%02d', $minutes, $remaining_seconds );
	}

	/**
	 * Validate template
	 *
	 * @since 3.4.0
	 * @param string $template Template content.
	 * @return array Validation result.
	 */
	public function validate_template( $template ) {
		$tokens = $this->find_tokens( $template );
		$invalid_tokens = array();
		$valid_tokens = array();

		foreach ( $tokens as $token ) {
			if ( isset( $this->token_registry[ $token ] ) ) {
				$valid_tokens[] = $token;
			} else {
				$invalid_tokens[] = $token;
			}
		}

		return array(
			'is_valid' => empty( $invalid_tokens ),
			'valid_tokens' => $valid_tokens,
			'invalid_tokens' => $invalid_tokens,
			'token_count' => count( $tokens ),
		);
	}

	/**
	 * Get token registry
	 *
	 * @since 3.4.0
	 * @return array Available tokens.
	 */
	public function get_token_registry() {
		return $this->token_registry;
	}

	/**
	 * Clear template cache
	 *
	 * @since 3.4.0
	 * @param int $tournament_id Tournament ID (optional).
	 */
	public function clear_cache( $tournament_id = null ) {
		global $wpdb;

		if ( $tournament_id ) {
			// Clear cache for specific tournament
			$cache_key_pattern = "tdwp_template_{$tournament_id}_";
			wp_cache_flush(); // Simple approach - clear all cache
		} else {
			// Clear all template cache
			wp_cache_flush();
		}
	}

	/**
	 * Register custom token
	 *
	 * @since 3.4.0
	 * @param string $token_name Token name.
	 * @param array  $token_config Token configuration.
	 * @return bool Success status.
	 */
	public function register_token( $token_name, $token_config ) {
		global $wpdb;

		// Validate token name
		if ( ! preg_match( '/^[a-zA-Z_][a-zA-Z0-9_]*$/', $token_name ) ) {
			return false;
		}

		// Prepare token data
		$token_data = array(
			'token_name' => $token_name,
			'token_description' => sanitize_text_field( $token_config['description'] ?? '' ),
			'token_type' => in_array( $token_config['type'], array( 'tournament', 'player', 'blind', 'prize', 'time', 'custom' ) ) ? $token_config['type'] : 'custom',
			'data_source' => sanitize_text_field( $token_config['data_source'] ?? '' ),
			'default_format' => sanitize_text_field( $token_config['default_format'] ?? '%s' ),
			'is_active' => 1,
		);

		// Insert into database
		$result = $wpdb->insert(
			$wpdb->prefix . 'poker_display_tokens',
			$token_data,
			array( '%s', '%s', '%s', '%s', '%s', '%d' )
		);

		if ( $result ) {
			// Update registry
			$this->token_registry[ $token_name ] = array(
				'description' => $token_data['token_description'],
				'type' => $token_data['token_type'],
				'data_source' => $token_data['data_source'],
				'default_format' => $token_data['default_format'],
			);

			return true;
		}

		return false;
	}
}