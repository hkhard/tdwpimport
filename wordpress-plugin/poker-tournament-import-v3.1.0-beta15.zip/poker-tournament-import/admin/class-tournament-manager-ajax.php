<?php
/**
 * Tournament Manager AJAX Handler
 *
 * Handles all AJAX endpoints for Phase 2 tournament management
 * Includes timer controls and table management operations
 *
 * @package Poker_Tournament_Import
 * @subpackage Tournament_Manager
 * @since 3.1.0
 */

// Prevent direct file access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tournament Manager AJAX class
 *
 * @since 3.1.0
 */
class TDWP_Tournament_Manager_AJAX {

	/**
	 * Register AJAX handlers
	 *
	 * @since 3.1.0
	 */
	public static function init() {
		// Timer endpoints
		add_action( 'wp_ajax_tdwp_tm_start', array( __CLASS__, 'start_tournament' ) );
		add_action( 'wp_ajax_tdwp_tm_pause', array( __CLASS__, 'pause_tournament' ) );
		add_action( 'wp_ajax_tdwp_tm_resume', array( __CLASS__, 'resume_tournament' ) );
		add_action( 'wp_ajax_tdwp_tm_advance_level', array( __CLASS__, 'advance_level' ) );
		add_action( 'wp_ajax_tdwp_tm_add_time', array( __CLASS__, 'add_time' ) );
		add_action( 'wp_ajax_tdwp_tm_start_break', array( __CLASS__, 'start_break' ) );
		add_action( 'wp_ajax_tdwp_tm_end_break', array( __CLASS__, 'end_break' ) );
		add_action( 'wp_ajax_tdwp_tm_finish', array( __CLASS__, 'finish_tournament' ) );
		add_action( 'wp_ajax_tdwp_tm_trash', array( __CLASS__, 'trash_tournament' ) );
		add_action( 'wp_ajax_tdwp_tm_get_state', array( __CLASS__, 'get_state' ) );

		// Table management endpoints
		add_action( 'wp_ajax_tdwp_tm_add_table', array( __CLASS__, 'add_table' ) );
		add_action( 'wp_ajax_tdwp_tm_remove_table', array( __CLASS__, 'remove_table' ) );
		add_action( 'wp_ajax_tdwp_tm_move_player', array( __CLASS__, 'move_player' ) );
		add_action( 'wp_ajax_tdwp_tm_unseat_player', array( __CLASS__, 'unseat_player' ) );
		add_action( 'wp_ajax_tdwp_tm_calculate_balance', array( __CLASS__, 'calculate_balance' ) );
		add_action( 'wp_ajax_tdwp_tm_execute_balance', array( __CLASS__, 'execute_balance' ) );
		add_action( 'wp_ajax_tdwp_tm_break_table', array( __CLASS__, 'break_table' ) );
		add_action( 'wp_ajax_tdwp_tm_get_tables', array( __CLASS__, 'get_tables' ) );
	}

	/**
	 * Verify nonce and capabilities
	 *
	 * @since 3.1.0
	 * @return bool True if valid
	 */
	private static function verify_request() {
		check_ajax_referer( 'tdwp_tournament_manager', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions', 'poker-tournament-import' ) ) );
			return false;
		}

		return true;
	}

	/**
	 * Start tournament
	 *
	 * @since 3.1.0
	 */
	public static function start_tournament() {
		self::verify_request();

		$tournament_id = isset( $_POST['tournament_id'] ) ? intval( $_POST['tournament_id'] ) : 0;
		$level_duration = isset( $_POST['level_duration'] ) ? intval( $_POST['level_duration'] ) : 900; // 15 min default

		TDWP_Debug_Logger::log(
			'AJAX',
			'START AJAX called',
			array(
				'tournament_id'  => $tournament_id,
				'level_duration' => $level_duration,
			)
		);

		if ( ! $tournament_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid tournament ID', 'poker-tournament-import' ) ) );
		}

		$success = TDWP_Live_State_Manager::start( $tournament_id, $level_duration );

		if ( $success ) {
			wp_send_json_success( array(
				'message' => __( 'Tournament started', 'poker-tournament-import' ),
				'state'   => TDWP_Live_State_Manager::get_state( $tournament_id ),
			) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to start tournament', 'poker-tournament-import' ) ) );
		}
	}

	/**
	 * Pause tournament
	 *
	 * @since 3.1.0
	 */
	public static function pause_tournament() {
		self::verify_request();

		$tournament_id   = isset( $_POST['tournament_id'] ) ? intval( $_POST['tournament_id'] ) : 0;
		$time_remaining  = isset( $_POST['time_remaining'] ) ? intval( $_POST['time_remaining'] ) : 0;

		TDWP_Debug_Logger::log(
			'AJAX',
			'PAUSE AJAX called',
			array(
				'tournament_id'  => $tournament_id,
				'time_remaining' => $time_remaining,
			)
		);

		if ( ! $tournament_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid tournament ID', 'poker-tournament-import' ) ) );
		}

		$success = TDWP_Live_State_Manager::pause( $tournament_id, $time_remaining );

		if ( $success ) {
			wp_send_json_success( array(
				'message' => __( 'Tournament paused', 'poker-tournament-import' ),
				'state'   => TDWP_Live_State_Manager::get_state( $tournament_id ),
			) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to pause tournament', 'poker-tournament-import' ) ) );
		}
	}

	/**
	 * Resume tournament
	 *
	 * @since 3.1.0
	 */
	public static function resume_tournament() {
		self::verify_request();

		$tournament_id = isset( $_POST['tournament_id'] ) ? intval( $_POST['tournament_id'] ) : 0;

		TDWP_Debug_Logger::log(
			'AJAX',
			'RESUME AJAX called',
			array( 'tournament_id' => $tournament_id )
		);

		if ( ! $tournament_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid tournament ID', 'poker-tournament-import' ) ) );
		}

		$success = TDWP_Live_State_Manager::resume( $tournament_id );

		if ( $success ) {
			wp_send_json_success( array(
				'message' => __( 'Tournament resumed', 'poker-tournament-import' ),
				'state'   => TDWP_Live_State_Manager::get_state( $tournament_id ),
			) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to resume tournament', 'poker-tournament-import' ) ) );
		}
	}

	/**
	 * Advance to next level
	 *
	 * @since 3.1.0
	 */
	public static function advance_level() {
		self::verify_request();

		$tournament_id      = isset( $_POST['tournament_id'] ) ? intval( $_POST['tournament_id'] ) : 0;
		$next_level_duration = isset( $_POST['next_level_duration'] ) ? intval( $_POST['next_level_duration'] ) : 900;

		if ( ! $tournament_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid tournament ID', 'poker-tournament-import' ) ) );
		}

		$success = TDWP_Live_State_Manager::advance_level( $tournament_id, $next_level_duration );

		if ( $success ) {
			wp_send_json_success( array(
				'message' => __( 'Advanced to next level', 'poker-tournament-import' ),
				'state'   => TDWP_Live_State_Manager::get_state( $tournament_id ),
			) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to advance level', 'poker-tournament-import' ) ) );
		}
	}

	/**
	 * Add time to current level
	 *
	 * @since 3.1.0
	 */
	public static function add_time() {
		self::verify_request();

		$tournament_id  = isset( $_POST['tournament_id'] ) ? intval( $_POST['tournament_id'] ) : 0;
		$seconds_to_add = isset( $_POST['seconds'] ) ? intval( $_POST['seconds'] ) : 300; // 5 min default

		if ( ! $tournament_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid tournament ID', 'poker-tournament-import' ) ) );
		}

		$success = TDWP_Live_State_Manager::add_time( $tournament_id, $seconds_to_add );

		if ( $success ) {
			wp_send_json_success( array(
				'message' => sprintf(
					/* translators: %d: seconds added */
					__( 'Added %d seconds', 'poker-tournament-import' ),
					$seconds_to_add
				),
				'state' => TDWP_Live_State_Manager::get_state( $tournament_id ),
			) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to add time', 'poker-tournament-import' ) ) );
		}
	}

	/**
	 * Start break
	 *
	 * @since 3.1.0
	 */
	public static function start_break() {
		self::verify_request();

		$tournament_id    = isset( $_POST['tournament_id'] ) ? intval( $_POST['tournament_id'] ) : 0;
		$break_duration   = isset( $_POST['break_duration'] ) ? intval( $_POST['break_duration'] ) : 10;

		if ( ! $tournament_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid tournament ID', 'poker-tournament-import' ) ) );
		}

		$success = TDWP_Live_State_Manager::start_break( $tournament_id, $break_duration );

		if ( $success ) {
			wp_send_json_success( array(
				'message' => sprintf(
					/* translators: %d: break duration in minutes */
					__( 'Break started (%d minutes)', 'poker-tournament-import' ),
					$break_duration
				),
				'state' => TDWP_Live_State_Manager::get_state( $tournament_id ),
			) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to start break', 'poker-tournament-import' ) ) );
		}
	}

	/**
	 * End break
	 *
	 * @since 3.1.0
	 */
	public static function end_break() {
		self::verify_request();

		$tournament_id       = isset( $_POST['tournament_id'] ) ? intval( $_POST['tournament_id'] ) : 0;
		$next_level_duration = isset( $_POST['next_level_duration'] ) ? intval( $_POST['next_level_duration'] ) : 900;

		if ( ! $tournament_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid tournament ID', 'poker-tournament-import' ) ) );
		}

		$success = TDWP_Live_State_Manager::end_break( $tournament_id, $next_level_duration );

		if ( $success ) {
			wp_send_json_success( array(
				'message' => __( 'Break ended', 'poker-tournament-import' ),
				'state'   => TDWP_Live_State_Manager::get_state( $tournament_id ),
			) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to end break', 'poker-tournament-import' ) ) );
		}
	}

	/**
	 * Finish tournament
	 *
	 * @since 3.1.0
	 */
	public static function finish_tournament() {
		self::verify_request();

		$tournament_id = isset( $_POST['tournament_id'] ) ? intval( $_POST['tournament_id'] ) : 0;

		TDWP_Debug_Logger::log(
			'AJAX',
			'FINISH AJAX called',
			array( 'tournament_id' => $tournament_id )
		);

		if ( ! $tournament_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid tournament ID', 'poker-tournament-import' ) ) );
		}

		$success = TDWP_Live_State_Manager::finish( $tournament_id );

		if ( $success ) {
			wp_send_json_success( array(
				'message' => __( 'Tournament finished', 'poker-tournament-import' ),
				'state'   => TDWP_Live_State_Manager::get_state( $tournament_id ),
			) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to finish tournament', 'poker-tournament-import' ) ) );
		}
	}

	/**
	 * Trash tournament
	 *
	 * @since 3.1.0
	 */
	public static function trash_tournament() {
		self::verify_request();

		$tournament_id = isset( $_POST['tournament_id'] ) ? intval( $_POST['tournament_id'] ) : 0;

		TDWP_Debug_Logger::log(
			'AJAX',
			'TRASH AJAX called',
			array( 'tournament_id' => $tournament_id )
		);

		if ( ! $tournament_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid tournament ID', 'poker-tournament-import' ) ) );
		}

		// Verify tournament is finished before allowing trash.
		$state = TDWP_Live_State_Manager::get_state( $tournament_id );
		if ( ! $state || 'finished' !== $state->status ) {
			wp_send_json_error( array( 'message' => __( 'Only finished tournaments can be trashed', 'poker-tournament-import' ) ) );
		}

		// Trash the tournament post.
		$result = wp_trash_post( $tournament_id );

		if ( $result ) {
			// Clear active tournament for current user.
			TDWP_Active_Tournament_Manager::clear_active_tournament( get_current_user_id() );

			wp_send_json_success( array(
				'message'      => __( 'Tournament trashed', 'poker-tournament-import' ),
				'redirect_url' => admin_url( 'admin.php?page=tdwp-live-control' ),
			) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to trash tournament', 'poker-tournament-import' ) ) );
		}
	}

	/**
	 * Get tournament state (for Heartbeat polling)
	 *
	 * @since 3.1.0
	 */
	public static function get_state() {
		self::verify_request();

		$tournament_id = isset( $_POST['tournament_id'] ) ? intval( $_POST['tournament_id'] ) : 0;

		TDWP_Debug_Logger::log(
			'AJAX',
			'GET_STATE AJAX called',
			array( 'tournament_id' => $tournament_id )
		);

		if ( ! $tournament_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid tournament ID', 'poker-tournament-import' ) ) );
		}

		$state = TDWP_Live_State_Manager::get_state( $tournament_id );

		TDWP_Debug_Logger::log(
			'AJAX',
			'GET_STATE initial state from DB',
			array(
				'status'         => $state ? $state->status : 'null',
				'time_remaining' => $state ? $state->time_remaining : 'null',
				'updated_at'     => $state ? $state->updated_at : 'null',
			)
		);

		// Tick for elapsed time to get fresh state (not stale database time)
		if ( $state && 'running' === $state->status ) {
			$elapsed = time() - strtotime( $state->updated_at );
			$elapsed = min( max( 0, $elapsed ), 30 ); // Cap between 0-30 seconds

			if ( $elapsed > 0 ) {
				$clock_manager = new TDWP_Tournament_Clock();
				$clock_manager->tick( $tournament_id, $elapsed );
				// Refresh state after tick
				$state = TDWP_Live_State_Manager::get_state( $tournament_id );

				TDWP_Debug_Logger::log(
					'AJAX',
					'GET_STATE after tick',
					array(
						'time_remaining' => $state->time_remaining,
						'updated_at'     => $state->updated_at,
					)
				);
			}
		}

		$tables = TDWP_Table_Manager::get_tables( $tournament_id, 'active' );

		wp_send_json_success( array(
			'state'        => $state,
			'tables'       => $tables,
			'player_count' => TDWP_Table_Manager::get_seated_player_count( $tournament_id ),
			'timestamp'    => time(),
		) );
	}

	/**
	 * Add table
	 *
	 * @since 3.1.0
	 */
	public static function add_table() {
		self::verify_request();

		$tournament_id = isset( $_POST['tournament_id'] ) ? intval( $_POST['tournament_id'] ) : 0;
		$max_seats     = isset( $_POST['max_seats'] ) ? intval( $_POST['max_seats'] ) : 9;

		if ( ! $tournament_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid tournament ID', 'poker-tournament-import' ) ) );
		}

		$table_id = TDWP_Table_Manager::add_table( $tournament_id, $max_seats );

		if ( $table_id ) {
			$table = TDWP_Table_Manager::get_table( $table_id );
			wp_send_json_success( array(
				'message' => __( 'Table added', 'poker-tournament-import' ),
				'table'   => $table,
			) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to add table', 'poker-tournament-import' ) ) );
		}
	}

	/**
	 * Remove table
	 *
	 * @since 3.1.0
	 */
	public static function remove_table() {
		self::verify_request();

		$table_id = isset( $_POST['table_id'] ) ? intval( $_POST['table_id'] ) : 0;

		if ( ! $table_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid table ID', 'poker-tournament-import' ) ) );
		}

		if ( ! TDWP_Table_Manager::is_table_empty( $table_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Cannot remove table with players', 'poker-tournament-import' ) ) );
		}

		$success = TDWP_Table_Manager::remove_table( $table_id );

		if ( $success ) {
			wp_send_json_success( array( 'message' => __( 'Table removed', 'poker-tournament-import' ) ) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to remove table', 'poker-tournament-import' ) ) );
		}
	}

	/**
	 * Move player to seat
	 *
	 * @since 3.1.0
	 */
	public static function move_player() {
		self::verify_request();

		$player_id      = isset( $_POST['player_id'] ) ? intval( $_POST['player_id'] ) : 0;
		$to_table_id    = isset( $_POST['to_table_id'] ) ? intval( $_POST['to_table_id'] ) : 0;
		$to_seat_number = isset( $_POST['to_seat_number'] ) ? intval( $_POST['to_seat_number'] ) : 0;

		if ( ! $player_id || ! $to_table_id || ! $to_seat_number ) {
			wp_send_json_error( array( 'message' => __( 'Invalid parameters', 'poker-tournament-import' ) ) );
		}

		// Validate assignment
		$validation = TDWP_Seat_Manager::validate_assignment( $player_id, $to_table_id, $to_seat_number );
		if ( ! $validation['valid'] ) {
			wp_send_json_error( array( 'message' => $validation['error'] ) );
		}

		$success = TDWP_Seat_Manager::move_player( $player_id, $to_table_id, $to_seat_number );

		if ( $success ) {
			wp_send_json_success( array(
				'message' => __( 'Player moved', 'poker-tournament-import' ),
				'seat'    => TDWP_Seat_Manager::get_player_seat( $player_id ),
			) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to move player', 'poker-tournament-import' ) ) );
		}
	}

	/**
	 * Unseat player
	 *
	 * @since 3.1.0
	 */
	public static function unseat_player() {
		self::verify_request();

		$player_id = isset( $_POST['player_id'] ) ? intval( $_POST['player_id'] ) : 0;

		if ( ! $player_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid player ID', 'poker-tournament-import' ) ) );
		}

		$success = TDWP_Seat_Manager::unseat_player( $player_id );

		if ( $success ) {
			wp_send_json_success( array( 'message' => __( 'Player unseated', 'poker-tournament-import' ) ) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to unseat player', 'poker-tournament-import' ) ) );
		}
	}

	/**
	 * Calculate balance plan
	 *
	 * @since 3.1.0
	 */
	public static function calculate_balance() {
		self::verify_request();

		$tournament_id = isset( $_POST['tournament_id'] ) ? intval( $_POST['tournament_id'] ) : 0;

		if ( ! $tournament_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid tournament ID', 'poker-tournament-import' ) ) );
		}

		$plan = TDWP_Table_Balancer::calculate_balance_plan( $tournament_id );

		wp_send_json_success( $plan );
	}

	/**
	 * Execute balance plan
	 *
	 * @since 3.1.0
	 */
	public static function execute_balance() {
		self::verify_request();

		$tournament_id = isset( $_POST['tournament_id'] ) ? intval( $_POST['tournament_id'] ) : 0;
		$moves         = isset( $_POST['moves'] ) ? json_decode( stripslashes( $_POST['moves'] ), true ) : array();

		if ( ! $tournament_id || empty( $moves ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid parameters', 'poker-tournament-import' ) ) );
		}

		$results = TDWP_Table_Balancer::execute_balance( $tournament_id, $moves );

		if ( $results['success'] ) {
			wp_send_json_success( array(
				'message' => __( 'Tables balanced', 'poker-tournament-import' ),
				'results' => $results,
			) );
		} else {
			wp_send_json_error( array(
				'message' => __( 'Some moves failed', 'poker-tournament-import' ),
				'results' => $results,
			) );
		}
	}

	/**
	 * Break table
	 *
	 * @since 3.1.0
	 */
	public static function break_table() {
		self::verify_request();

		$tournament_id = isset( $_POST['tournament_id'] ) ? intval( $_POST['tournament_id'] ) : 0;
		$table_id      = isset( $_POST['table_id'] ) ? intval( $_POST['table_id'] ) : 0;

		if ( ! $tournament_id || ! $table_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid parameters', 'poker-tournament-import' ) ) );
		}

		// Get break suggestion
		$suggestion = TDWP_Table_Balancer::suggest_table_break( $tournament_id );

		if ( ! $suggestion || ! $suggestion['can_break'] ) {
			wp_send_json_error( array( 'message' => $suggestion['message'] ) );
		}

		// Execute break
		$success = TDWP_Table_Balancer::execute_table_break( $tournament_id, $table_id, $suggestion['moves'] );

		if ( $success ) {
			wp_send_json_success( array(
				'message' => __( 'Table broken', 'poker-tournament-import' ),
				'moves'   => $suggestion['moves'],
			) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to break table', 'poker-tournament-import' ) ) );
		}
	}

	/**
	 * Get tables data
	 *
	 * @since 3.1.0
	 */
	public static function get_tables() {
		self::verify_request();

		$tournament_id = isset( $_POST['tournament_id'] ) ? intval( $_POST['tournament_id'] ) : 0;

		if ( ! $tournament_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid tournament ID', 'poker-tournament-import' ) ) );
		}

		$tables         = TDWP_Table_Manager::get_tables( $tournament_id, 'active' );
		$balance_status = TDWP_Table_Balancer::get_balance_status( $tournament_id );

		wp_send_json_success( array(
			'tables'         => $tables,
			'balance_status' => $balance_status,
			'player_count'   => TDWP_Table_Manager::get_seated_player_count( $tournament_id ),
		) );
	}
}

// Initialize AJAX handlers
TDWP_Tournament_Manager_AJAX::init();
