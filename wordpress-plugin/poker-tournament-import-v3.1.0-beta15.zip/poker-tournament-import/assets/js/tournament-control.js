/**
 * Tournament Control JS
 * Tab switching, minimized indicator
 */

(function($) {
    'use strict';

    const TournamentControl = {
        currentTab: 'timer',

        init: function() {
            this.bindEvents();
            this.initMinimizedClock();
        },

        bindEvents: function() {
            // Tab switching
            $('.tdwp-tab-button').on('click', this.switchTab.bind(this));

            // Modal close buttons
            $('.modal-close').on('click', function() {
                $(this).closest('.tdwp-modal').hide();
            });

            // Click outside modal to close
            $('.tdwp-modal').on('click', function(e) {
                if ($(e.target).hasClass('tdwp-modal')) {
                    $(this).hide();
                }
            });
        },

        switchTab: function(e) {
            const $button = $(e.currentTarget);
            const tab = $button.data('tab');

            if (tab === this.currentTab) {
                return;
            }

            // Update buttons
            $('.tdwp-tab-button').removeClass('active');
            $button.addClass('active');

            // Update panels
            $('.tdwp-tab-panel').removeClass('active');
            $('#tab-' + tab).addClass('active');

            // Update minimized clock visibility
            if (tab === 'timer') {
                $('#tdwp-minimized-clock').hide();
            } else {
                $('#tdwp-minimized-clock').show();
            }

            this.currentTab = tab;

            // Trigger event for other scripts
            $(document).trigger('tdwp:tabChanged', [tab]);
        },

        initMinimizedClock: function() {
            // Initially hidden (timer tab is active by default)
            $('#tdwp-minimized-clock').hide();
        },

        updateMinimizedClock: function(level, time, blinds) {
            $('#mini-level').text(level);
            $('#mini-time').text(time);
            $('#mini-blinds').text(blinds);
        },

        showNotice: function(message, type) {
            type = type || 'success';

            const $notice = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');

            $('.tdwp-tournament-control h1').after($notice);

            // Auto-dismiss after 3 seconds
            setTimeout(function() {
                $notice.fadeOut(function() {
                    $(this).remove();
                });
            }, 3000);
        },

        showModal: function(modalId) {
            $('#' + modalId).show();
        },

        hideModal: function(modalId) {
            $('#' + modalId).hide();
        }
    };

    // Initialize on document ready
    $(document).ready(function() {
        TournamentControl.init();
    });

    // Export to global scope for other scripts
    window.TournamentControl = TournamentControl;

})(jQuery);
