<?php
/**
 * CSS Dashboard Configuration for Poker Tournament Import
 *
 * Maps existing poker tournament data to CSS dashboard components
 */

class Poker_CSS_Dashboard_Config extends CSS_Dashboard_Base
{

    public function __construct()
    {
        parent::__construct();
        add_filter('css_dashboard_config', array($this, 'get_dashboard_config'));
    }

    protected function get_menu_slug()
    {
        return 'poker-css-dashboard';
    }

    protected function get_page_title()
    {
        return 'Poker Dashboard';
    }

    protected function get_menu_title()
    {
        return 'Poker Dashboard';
    }

    protected function get_menu_icon()
    {
        return 'dashicons-chart-pie';
    }

    protected function get_menu_position()
    {
        return 3;
    }

    /**
     * Filter controls section
     *
     * @param Poker_Dashboard_Filters $filters Filter system instance
     * @return array Section configuration
     */
    private function get_filters_section($filters) {
        $current_url = remove_query_arg(array_keys($_GET)); // Clear all params

        return array(
            'id' => 'dashboard-filters',
            'title' => '', // No title for filter bar
            'columns' => 1,
            'components' => array(
                array(
                    'id' => 'filter-controls',
                    'parent_section_id' => 'dashboard-filters',
                    'type' => 'custom', // Custom HTML type
                    'html' => $filters->render_filter_controls($current_url)
                )
            )
        );
    }

    public function get_dashboard_config($config)
    {
        global $wpdb;

        // Initialize filter system
        $filters = new Poker_Dashboard_Filters();

        $config['title'] = 'Poker Tournament Dashboard';
        $config['sections'] = array();

        // Add filter controls section (first, before data)
        $config['sections'][] = $this->get_filters_section($filters);

        // Overview Statistics Section
        $config['sections'][] = $this->get_overview_section($filters);

        // Tournaments Table Section
        $config['sections'][] = $this->get_tournaments_section($filters);

        // Players Table Section
        $config['sections'][] = $this->get_players_section($filters);

        // Series Table Section
        $config['sections'][] = $this->get_series_section($filters);

        // Seasons Table Section
        $config['sections'][] = $this->get_seasons_section($filters);

        // Overall Points Standings Section
        $config['sections'][] = $this->get_overall_standings_section($filters);

        return $config;
    }

    private function get_overview_section($filters = null)
    {
        // Get active season from filters
        $season_id = null;
        if ($filters) {
            $season_id = $filters->get_active_season();
        }

        // Count tournaments (filtered by season if active)
        $tournament_args = array(
            'post_type' => 'tournament',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'post_status' => 'publish'
        );

        if ($season_id) {
            $tournament_args['meta_query'] = array(
                array('key' => '_season_id', 'value' => $season_id, 'compare' => '=')
            );
        }

        $tournaments = get_posts($tournament_args);
        $tournament_count = count($tournaments);

        // Count unique players from filtered tournaments
        $player_count = 0;
        if (!empty($tournaments)) {
            global $wpdb;
            // When 'fields' => 'ids', $tournaments IS already the array of IDs
            $tournament_ids = $tournaments;
            $table_name = $wpdb->prefix . 'poker_tournament_players';

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table query
            $player_count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(DISTINCT player_id) FROM $table_name
                 WHERE tournament_id IN (" . implode(',', array_fill(0, count($tournament_ids), '%s')) . ")",
                $tournament_ids
            ));
        }

        $series_count = wp_count_posts('tournament_series')->publish;
        $season_count = wp_count_posts('tournament_season')->publish;

        // Calculate total prize pool from filtered tournaments (poker_financial_summary table doesn't have season_id column)
        global $wpdb;
        $total_prize = 0;
        if (!empty($tournaments)) {
            // Sum prize pool from tournament meta directly
            foreach ($tournaments as $tournament_id) {
                $prize = get_post_meta($tournament_id, '_prize_pool', true);
                $total_prize += floatval($prize);
            }
        }

        return array(
            'id' => 'overview-stats',
            'title' => 'Overview Statistics',
            'columns' => 4,
            'components' => array(
                array(
                    'id' => 'total-tournaments',
                    'parent_section_id' => 'overview-stats',
                    'type' => 'stat',
                    'title' => 'Total Tournaments',
                    'value' => number_format($tournament_count),
                    'icon' => 'dashicons-calendar',
                    'color' => 'primary',
                ),
                array(
                    'id' => 'total-players',
                    'parent_section_id' => 'overview-stats',
                    'type' => 'stat',
                    'title' => 'Total Players',
                    'value' => number_format($player_count),
                    'icon' => 'dashicons-groups',
                    'color' => 'success',
                ),
                array(
                    'id' => 'total-prize',
                    'parent_section_id' => 'overview-stats',
                    'type' => 'stat',
                    'title' => 'Total Prize Pool',
                    'value' => '$' . number_format($total_prize ?: 0),
                    'icon' => 'dashicons-money-alt',
                    'color' => 'primary',
                ),
                array(
                    'id' => 'series-count',
                    'parent_section_id' => 'overview-stats',
                    'type' => 'stat',
                    'title' => 'Series / Seasons',
                    'value' => number_format($series_count) . ' / ' . number_format($season_count),
                    'icon' => 'dashicons-list-view',
                    'color' => 'success',
                ),
            )
        );
    }

    private function get_tournaments_section($filters = null)
    {
        // Get active season from filters
        $season_id = null;
        if ($filters) {
            $season_id = $filters->get_active_season();
        }

        $args = array(
            'post_type' => 'tournament',
            'posts_per_page' => 50,
            'orderby' => 'date',
            'order' => 'DESC',
            'post_status' => 'publish',
        );

        // Apply season filter if active
        if ($season_id) {
            $args['meta_query'] = array(
                array('key' => '_season_id', 'value' => $season_id, 'compare' => '=')
            );
        }

        $tournaments = get_posts($args);
        $rows = array();

        foreach ($tournaments as $index => $tournament) {
            $date = get_post_meta($tournament->ID, '_tournament_date', true);
            $players = get_post_meta($tournament->ID, '_player_count', true);
            $prize_pool = get_post_meta($tournament->ID, '_prize_pool', true);

            $rows[] = array(
                'cells' => array(
                    esc_html($tournament->post_title),
                    $date ? date('Y-m-d', strtotime($date)) : 'N/A',
                    $players ? number_format($players) : '0',
                    $prize_pool ? '$' . number_format($prize_pool) : '$0',
                ),
            );
        }

        return array(
            'id' => 'tournaments-table',
            'title' => 'Recent Tournaments',
            'components' => array(
                array(
                    'id' => 'tournaments-data',
                    'parent_section_id' => 'tournaments-table',
                    'type' => 'table',
                    'headers' => array('Tournament', 'Date', 'Players', 'Prize Pool'),
                    'rows' => $rows,
                    'per_page' => 25,
                )
            )
        );
    }

    private function get_players_section($filters = null)
    {
        // Get active season from filters
        $season_id = null;
        if ($filters) {
            $season_id = $filters->get_active_season();
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'poker_tournament_players';

        // Get player statistics from custom table, filtered by season if active
        if ($season_id) {
            // Get tournament post IDs first
            $season_tournaments = get_posts(array(
                'post_type' => 'tournament',
                'posts_per_page' => -1,
                'fields' => 'ids',
                'meta_query' => array(
                    array('key' => '_season_id', 'value' => $season_id, 'compare' => '=')
                )
            ));

            if (empty($season_tournaments)) {
                $players = array();
            } else {
                // CRITICAL: Get tournament UUIDs from postmeta
                $tournament_uuids = array();
                foreach ($season_tournaments as $post_id) {
                    $uuid = get_post_meta($post_id, 'tournament_uuid', true);
                    if ($uuid) {
                        $tournament_uuids[] = $uuid;
                    }
                }

                if (empty($tournament_uuids)) {
                    $players = array();
                } else {
                    // Now get players using UUIDs
                    $players = $wpdb->get_results($wpdb->prepare(
                        "SELECT DISTINCT p.ID, p.post_title,
                                COALESCE(SUM(tp.winnings), 0) as winnings,
                                COUNT(DISTINCT tp.tournament_id) as played,
                                COALESCE(AVG(tp.finish_position), 0) as avg_finish
                         FROM {$wpdb->posts} p
                         INNER JOIN $table_name tp ON p.ID = tp.player_id
                         WHERE tp.tournament_id IN (" . implode(',', array_fill(0, count($tournament_uuids), '%s')) . ")
                         GROUP BY p.ID
                         ORDER BY winnings DESC
                         LIMIT 100",
                        $tournament_uuids
                    ));
                }
            }
        } else {
            // Get all players without season filter
            $players = $wpdb->get_results("
                SELECT p.ID, p.post_title,
                       COALESCE(stats.total_winnings, 0) as winnings,
                       COALESCE(stats.tournaments_played, 0) as played,
                       COALESCE(stats.avg_finish, 0) as avg_finish
                FROM {$wpdb->posts} p
                LEFT JOIN {$wpdb->prefix}poker_player_roi stats ON p.ID = stats.player_id
                WHERE p.post_type = 'player' AND p.post_status = 'publish'
                ORDER BY winnings DESC
                LIMIT 100
            ");
        }

        $rows = array();

        foreach ($players as $player) {
            $rows[] = array(
                'cells' => array(
                    esc_html($player->post_title),
                    number_format($player->winnings),
                    number_format($player->played),
                    number_format($player->avg_finish, 1),
                ),
            );
        }

        return array(
            'id' => 'players-table',
            'title' => 'Player Rankings',
            'components' => array(
                array(
                    'id' => 'players-data',
                    'parent_section_id' => 'players-table',
                    'type' => 'table',
                    'headers' => array('Player', 'Total Winnings', 'Tournaments', 'Avg Finish'),
                    'rows' => $rows,
                    'per_page' => 25,
                )
            )
        );
    }

    private function get_series_section($filters = null)
    {
        // Get active season from filters
        $season_id = null;
        if ($filters) {
            $season_id = $filters->get_active_season();
        }

        global $wpdb;

        $series_args = array(
            'post_type' => 'tournament_series',
            'posts_per_page' => 50,
            'orderby' => 'title',
            'order' => 'ASC',
        );

        // If season is filtered, only show series from that season
        if ($season_id) {
            $series_args['meta_query'] = array(
                array('key' => '_season_id', 'value' => $season_id, 'compare' => '=')
            );
        }

        $series_list = get_posts($series_args);

        $rows = array();

        foreach ($series_list as $series) {
            $tournament_count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->posts}
                WHERE post_type = 'tournament'
                AND post_status = 'publish'
                AND ID IN (
                    SELECT post_id FROM {$wpdb->postmeta}
                    WHERE meta_key = '_tournament_series_id'
                    AND meta_value = %d
                )",
                $series->ID
            ));

            $rows[] = array(
                'cells' => array(
                    esc_html($series->post_title),
                    $tournament_count ? number_format($tournament_count) : '0',
                ),
            );
        }

        return array(
            'id' => 'series-table',
            'title' => 'Tournament Series',
            'components' => array(
                array(
                    'id' => 'series-data',
                    'parent_section_id' => 'series-table',
                    'type' => 'table',
                    'headers' => array('Series', 'Tournaments'),
                    'rows' => $rows,
                    'per_page' => 25,
                )
            )
        );
    }

    private function get_seasons_section($filters = null)
    {
        global $wpdb;

        $seasons = get_posts(array(
            'post_type' => 'tournament_season',
            'posts_per_page' => 50,
            'orderby' => 'title',
            'order' => 'DESC',
        ));

        $rows = array();

        foreach ($seasons as $season) {
            $tournament_count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->posts}
                WHERE post_type = 'tournament'
                AND post_status = 'publish'
                AND ID IN (
                    SELECT post_id FROM {$wpdb->postmeta}
                    WHERE meta_key = '_season_id'
                    AND meta_value = %d
                )",
                $season->ID
            ));

            $rows[] = array(
                'cells' => array(
                    esc_html($season->post_title),
                    $tournament_count ? number_format($tournament_count) : '0',
                ),
            );
        }

        return array(
            'id' => 'seasons-table',
            'title' => 'Tournament Seasons',
            'components' => array(
                array(
                    'id' => 'seasons-data',
                    'parent_section_id' => 'seasons-table',
                    'type' => 'table',
                    'headers' => array('Season', 'Tournaments'),
                    'rows' => $rows,
                    'per_page' => 25,
                )
            )
        );
    }

    /**
     * Overall Points Standings Section
     * Shows player rankings across all tournaments (filtered by season)
     *
     * @param Poker_Dashboard_Filters $filters Filter system instance
     * @return array Section configuration
     */
    private function get_overall_standings_section($filters) {
        // Get filtered tournament IDs
        $tournament_ids = $filters->get_filtered_tournament_ids();

        // Calculate standings
        $calculator = new Poker_Series_Standings_Calculator();
        $standings = $calculator->calculate_overall_standings($tournament_ids);

        if (empty($standings)) {
            // Return empty section with message
            return array(
                'id' => 'overall-standings',
                'title' => __('Overall Points Standings', 'poker-tournament-import'),
                'columns' => 1,
                'components' => array(
                    array(
                        'id' => 'standings-empty',
                        'parent_section_id' => 'overall-standings',
                        'type' => 'custom',
                        'html' => '<p>' . esc_html__('No standings data available.', 'poker-tournament-import') . '</p>'
                    )
                )
            );
        }

        // Build table rows
        $rows = array();
        foreach ($standings as $standing) {
            $rank_display = $standing['rank'];
            if ($standing['is_tied']) {
                $rank_display .= 'T';
            }

            // Add position indicators for top ranks
            $rank_suffix = '';
            $rank_class = '';
            if ($standing['rank'] === 1) {
                $rank_suffix = ' 🥇';
                $rank_class = ' rank-first';
            } elseif ($standing['rank'] === 2) {
                $rank_suffix = ' 🥈';
                $rank_class = ' rank-second';
            } elseif ($standing['rank'] === 3) {
                $rank_suffix = ' 🥉';
                $rank_class = ' rank-third';
            }

            // Player cell with link
            $player_cell = $standing['player_url']
                ? sprintf('<a href="%s">%s</a>', $standing['player_url'], esc_html($standing['player_name']))
                : esc_html($standing['player_name']);

            $rows[] = array(
                'cells' => array(
                    '<span class="rank-cell' . esc_attr($rank_class) . '">' . esc_html($rank_display) . esc_html($rank_suffix) . '</span>',
                    $player_cell,
                    '<span class="points-cell">' . number_format($standing['overall_points'], 1) . '</span>',
                    number_format($standing['tournaments_played']),
                    $standing['best_finish'],
                    number_format($standing['avg_finish'], 1),
                    number_format($standing['tie_breakers']['first_places']),
                    number_format($standing['tie_breakers']['top3_finishes']),
                    number_format($standing['tie_breakers']['top5_finishes']),
                )
            );
        }

        return array(
            'id' => 'overall-standings',
            'title' => __('Overall Points Standings', 'poker-tournament-import'),
            'columns' => 1,
            'components' => array(
                array(
                    'id' => 'overall-standings-table',
                    'parent_section_id' => 'overall-standings',
                    'type' => 'table',
                    'sortable' => false, // Server-side sorted, no client sorting needed
                    'headers' => array(
                        __('Rank', 'poker-tournament-import'),
                        __('Player', 'poker-tournament-import'),
                        __('Points', 'poker-tournament-import'),
                        __('Played', 'poker-tournament-import'),
                        __('Best', 'poker-tournament-import'),
                        __('Avg Finish', 'poker-tournament-import'),
                        __('1st', 'poker-tournament-import'),
                        __('Top 3', 'poker-tournament-import'),
                        __('Top 5', 'poker-tournament-import'),
                    ),
                    'rows' => $rows,
                    'per_page' => 25
                )
            )
        );
    }
}

new Poker_CSS_Dashboard_Config();
