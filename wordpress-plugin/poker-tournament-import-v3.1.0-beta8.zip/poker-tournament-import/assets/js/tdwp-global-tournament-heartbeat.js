/**
 * Global Tournament Heartbeat
 *
 * Keeps tournament clock ticking across all admin pages using WordPress Heartbeat API.
 * Only runs when user has an active tournament.
 *
 * @package Poker_Tournament_Import
 * @since 3.1.0
 */

(function ($) {
	'use strict';

	// Only run if user has active tournament
	if (!tdwpGlobalHeartbeat || !tdwpGlobalHeartbeat.activeTournamentId) {
		return;
	}

	/**
	 * Send tournament ID with every heartbeat
	 *
	 * WordPress Heartbeat runs every 60 seconds on admin pages.
	 * This ensures tournament clock ticks even when user is on other pages.
	 *
	 * @since 3.1.0
	 */
	$(document).on('heartbeat-send', function (e, data) {
		data.tdwp_tournament_id = tdwpGlobalHeartbeat.activeTournamentId;
	});

	/**
	 * Update admin bar when heartbeat returns
	 *
	 * Server returns updated tournament state (status, level, time, etc.).
	 * Update admin bar widget to show current state.
	 *
	 * @since 3.1.0
	 */
	$(document).on('heartbeat-tick', function (e, data) {
		if (data.tdwp_live_state) {
			updateAdminBar(data.tdwp_live_state);
		}
	});

	/**
	 * Update admin bar widget with current state
	 *
	 * @since 3.1.0
	 * @param {Object} state Tournament state from server.
	 */
	function updateAdminBar(state) {
		var $statusEl = $('#wp-admin-bar-tdwp-active-tournament .tdwp-status');

		if (!$statusEl.length) {
			return;
		}

		var statusText = getStatusText(state.status, state.current_level);
		$statusEl.text(statusText);
	}

	/**
	 * Get formatted status text
	 *
	 * @since 3.1.0
	 * @param {string} status Tournament status (running, paused, break, setup).
	 * @param {number} level Current level number.
	 * @return {string} Formatted status text.
	 */
	function getStatusText(status, level) {
		switch (status) {
			case 'running':
				return tdwpGlobalHeartbeat.i18n.level.replace('%d', level);

			case 'paused':
				return tdwpGlobalHeartbeat.i18n.paused.replace('%d', level);

			case 'break':
				return tdwpGlobalHeartbeat.i18n.break;

			case 'setup':
				return tdwpGlobalHeartbeat.i18n.setup;

			default:
				return status.charAt(0).toUpperCase() + status.slice(1);
		}
	}

})(jQuery);
