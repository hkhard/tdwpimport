<?php
/**
 * Plugin Name: Poker Tournament Import
 * Plugin URI: https://nikielhard.se/tdwpimport
 * Description: Import and display poker tournament results from Tournament Director (.tdt) files
 * Version: 2.4.43
 * Author: Hans Kästel Hård
 * Author URI: https://nikielhard.se/tdwpimport
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: poker-tournament-import
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 8.0
 */

// Prevent direct file access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('POKER_TOURNAMENT_IMPORT_VERSION', '2.4.43');
define('POKER_TOURNAMENT_IMPORT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('POKER_TOURNAMENT_IMPORT_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Main plugin class
 */
class Poker_Tournament_Import {

    /**
     * Singleton instance
     */
    private static $instance = null;

    /**
     * PHP 8.2+ compatibility - declare dynamic properties
     */
    private $taxonomies;
    private $formula_validator;
    private $statistics_engine;

    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        add_action('init', array($this, 'init'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }

    /**
     * Initialize plugin
     */
    public function init() {
        $this->load_textdomain();
        $this->includes();
        $this->init_post_types();
        $this->init_taxonomies();
        $this->init_formula_validator();
        $this->init_shortcodes();
        $this->init_statistics_engine();

        // Check for plugin update and refresh statistics if needed
        $this->check_plugin_update();

        // Register custom template loading for our post types
        add_filter('template_include', array($this, 'load_custom_templates'));

        // Frontend assets - only load on frontend, NOT in admin
        if (!is_admin()) {
            add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
        }

        // Admin hooks
        if (is_admin()) {
            require_once POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'admin/class-admin.php';
            new Poker_Tournament_Import_Admin();

            // Initialize migration tools
            require_once POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'admin/class-migration-tools.php';
            new Poker_Tournament_Migration_Tools();

            // Initialize shortcode help page
            require_once POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'admin/shortcode-help.php';
            $shortcode_help = new Poker_Shortcode_Help_Page();
            $shortcode_help->add_help_admin_menu();

            // Initialize shortcode helper meta boxes
            require_once POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'admin/shortcode-helper.php';
            new Poker_Shortcode_Helper();

            // Initialize data mart cleaner
            require_once POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'admin/class-data-mart-cleaner.php';
            new Poker_Data_Mart_Cleaner();
        }

        // AJAX handlers for tabbed interface
        add_action('wp_ajax_poker_series_tab_content', array($this, 'ajax_series_tab_content'));
        add_action('wp_ajax_nopriv_poker_series_tab_content', array($this, 'ajax_series_tab_content'));
        add_action('wp_ajax_poker_series_load_more', array($this, 'ajax_series_load_more'));
        add_action('wp_ajax_nopriv_poker_series_load_more', array($this, 'ajax_series_load_more'));

        // AJAX handlers for formula validator
        add_action('wp_ajax_poker_validate_formula', array($this, 'ajax_validate_formula'));
        add_action('wp_ajax_poker_save_formula', array($this, 'ajax_save_formula'));
        add_action('wp_ajax_poker_delete_formula', array($this, 'ajax_delete_formula'));
        add_action('wp_ajax_poker_get_formula', array($this, 'ajax_get_formula'));

        // AJAX handlers for series standings
        add_action('wp_ajax_poker_export_standings', array($this, 'ajax_export_standings'));

        // Dashboard AJAX handlers are now registered in admin/class-admin.php to avoid conflicts

        // **PHASE 1: AJAX handlers for player drill-through**
        add_action('wp_ajax_poker_get_player_details', array($this, 'ajax_get_player_details'));
        add_action('wp_ajax_nopriv_poker_get_player_details', array($this, 'ajax_get_player_details'));

        // AJAX handlers for statistics refresh
        add_action('wp_ajax_poker_refresh_statistics', array($this, 'ajax_refresh_statistics'));

        // AJAX handlers for data mart cleaner
        add_action('wp_ajax_poker_clean_data_mart', array($this, 'ajax_clean_data_mart'));

        // AJAX handlers for tournament chronology reconstruction
        add_action('wp_ajax_poker_reconstruct_chronology', array($this, 'ajax_reconstruct_chronology'));
        add_action('wp_ajax_poker_upload_tdt_for_tournament', array($this, 'ajax_upload_tdt_for_tournament'));

        // AJAX handlers for enhanced data mart cleaning
        add_action('wp_ajax_poker_clean_statistics_enhanced', array($this, 'ajax_clean_statistics_enhanced'));
        add_action('wp_ajax_poker_clean_financial_enhanced', array($this, 'ajax_clean_financial_enhanced'));
        add_action('wp_ajax_poker_clean_player_data_enhanced', array($this, 'ajax_clean_player_data_enhanced'));
        add_action('wp_ajax_poker_clean_analytics_enhanced', array($this, 'ajax_clean_analytics_enhanced'));
        add_action('wp_ajax_poker_clean_options_enhanced', array($this, 'ajax_clean_options_enhanced'));
        add_action('wp_ajax_poker_clean_all_enhanced', array($this, 'ajax_clean_all_enhanced'));
        add_action('wp_ajax_poker_get_cleaning_status', array($this, 'ajax_get_cleaning_status'));

        // Hook into tournament creation and updates
        add_action('save_post_tournament', array($this, 'on_tournament_save'), 10, 3);
        add_action('wp_trash_post', array($this, 'on_tournament_delete'));
        add_action('untrash_post', array($this, 'on_tournament_restore'));

        // Hook for asynchronous statistics refresh
        add_action('poker_refresh_statistics_async', array($this, 'async_refresh_statistics'));
    }

    /**
     * Check for plugin update and refresh statistics if needed
     */
    private function check_plugin_update() {
        $last_version = get_option('poker_import_last_version', '0');

        if ($last_version !== POKER_TOURNAMENT_IMPORT_VERSION) {
            // Plugin was updated, force refresh statistics
            error_log("Poker Import: Plugin updated from {$last_version} to " . POKER_TOURNAMENT_IMPORT_VERSION . ", refreshing statistics");

            if (class_exists('Poker_Statistics_Engine')) {
                $stats_engine = Poker_Statistics_Engine::get_instance();
                $result = $stats_engine->calculate_all_statistics();

                if ($result) {
                    error_log("Poker Import: Statistics refreshed successfully after plugin update");
                    update_option('poker_statistics_last_refresh', current_time('mysql'));
                } else {
                    error_log("Poker Import: Failed to refresh statistics after plugin update");
                }

                // **v2.4.34: ONE-TIME MIGRATION** - Populate ROI table if empty
                global $wpdb;
                $roi_table = $wpdb->prefix . 'poker_player_roi';
                $roi_count = $wpdb->get_var("SELECT COUNT(*) FROM $roi_table");

                if ($roi_count == 0) {
                    error_log("ROI Migration: ROI table is empty, triggering migration");
                    $migration_result = $stats_engine->migrate_populate_roi_table();

                    if ($migration_result['success']) {
                        error_log("ROI Migration: SUCCESS - {$migration_result['records_created']} records created from {$migration_result['tournaments_processed']} tournaments");
                        update_option('poker_roi_migration_complete', POKER_TOURNAMENT_IMPORT_VERSION);
                    } else {
                        error_log("ROI Migration: FAILED - See previous log entries for details");
                    }
                } else {
                    error_log("ROI Migration: Skipped - ROI table already has {$roi_count} records");
                }
            }

            // Update the stored version
            update_option('poker_import_last_version', POKER_TOURNAMENT_IMPORT_VERSION);
        }
    }

    /**
     * Load plugin text domain
     */
    private function load_textdomain() {
        load_plugin_textdomain(
            'poker-tournament-import',
            false,
            dirname(plugin_basename(__FILE__)) . '/languages'
        );
    }

    /**
     * Enqueue frontend styles and scripts
     */
    public function enqueue_frontend_assets() {
        // CRITICAL: Double-check we're not in admin - prevent frontend scripts from loading in dashboard
        if (is_admin()) {
            return;
        }

        wp_enqueue_style(
            'poker-tournament-import-frontend',
            POKER_TOURNAMENT_IMPORT_PLUGIN_URL . 'assets/css/frontend.css',
            array(),
            POKER_TOURNAMENT_IMPORT_VERSION
        );

        wp_enqueue_script(
            'poker-tournament-import-frontend',
            POKER_TOURNAMENT_IMPORT_PLUGIN_URL . 'assets/js/frontend.js',
            array('jquery'),
            POKER_TOURNAMENT_IMPORT_VERSION,
            true
        );

        // Localize script with nonce and other data
        // IMPORTANT: Use pokerImportFrontend to avoid collision with admin pokerImport
        wp_localize_script(
            'poker-tournament-import-frontend',
            'pokerImportFrontend',
            array(
                'nonce' => wp_create_nonce('poker_series_tab_content'),
                'loadMoreNonce' => wp_create_nonce('poker_series_load_more'),
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'messages' => array(
                    'tabError' => __('Error loading content. Please try again.', 'poker-tournament-import'),
                    'loadMoreError' => __('Error loading more results. Please try again.', 'poker-tournament-import')
                )
            )
        );
    }

    /**
     * Include required files
     */
    private function includes() {
        // v2.4.9: AST-based TDT Parser (replaces regex-based extraction)
        require_once POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'includes/class-tdt-lexer.php';
        require_once POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'includes/class-tdt-ast-parser.php';
        require_once POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'includes/class-tdt-domain-mapper.php';

        require_once POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'includes/class-parser.php';
        require_once POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'includes/class-post-types.php';
        require_once POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'includes/class-shortcodes.php';
        require_once POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'includes/class-debug.php';
        require_once POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'includes/class-formula-validator.php';
        require_once POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'includes/class-series-standings.php';
        require_once POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'includes/class-statistics-engine.php';
    }

    /**
     * Initialize custom post types
     */
    private function init_post_types() {
        $post_types = new Poker_Tournament_Import_Post_Types();
        $post_types->register();
    }

    /**
     * Initialize custom taxonomies
     */
    private function init_taxonomies() {
        // Load and initialize the taxonomy class
        require_once POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'includes/class-taxonomies.php';
        $this->taxonomies = new Poker_Tournament_Import_Taxonomies();
    }

    /**
     * Initialize formula validator
     */
    private function init_formula_validator() {
        $this->formula_validator = new Poker_Tournament_Formula_Validator();
    }

    /**
     * Initialize shortcodes
     */
    private function init_shortcodes() {
        new Poker_Tournament_Import_Shortcodes();
    }

    /**
     * Initialize statistics engine
     */
    private function init_statistics_engine() {
        $this->statistics_engine = Poker_Statistics_Engine::get_instance();
    }

    /**
     * Plugin activation
     */
    public function activate() {
        // Flush rewrite rules
        flush_rewrite_rules();

        // Create database tables if needed
        $this->create_database_tables();

        // Force statistics table creation and initial calculation
        $this->ensure_statistics_table_exists();

        // Initialize and calculate statistics
        if (class_exists('Poker_Statistics_Engine')) {
            $stats_engine = Poker_Statistics_Engine::get_instance();
            $stats_engine->calculate_all_statistics();
        }

        // Set version to force refresh on first load
        update_option('poker_import_last_version', POKER_TOURNAMENT_IMPORT_VERSION);
    }

    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Flush rewrite rules
        flush_rewrite_rules();
    }

    /**
     * Create custom database tables
     */
    private function create_database_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        // Table for tournament players
        $table_name = $wpdb->prefix . 'poker_tournament_players';
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            tournament_id varchar(100) NOT NULL,
            player_id varchar(100) NOT NULL,
            finish_position int NOT NULL,
            winnings decimal(10,2) DEFAULT 0,
            buyins int DEFAULT 1,
            rebuys int DEFAULT 0,
            addons int DEFAULT 0,
            hits int DEFAULT 0,
            points decimal(10,2) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY tournament_id (tournament_id),
            KEY player_id (player_id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        // Table for dashboard statistics (data mart)
        $stats_table_name = $wpdb->prefix . 'poker_statistics';
        $stats_sql = "CREATE TABLE $stats_table_name (
            stat_id mediumint(9) NOT NULL AUTO_INCREMENT,
            stat_name varchar(100) NOT NULL,
            stat_value decimal(20,2) NOT NULL,
            stat_type enum('count', 'sum', 'average', 'latest') NOT NULL DEFAULT 'count',
            last_updated timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            calculation_date date DEFAULT NULL,
            related_id int DEFAULT NULL,
            PRIMARY KEY  (stat_id),
            UNIQUE KEY stat_name (stat_name),
            KEY stat_type (stat_type),
            KEY last_updated (last_updated)
        ) $charset_collate;";

        dbDelta($stats_sql);

        // **PHASE 2.1: Financial Data Infrastructure Tables**

        // Table for tournament costs
        $costs_table_name = $wpdb->prefix . 'poker_tournament_costs';
        $costs_sql = "CREATE TABLE $costs_table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            tournament_id varchar(100) NOT NULL,
            cost_category varchar(50) NOT NULL COMMENT 'venue, staff, equipment, marketing, prize_pool, overhead',
            cost_amount decimal(10,2) NOT NULL DEFAULT 0,
            cost_description text,
            cost_date date DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY tournament_id (tournament_id),
            KEY cost_category (cost_category),
            KEY cost_date (cost_date)
        ) $charset_collate;";

        dbDelta($costs_sql);

        // Table for tournament financial summary (enhanced data mart)
        $financial_table_name = $wpdb->prefix . 'poker_financial_summary';
        $financial_sql = "CREATE TABLE $financial_table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            tournament_id varchar(100) NOT NULL,
            tournament_revenue decimal(12,2) NOT NULL DEFAULT 0 COMMENT 'Total revenue from buy-ins, rebuys, etc',
            tournament_costs decimal(12,2) NOT NULL DEFAULT 0 COMMENT 'Total operating costs',
            tournament_profit decimal(12,2) NOT NULL DEFAULT 0 COMMENT 'Revenue minus costs',
            tournament_roi_percentage decimal(5,2) DEFAULT 0 COMMENT 'ROI as percentage',
            prize_pool_efficiency decimal(5,2) DEFAULT 0 COMMENT 'Prize pool to revenue ratio',
            buy_in_amount decimal(10,2) DEFAULT 0 COMMENT 'Standardized buy-in amount',
            currency_code varchar(3) DEFAULT 'USD' COMMENT 'ISO currency code',
            currency_conversion_rate decimal(10,6) DEFAULT 1.000000 COMMENT 'Conversion rate to base currency',
            financial_data json DEFAULT NULL COMMENT 'Additional financial metrics as JSON',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY tournament_id (tournament_id),
            KEY tournament_roi (tournament_roi_percentage),
            KEY currency_code (currency_code),
            KEY created_at (created_at)
        ) $charset_collate;";

        dbDelta($financial_sql);

        // Table for player ROI tracking
        $player_roi_table_name = $wpdb->prefix . 'poker_player_roi';
        $player_roi_sql = "CREATE TABLE $player_roi_table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            player_id varchar(100) NOT NULL,
            tournament_id varchar(100) NOT NULL,
            total_invested decimal(10,2) NOT NULL DEFAULT 0 COMMENT 'Buy-ins + rebuys + addons',
            total_winnings decimal(10,2) NOT NULL DEFAULT 0 COMMENT 'Tournament winnings',
            net_profit decimal(10,2) NOT NULL DEFAULT 0 COMMENT 'Winnings minus invested',
            roi_percentage decimal(5,2) DEFAULT 0 COMMENT 'Return on investment percentage',
            finish_position int NOT NULL DEFAULT 0,
            tournament_date date DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY player_id (player_id),
            KEY tournament_id (tournament_id),
            KEY roi_percentage (roi_percentage),
            KEY tournament_date (tournament_date)
        ) $charset_collate;";

        dbDelta($player_roi_sql);

        // Table for revenue analytics (monthly aggregation)
        $revenue_analytics_table_name = $wpdb->prefix . 'poker_revenue_analytics';
        $revenue_analytics_sql = "CREATE TABLE $revenue_analytics_table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            analytics_period varchar(7) NOT NULL COMMENT 'YYYY-MM format',
            total_tournaments int NOT NULL DEFAULT 0,
            total_revenue decimal(12,2) NOT NULL DEFAULT 0,
            total_costs decimal(12,2) NOT NULL DEFAULT 0,
            total_profit decimal(12,2) NOT NULL DEFAULT 0,
            average_profit_per_tournament decimal(10,2) NOT NULL DEFAULT 0,
            total_players int NOT NULL DEFAULT 0,
            average_revenue_per_player decimal(10,2) NOT NULL DEFAULT 0,
            profit_margin_percentage decimal(5,2) DEFAULT 0,
            revenue_growth_percentage decimal(5,2) DEFAULT 0,
            currency_code varchar(3) DEFAULT 'USD',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY analytics_period (analytics_period),
            KEY profit_margin (profit_margin_percentage),
            KEY revenue_growth (revenue_growth_percentage),
            KEY currency_code (currency_code)
        ) $charset_collate;";

        dbDelta($revenue_analytics_sql);

        // Log successful table creation
        error_log("Poker Import: Phase 2.1 Financial tables created successfully");
    }

    /**
     * Ensure statistics table exists with proper error handling
     */
    private function ensure_statistics_table_exists() {
        global $wpdb;

        $stats_table_name = $wpdb->prefix . 'poker_statistics';
        $charset_collate = $wpdb->get_charset_collate();

        // Check if table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$stats_table_name}'");

        if (!$table_exists) {
            error_log("Poker Statistics: Creating statistics table - it doesn't exist");

            // Create table directly
            $stats_sql = "CREATE TABLE {$stats_table_name} (
                stat_id mediumint(9) NOT NULL AUTO_INCREMENT,
                stat_name varchar(100) NOT NULL,
                stat_value decimal(20,2) NOT NULL,
                stat_type enum('count', 'sum', 'average', 'latest') NOT NULL DEFAULT 'count',
                last_updated timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                calculation_date date DEFAULT NULL,
                related_id int DEFAULT NULL,
                PRIMARY KEY  (stat_id),
                UNIQUE KEY stat_name (stat_name),
                KEY stat_type (stat_type),
                KEY last_updated (last_updated)
            ) {$charset_collate};";

            $result = $wpdb->query($stats_sql);

            if ($result === false) {
                error_log("Poker Statistics: Failed to create statistics table: " . $wpdb->last_error);
            } else {
                error_log("Poker Statistics: Statistics table created successfully");
            }
        } else {
            error_log("Poker Statistics: Statistics table already exists");
        }
    }

    /**
     * AJAX handler for series tab content
     */
    public function ajax_series_tab_content() {
        check_ajax_referer('poker_series_tab_content', 'nonce');

        $series_id = intval($_POST['series_id']);
        $tab = sanitize_text_field($_POST['tab']);

        if (!$series_id || !in_array($tab, array('overview', 'results', 'statistics', 'players'))) {
            wp_die('Invalid request');
        }

        // Output the appropriate shortcode content
        $shortcode = '[series_' . $tab . ' id="' . $series_id . '"]';
        echo do_shortcode($shortcode);
        wp_die();
    }

    /**
     * AJAX handler for loading more series results
     */
    public function ajax_series_load_more() {
        check_ajax_referer('poker_series_load_more', 'nonce');

        $series_id = intval($_POST['series_id']);
        $offset = intval($_POST['offset']);
        $limit = intval($_POST['limit']);

        if (!$series_id) {
            wp_die('Invalid request');
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'poker_tournament_players';

        // Get tournaments for this series
        $series_tournaments = get_posts(array(
            'post_type' => 'tournament',
            'meta_key' => '_series_id',
            'meta_value' => $series_id,
            'posts_per_page' => $limit,
            'offset' => $offset,
            'orderby' => 'date',
            'order' => 'DESC'
        ));

        ob_start();

        if (!empty($series_tournaments)) {
            foreach ($series_tournaments as $tournament):
                $tournament_uuid = get_post_meta($tournament->ID, 'tournament_uuid', true);
                $players_count = get_post_meta($tournament->ID, '_players_count', true);
                $prize_pool = get_post_meta($tournament->ID, '_prize_pool', true);
                $tournament_date = get_post_meta($tournament->ID, '_tournament_date', true);
                $currency = get_post_meta($tournament->ID, '_currency', true) ?: '$';

                // Get winner
                $winner_name = '';
                if ($tournament_uuid) {
                    $winner = $wpdb->get_row($wpdb->prepare(
                        "SELECT p.post_title
                         FROM $table_name tp
                         LEFT JOIN {$wpdb->postmeta} pm ON pm.meta_value = tp.player_id AND pm.meta_key = 'player_uuid'
                         LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
                         WHERE tp.tournament_id = %s AND tp.finish_position = 1
                         LIMIT 1",
                        $tournament_uuid
                    ));
                    if ($winner) $winner_name = $winner->post_title;
                }
                ?>
                <tr>
                    <td class="tournament-name">
                        <a href="<?php echo get_permalink($tournament->ID); ?>">
                            <?php echo esc_html($tournament->post_title); ?>
                        </a>
                    </td>
                    <td class="tournament-date">
                        <?php echo $tournament_date ? esc_html(date_i18n('M j, Y', strtotime($tournament_date))) : esc_html(get_the_date('M j, Y', $tournament->ID)); ?>
                    </td>
                    <td class="tournament-players"><?php echo esc_html($players_count ?: '--'); ?></td>
                    <td class="tournament-prize"><?php echo esc_html($currency . number_format(floatval($prize_pool ?: 0), 0)); ?></td>
                    <td class="tournament-winner">
                        <?php if ($winner_name): ?>
                            <a href="#" class="winner-link"><?php echo esc_html($winner_name); ?></a>
                        <?php else: ?>
                            --
                        <?php endif; ?>
                    </td>
                </tr>
                <?php
            endforeach;
        }

        $output = ob_get_clean();
        echo $output;
        wp_die();
    }

    /**
     * AJAX handler for formula validation
     */
    public function ajax_validate_formula() {
        check_ajax_referer('poker_formula_validator', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'poker-tournament-import'));
        }

        $formula = sanitize_textarea_field($_POST['formula']);
        $test_data = $_POST['test_data'];

        if (empty($formula)) {
            echo '<div class="error"><p>' . __('Formula cannot be empty.', 'poker-tournament-import') . '</p></div>';
            wp_die();
        }

        $validator = new Poker_Tournament_Formula_Validator();
        $validation = $validator->validate_formula($formula);

        // Prepare test data
        $prepared_data = array(
            'total_players' => intval($test_data['n'] ?? 20),
            'finish_position' => intval($test_data['r'] ?? 3),
            'hits' => intval($test_data['hits'] ?? 0),
            'total_money' => floatval($test_data['total_money'] ?? 2000),
            'total_buyins' => intval($test_data['total_buyins'] ?? 20),
            'total_buyins_amount' => floatval($test_data['total_money'] ?? 2000),
            'total_rebuys_amount' => 0,
            'total_addons_amount' => 0,
        );

        $calculation = $validator->calculate_formula($formula, $prepared_data);

        // Display results
        $output = '<div class="validation-results">';

        if ($validation['valid']) {
            $output .= '<div class="success"><p>✅ <strong>' . __('Formula is valid!', 'poker-tournament-import') . '</strong></p></div>';

            if (!empty($validation['warnings'])) {
                $output .= '<div class="warning"><p><strong>' . __('Warnings:', 'poker-tournament-import') . '</strong></p><ul>';
                foreach ($validation['warnings'] as $warning) {
                    $output .= '<li>' . esc_html($warning) . '</li>';
                }
                $output .= '</ul></div>';
            }

            if ($calculation['success']) {
                $output .= '<div class="calculation-result">';
                $output .= '<h4>' . __('Test Result:', 'poker-tournament-import') . '</h4>';
                $output .= '<p><strong>' . __('Calculated Points:', 'poker-tournament-import') . '</strong> ' . esc_html(number_format($calculation['result'], 2)) . '</p>';

                if (!empty($calculation['variables'])) {
                    $output .= '<h4>' . __('Variables Used:', 'poker-tournament-import') . '</h4>';
                    $output .= '<table class="wp-list-table widefat striped" style="max-width: 400px;">';
                    $output .= '<thead><tr><th>Variable</th><th>Value</th></tr></thead><tbody>';

                    $important_vars = array('n', 'r', 'hits', 'monies', 'avgBC', 'T33', 'T80', 'points');
                    foreach ($important_vars as $var) {
                        if (isset($calculation['variables'][$var])) {
                            $value = $calculation['variables'][$var];
                            if (is_float($value)) {
                                $value = number_format($value, 2);
                            }
                            $output .= '<tr><td><code>' . esc_html($var) . '</code></td><td>' . esc_html($value) . '</td></tr>';
                        }
                    }
                    $output .= '</tbody></table>';
                }
                $output .= '</div>';
            } else {
                $output .= '<div class="error"><p><strong>' . __('Calculation Error:', 'poker-tournament-import') . '</strong> ' . esc_html($calculation['error']) . '</p></div>';
            }
        } else {
            $output .= '<div class="error"><p><strong>' . __('Formula is invalid:', 'poker-tournament-import') . '</strong></p><ul>';
            foreach ($validation['errors'] as $error) {
                $output .= '<li>' . esc_html($error) . '</li>';
            }
            $output .= '</ul></div>';
        }

        $output .= '</div>';
        echo $output;
        wp_die();
    }

    /**
     * AJAX handler for saving formulas
     */
    public function ajax_save_formula() {
        check_ajax_referer('poker_formula_manager', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'poker-tournament-import'));
        }

        $name = sanitize_text_field($_POST['formula_name']);
        $formula_data = array(
            'name' => sanitize_text_field($_POST['display_name']),
            'description' => sanitize_textarea_field($_POST['description']),
            'formula' => sanitize_textarea_field(wp_unslash($_POST['formula'])),
            'dependencies' => sanitize_textarea_field(wp_unslash($_POST['dependencies'])),
            'category' => sanitize_text_field($_POST['category'])
        );

        $validator = new Poker_Tournament_Formula_Validator();
        $validation = $validator->validate_formula($formula_data['formula']);

        if (!$validation['valid']) {
            wp_send_json_error(array(
                'message' => __('Formula is invalid and cannot be saved.', 'poker-tournament-import'),
                'errors' => $validation['errors']
            ));
        }

        $validator->save_formula($name, $formula_data);
        wp_send_json_success(array(
            'message' => __('Formula saved successfully!', 'poker-tournament-import')
        ));
    }

    /**
     * AJAX handler for deleting formulas
     */
    public function ajax_delete_formula() {
        check_ajax_referer('poker_formula_manager', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'poker-tournament-import'));
        }

        $name = sanitize_text_field($_POST['formula_name']);
        $validator = new Poker_Tournament_Formula_Validator();

        if ($validator->delete_formula($name)) {
            wp_send_json_success(array(
                'message' => __('Formula deleted successfully!', 'poker-tournament-import')
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Formula not found or cannot be deleted.', 'poker-tournament-import')
            ));
        }
    }

    /**
     * AJAX handler for getting formula data
     */
    public function ajax_get_formula() {
        check_ajax_referer('poker_formula_manager', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'poker-tournament-import'));
        }

        $name = sanitize_text_field($_POST['formula_key']);
        $validator = new Poker_Tournament_Formula_Validator();
        $formula = $validator->get_formula($name);

        if ($formula) {
            // Check if this is a default formula
            $default_formulas = $validator->get_default_formulas();
            $formula['is_default'] = isset($default_formulas[$name]);

            wp_send_json_success($formula);
        } else {
            wp_send_json_error(array(
                'message' => __('Formula not found.', 'poker-tournament-import')
            ));
        }
    }

    /**
     * AJAX handler for exporting standings
     */
    public function ajax_export_standings() {
        check_ajax_referer('poker_export_standings', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'poker-tournament-import'));
        }

        $series_id = intval($_POST['series_id']);
        $formula_key = sanitize_text_field($_POST['formula']);

        $standings_calculator = new Poker_Series_Standings_Calculator();
        $csv_file = $standings_calculator->export_series_standings_csv($series_id, $formula_key);

        if ($csv_file && file_exists($csv_file)) {
            // Create download URL
            $upload_dir = wp_upload_dir();
            $relative_path = str_replace($upload_dir['basedir'], '', $csv_file);
            $download_url = $upload_dir['baseurl'] . $relative_path;
            $filename = basename($csv_file);

            wp_send_json_success(array(
                'download_url' => $download_url,
                'filename' => $filename
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Failed to generate CSV file.', 'poker-tournament-import')
            ));
        }
    }

    /**
     * AJAX handler for dashboard content loading
     */
    public function ajax_dashboard_load_content() {
        check_ajax_referer('poker_dashboard_nonce', 'nonce');

        $view = isset($_POST['view']) ? sanitize_text_field($_POST['view']) : 'overview';

        global $wpdb;
        $table_name = $wpdb->prefix . 'poker_tournament_players';

        ob_start();

        switch ($view) {
            case 'tournaments':
                $this->render_tournaments_tab_content();
                break;
            case 'players':
                $this->render_players_tab_content();
                break;
            case 'series':
                $this->render_series_tab_content();
                break;
            case 'analytics':
                $this->render_analytics_tab_content();
                break;
            default:
                echo '<div class="error">' . __('Unknown view', 'poker-tournament-import') . '</div>';
                break;
        }

        $content = ob_get_clean();

        wp_send_json_success(array('content' => $content));
    }

    /**
     * AJAX handler for dashboard detailed view
     */
    public function ajax_dashboard_detailed_view() {
        check_ajax_referer('poker_dashboard_nonce', 'nonce');

        $type = isset($_POST['type']) ? sanitize_text_field($_POST['type']) : '';

        ob_start();

        switch ($type) {
            case 'tournaments':
                $this->render_detailed_tournaments_view();
                break;
            case 'players':
                $this->render_detailed_players_view();
                break;
            case 'leaderboard':
                $this->render_detailed_leaderboard_view();
                break;
            case 'calendar':
                $this->render_calendar_view();
                break;
            default:
                echo '<div class="error">' . __('Unknown view type', 'poker-tournament-import') . '</div>';
                break;
        }

        $content = ob_get_clean();

        wp_send_json_success(array('content' => $content));
    }

    /**
     * AJAX handler for dashboard report generation
     */
    public function ajax_dashboard_generate_report() {
        check_ajax_referer('poker_dashboard_nonce', 'nonce');

        global $wpdb;
        $table_name = $wpdb->prefix . 'poker_tournament_players';

        // Generate CSV report
        $filename = 'poker-tournament-report-' . date('Y-m-d') . '.csv';
        $filepath = get_temp_dir() . $filename;

        $handle = fopen($filepath, 'w');

        // CSV headers
        fputcsv($handle, array(
            'Tournament Name',
            'Date',
            'Players',
            'Prize Pool',
            'Winner',
            'Winner Earnings'
        ));

        // Get tournament data
        $tournaments = get_posts(array(
            'post_type' => 'tournament',
            'posts_per_page' => -1,
            'orderby' => 'date',
            'order' => 'DESC'
        ));

        foreach ($tournaments as $tournament) {
            $tournament_uuid = get_post_meta($tournament->ID, 'tournament_uuid', true);
            $players_count = get_post_meta($tournament->ID, '_players_count', true);
            $prize_pool = get_post_meta($tournament->ID, '_prize_pool', true);
            $tournament_date = get_post_meta($tournament->ID, '_tournament_date', true);

            $winner_name = '';
            $winner_winnings = 0;

            if ($tournament_uuid) {
                $winner = $wpdb->get_row($wpdb->prepare(
                    "SELECT p.post_title as winner_name, tp.winnings as winner_winnings
                     FROM $table_name tp
                     LEFT JOIN {$wpdb->postmeta} pm ON pm.meta_value = tp.player_id AND pm.meta_key = '_player_uuid'
                     LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
                     WHERE tp.tournament_id = %s AND tp.finish_position = 1
                     LIMIT 1",
                    $tournament_uuid
                ));

                if ($winner) {
                    $winner_name = $winner->winner_name;
                    $winner_winnings = $winner->winner_winnings;
                }
            }

            fputcsv($handle, array(
                $tournament->post_title,
                $tournament_date ?: get_the_date('Y-m-d', $tournament->ID),
                $players_count ?: 0,
                $prize_pool ?: 0,
                $winner_name,
                $winner_winnings
            ));
        }

        fclose($handle);

        // Create download URL
        $upload_dir = wp_upload_dir();
        $report_dir = $upload_dir['basedir'] . '/poker-reports/';
        if (!file_exists($report_dir)) {
            wp_mkdir_p($report_dir);
        }

        $final_filepath = $report_dir . $filename;
        rename($filepath, $final_filepath);

        $download_url = $upload_dir['baseurl'] . '/poker-reports/' . $filename;

        wp_send_json_success(array(
            'download_url' => $download_url,
            'filename' => $filename
        ));
    }

    /**
     * Render tournaments tab content
     */
    private function render_tournaments_tab_content() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'poker_tournament_players';

        $tournaments = get_posts(array(
            'post_type' => 'tournament',
            'posts_per_page' => 20,
            'orderby' => 'date',
            'order' => 'DESC'
        ));

        echo '<div class="tournaments-detail-view">';
        echo '<h3>' . __('All Tournaments', 'poker-tournament-import') . '</h3>';

        if (!empty($tournaments)) {
            echo '<div class="tournaments-table-wrapper">';
            echo '<table class="widefat tournaments-table">';
            echo '<thead>';
            echo '<tr>';
            echo '<th>' . __('Tournament', 'poker-tournament-import') . '</th>';
            echo '<th>' . __('Date', 'poker-tournament-import') . '</th>';
            echo '<th>' . __('Players', 'poker-tournament-import') . '</th>';
            echo '<th>' . __('Prize Pool', 'poker-tournament-import') . '</th>';
            echo '<th>' . __('Winner', 'poker-tournament-import') . '</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';

            foreach ($tournaments as $tournament) {
                $tournament_uuid = get_post_meta($tournament->ID, 'tournament_uuid', true);
                $players_count = get_post_meta($tournament->ID, '_players_count', true);
                $prize_pool = get_post_meta($tournament->ID, '_prize_pool', true);
                $tournament_date = get_post_meta($tournament->ID, '_tournament_date', true);
                $currency = get_post_meta($tournament->ID, '_currency', true) ?: '$';

                // Get winner
                $winner_name = '';
                if ($tournament_uuid) {
                    $winner = $wpdb->get_row($wpdb->prepare(
                        "SELECT p.post_title as winner_name
                         FROM $table_name tp
                         LEFT JOIN {$wpdb->postmeta} pm ON pm.meta_value = tp.player_id AND pm.meta_key = 'player_uuid'
                         LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
                         WHERE tp.tournament_id = %s AND tp.finish_position = 1
                         LIMIT 1",
                        $tournament_uuid
                    ));
                    if ($winner) $winner_name = $winner->winner_name;
                }

                echo '<tr>';
                echo '<td><strong><a href="' . get_permalink($tournament->ID) . '">' . esc_html($tournament->post_title) . '</a></strong></td>';
                echo '<td>' . esc_html($tournament_date ? date_i18n('M j, Y', strtotime($tournament_date)) : get_the_date('M j, Y', $tournament->ID)) . '</td>';
                echo '<td>' . esc_html($players_count ?: '--') . '</td>';
                echo '<td>' . esc_html($currency . number_format($prize_pool ?: 0, 0)) . '</td>';
                echo '<td>' . ($winner_name ? '<a href="#">' . esc_html($winner_name) . '</a>' : '--') . '</td>';
                echo '</tr>';
            }

            echo '</tbody>';
            echo '</table>';
            echo '</div>';
        } else {
            echo '<p>' . __('No tournaments found.', 'poker-tournament-import') . '</p>';
        }

        echo '</div>';
    }

    /**
     * Render players tab content
     */
    private function render_players_tab_content() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'poker_tournament_players';

        $top_players = $wpdb->get_results($wpdb->prepare(
            "SELECT tp.player_id,
                    COUNT(*) as tournaments_played,
                    SUM(tp.winnings) as total_winnings,
                    SUM(tp.points) as total_points,
                    MIN(tp.finish_position) as best_finish,
                    AVG(tp.finish_position) as avg_finish
             FROM $table_name tp
             GROUP BY tp.player_id
             ORDER BY total_winnings DESC, total_points DESC
             LIMIT 50"
        ));

        echo '<div class="players-detail-view">';
        echo '<h3>' . __('All Players', 'poker-tournament-import') . '</h3>';

        if (!empty($top_players)) {
            echo '<div class="players-table-wrapper">';
            echo '<table class="widefat players-table">';
            echo '<thead>';
            echo '<tr>';
            echo '<th>' . __('Player', 'poker-tournament-import') . '</th>';
            echo '<th>' . __('Tournaments', 'poker-tournament-import') . '</th>';
            echo '<th>' . __('Total Winnings', 'poker-tournament-import') . '</th>';
            echo '<th>' . __('Total Points', 'poker-tournament-import') . '</th>';
            echo '<th>' . __('Best Finish', 'poker-tournament-import') . '</th>';
            echo '<th>' . __('Avg Finish', 'poker-tournament-import') . '</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';

            foreach ($top_players as $index => $player) {
                $player_post = $wpdb->get_row($wpdb->prepare(
                    "SELECT p.ID, p.post_title
                     FROM {$wpdb->postmeta} pm
                     LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
                     WHERE pm.meta_key = 'player_uuid' AND pm.meta_value = %s
                     LIMIT 1",
                    $player->player_id
                ));

                $rank_class = '';
                if ($index === 0) $rank_class = 'gold';
                elseif ($index === 1) $rank_class = 'silver';
                elseif ($index === 2) $rank_class = 'bronze';

                echo '<tr class="' . esc_attr($rank_class) . '">';
                echo '<td>';
                if ($player_post) {
                    echo '<a href="' . get_permalink($player_post->ID) . '">' . esc_html($player_post->post_title) . '</a>';
                } else {
                    echo esc_html($player->player_id);
                }
                echo '</td>';
                echo '<td>' . esc_html($player->tournaments_played) . '</td>';
                echo '<td>$' . esc_html(number_format($player->total_winnings, 0)) . '</td>';
                echo '<td>' . esc_html(number_format($player->total_points, 1)) . '</td>';
                echo '<td>' . esc_html($player->best_finish) . get_ordinal_suffix($player->best_finish) . '</td>';
                echo '<td>' . esc_html(number_format($player->avg_finish, 1)) . '</td>';
                echo '</tr>';
            }

            echo '</tbody>';
            echo '</table>';
            echo '</div>';
        } else {
            echo '<p>' . __('No players found.', 'poker-tournament-import') . '</p>';
        }

        echo '</div>';
    }

    /**
     * Render series tab content
     */
    private function render_series_tab_content() {
        $series_list = get_posts(array(
            'post_type' => 'tournament_series',
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC'
        ));

        echo '<div class="series-detail-view">';
        echo '<h3>' . __('All Series', 'poker-tournament-import') . '</h3>';

        if (!empty($series_list)) {
            echo '<div class="series-grid">';
            foreach ($series_list as $series) {
                // Get tournament count
                $tournament_count = count(get_posts(array(
                    'post_type' => 'tournament',
                    'meta_key' => 'series_id',
                    'meta_value' => $series->ID,
                    'posts_per_page' => -1,
                    'fields' => 'ids'
                )));

                echo '<div class="series-card">';
                echo '<h4><a href="' . get_edit_post_link($series->ID) . '">' . esc_html($series->post_title) . '</a></h4>';
                echo '<p>' . sprintf(_n('%d tournament', '%d tournaments', $tournament_count, 'poker-tournament-import'), $tournament_count) . '</p>';
                echo '<div class="series-actions">';
                echo '[series_overview id="' . $series->ID . '"]';
                echo '</div>';
                echo '</div>';
            }
            echo '</div>';
        } else {
            echo '<p>' . __('No series found.', 'poker-tournament-import') . '</p>';
        }

        echo '</div>';
    }

    /**
     * Render analytics tab content
     */
    private function render_analytics_tab_content() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'poker_tournament_players';

        echo '<div class="analytics-detail-view">';
        echo '<h3>' . __('Tournament Analytics', 'poker-tournament-import') . '</h3>';

        // Prize pool distribution
        $prize_distribution = $wpdb->get_results(
            "SELECT
                CASE
                    WHEN prize_pool < 500 THEN '< $500'
                    WHEN prize_pool < 1000 THEN '$500-$1,000'
                    WHEN prize_pool < 2000 THEN '$1,000-$2,000'
                    WHEN prize_pool < 5000 THEN '$2,000-$5,000'
                    ELSE '> $5,000'
                END as prize_range,
                COUNT(*) as tournament_count
             FROM (
                 SELECT SUM(CAST(meta_value AS DECIMAL(10,2))) as prize_pool
                 FROM {$wpdb->postmeta}
                 WHERE meta_key = '_prize_pool'
                 GROUP BY post_id
             ) as prize_data
             GROUP BY prize_range
             ORDER BY MIN(prize_pool)"
        );

        echo '<div class="analytics-grid">';
        echo '<div class="analytics-card">';
        echo '<h4>' . __('Prize Pool Distribution', 'poker-tournament-import') . '</h4>';
        if (!empty($prize_distribution)) {
            echo '<div class="chart-container">';
            foreach ($prize_distribution as $range) {
                $percentage = 0;
                if (isset($total_tournaments)) {
                    $percentage = ($range->tournament_count / $total_tournaments) * 100;
                } else {
                    $total_tournaments = array_sum(array_column($prize_distribution, 'tournament_count'));
                    $percentage = ($range->tournament_count / $total_tournaments) * 100;
                }
                echo '<div class="chart-bar">';
                echo '<div class="chart-label">' . esc_html($range->prize_range) . '</div>';
                echo '<div class="chart-bar-container">';
                echo '<div class="chart-bar-fill" style="width: ' . esc_attr($percentage) . '%"></div>';
                echo '</div>';
                echo '<div class="chart-value">' . esc_html($range->tournament_count) . ' (' . esc_html(round($percentage)) . '%)</div>';
                echo '</div>';
            }
            echo '</div>';
        } else {
            echo '<p>' . __('No data available', 'poker-tournament-import') . '</p>';
        }
        echo '</div>';

        // Player participation trends
        echo '<div class="analytics-card">';
        echo '<h4>' . __('Player Participation', 'poker-tournament-import') . '</h4>';
        echo '<p>' . __('Analytics features coming soon', 'poker-tournament-import') . '</p>';
        echo '</div>';

        echo '</div>'; // analytics-grid
        echo '</div>'; // analytics-detail-view
    }

    /**
     * Render detailed tournaments view
     */
    private function render_detailed_tournaments_view() {
        echo '<div class="detailed-tournaments-view">';
        echo '<h3>' . __('Tournament Details', 'poker-tournament-import') . '</h3>';
        echo '<p>' . __('Detailed tournament analytics coming soon', 'poker-tournament-import') . '</p>';
        echo '</div>';
    }

    /**
     * Render detailed players view
     */
    private function render_detailed_players_view() {
        echo '<div class="detailed-players-view">';
        echo '<h3>' . __('Player Details', 'poker-tournament-import') . '</h3>';
        echo '<p>' . __('Detailed player analytics coming soon', 'poker-tournament-import') . '</p>';
        echo '</div>';
    }

    /**
     * Render detailed leaderboard view
     */
    private function render_detailed_leaderboard_view() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'poker_tournament_players';

        $leaderboard = $wpdb->get_results($wpdb->prepare(
            "SELECT tp.player_id,
                    COUNT(*) as tournaments_played,
                    SUM(tp.winnings) as total_winnings,
                    SUM(tp.points) as total_points,
                    MIN(tp.finish_position) as best_finish,
                    AVG(tp.finish_position) as avg_finish
             FROM $table_name tp
             GROUP BY tp.player_id
             ORDER BY total_winnings DESC, total_points DESC
             LIMIT 100"
        ));

        echo '<div class="detailed-leaderboard-view">';
        echo '<h3>' . __('Complete Leaderboard', 'poker-tournament-import') . '</h3>';

        if (!empty($leaderboard)) {
            echo '<div class="leaderboard-table-wrapper">';
            echo '<table class="widefat leaderboard-table">';
            echo '<thead>';
            echo '<tr>';
            echo '<th>' . __('Rank', 'poker-tournament-import') . '</th>';
            echo '<th>' . __('Player', 'poker-tournament-import') . '</th>';
            echo '<th>' . __('Tournaments', 'poker-tournament-import') . '</th>';
            echo '<th>' . __('Winnings', 'poker-tournament-import') . '</th>';
            echo '<th>' . __('Points', 'poker-tournament-import') . '</th>';
            echo '<th>' . __('Best Finish', 'poker-tournament-import') . '</th>';
            echo '<th>' . __('Avg Finish', 'poker-tournament-import') . '</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';

            foreach ($leaderboard as $index => $player) {
                $player_post = $wpdb->get_row($wpdb->prepare(
                    "SELECT p.ID, p.post_title
                     FROM {$wpdb->postmeta} pm
                     LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
                     WHERE pm.meta_key = 'player_uuid' AND pm.meta_value = %s
                     LIMIT 1",
                    $player->player_id
                ));

                $rank_class = '';
                if ($index === 0) $rank_class = 'gold';
                elseif ($index === 1) $rank_class = 'silver';
                elseif ($index === 2) $rank_class = 'bronze';

                echo '<tr class="' . esc_attr($rank_class) . '">';
                echo '<td class="rank"><span class="rank-number">' . esc_html($index + 1) . '</span></td>';
                echo '<td>';
                if ($player_post) {
                    echo '<a href="' . get_permalink($player_post->ID) . '">' . esc_html($player_post->post_title) . '</a>';
                } else {
                    echo esc_html($player->player_id);
                }
                echo '</td>';
                echo '<td>' . esc_html($player->tournaments_played) . '</td>';
                echo '<td>$' . esc_html(number_format($player->total_winnings, 0)) . '</td>';
                echo '<td>' . esc_html(number_format($player->total_points, 1)) . '</td>';
                echo '<td>' . esc_html($player->best_finish) . get_ordinal_suffix($player->best_finish) . '</td>';
                echo '<td>' . esc_html(number_format($player->avg_finish, 1)) . '</td>';
                echo '</tr>';
            }

            echo '</tbody>';
            echo '</table>';
            echo '</div>';
        } else {
            echo '<p>' . __('No leaderboard data available', 'poker-tournament-import') . '</p>';
        }

        echo '</div>';
    }

    /**
     * Render calendar view
     */
    private function render_calendar_view() {
        echo '<div class="calendar-view">';
        echo '<h3>' . __('Tournament Calendar', 'poker-tournament-import') . '</h3>';
        echo '<p>' . __('Calendar view coming soon', 'poker-tournament-import') . '</p>';
        echo '</div>';
    }

    /**
     * **PHASE 1: AJAX handler for player details (drill-through)**
     */
    public function ajax_get_player_details() {
        check_ajax_referer('poker_player_details', 'nonce');

        $player_id = sanitize_text_field($_POST['player_id']);

        if (empty($player_id)) {
            wp_send_json_error(array(
                'message' => __('Player ID is required.', 'poker-tournament-import')
            ));
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'poker_tournament_players';

        // Get player statistics
        $player_stats = $wpdb->get_row($wpdb->prepare(
            "SELECT
                tp.player_id,
                COUNT(*) as tournaments_played,
                SUM(tp.winnings) as total_winnings,
                SUM(tp.points) as total_points,
                MIN(tp.finish_position) as best_finish,
                AVG(tp.finish_position) as avg_finish,
                SUM(tp.buyins) as total_buyins,
                MAX(tp.winnings) as highest_payout
             FROM {$table_name} tp
             WHERE tp.player_id = %s
             GROUP BY tp.player_id",
            $player_id
        ));

        if (!$player_stats) {
            wp_send_json_error(array(
                'message' => __('Player not found.', 'poker-tournament-import')
            ));
        }

        // Get player name from WordPress posts
        $player_post = $wpdb->get_row($wpdb->prepare(
            "SELECT p.ID, p.post_title
             FROM {$wpdb->postmeta} pm
             LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
             WHERE pm.meta_key = 'player_uuid' AND pm.meta_value = %s
             LIMIT 1",
            $player_id
        ));

        $player_name = $player_post ? $player_post->post_title : $player_id;

        // Get recent tournament results for this player
        $recent_tournaments = $wpdb->get_results($wpdb->prepare(
            "SELECT
                tp.finish_position,
                tp.winnings,
                tp.points,
                p.post_title as tournament_name,
                p.post_date as tournament_date,
                pm.meta_value as tournament_date_meta
             FROM {$table_name} tp
             LEFT JOIN {$wpdb->postmeta} pm2 ON pm2.meta_value = tp.tournament_id AND pm2.meta_key = 'tournament_uuid'
             LEFT JOIN {$wpdb->posts} p ON pm2.post_id = p.ID
             LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_tournament_date'
             WHERE tp.player_id = %s
             ORDER BY p.post_date DESC, tp.finish_position ASC
             LIMIT 10",
            $player_id
        ));

        // Format recent tournaments data
        $formatted_tournaments = array();
        foreach ($recent_tournaments as $tournament) {
            $formatted_tournaments[] = array(
                'tournament_name' => $tournament->tournament_name,
                'finish_position' => intval($tournament->finish_position),
                'winnings' => floatval($tournament->winnings),
                'points' => floatval($tournament->points),
                'tournament_date' => $tournament->tournament_date_meta ?: $tournament->tournament_date
            );
        }

        // Prepare response data
        $player_data = array(
            'player_id' => $player_id,
            'player_name' => $player_name,
            'player_post_id' => $player_post ? $player_post->ID : null,
            'tournaments_played' => intval($player_stats->tournaments_played),
            'total_winnings' => floatval($player_stats->total_winnings),
            'total_points' => floatval($player_stats->total_points),
            'best_finish' => intval($player_stats->best_finish),
            'avg_finish' => floatval($player_stats->avg_finish),
            'total_buyins' => intval($player_stats->total_buyins),
            'highest_payout' => floatval($player_stats->highest_payout),
            'recent_tournaments' => $formatted_tournaments
        );

        wp_send_json_success(array('data' => $player_data));
    }

    /**
     * AJAX handler for statistics refresh
     */
    public function ajax_refresh_statistics() {
        check_ajax_referer('poker_refresh_statistics', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'poker-tournament-import'));
        }

        $result = $this->statistics_engine->refresh_statistics();

        if ($result) {
            wp_send_json_success(array(
                'message' => __('Statistics refreshed successfully!', 'poker-tournament-import'),
                'timestamp' => current_time('mysql'),
                'stats' => $this->statistics_engine->get_dashboard_statistics()
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Failed to refresh statistics.', 'poker-tournament-import')
            ));
        }
    }

    /**
     * Handle tournament save/update - refresh statistics
     */
    public function on_tournament_save($post_id, $post, $update) {
        // Only refresh if not an auto-save and not a revision
        if (wp_is_post_revision($post_id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)) {
            return;
        }

        // Only act on tournament post type
        if ($post->post_type !== 'tournament') {
            return;
        }

        // Refresh statistics asynchronously to avoid blocking save
        wp_schedule_single_event(time(), 'poker_refresh_statistics_async', array($post_id));
    }

    /**
     * Handle tournament deletion - refresh statistics
     */
    public function on_tournament_delete($post_id) {
        $post = get_post($post_id);
        if ($post && $post->post_type === 'tournament') {
            // Refresh statistics asynchronously
            wp_schedule_single_event(time(), 'poker_refresh_statistics_async', array($post_id));
        }
    }

    /**
     * Handle tournament restoration - refresh statistics
     */
    public function on_tournament_restore($post_id) {
        $post = get_post($post_id);
        if ($post && $post->post_type === 'tournament') {
            // Refresh statistics asynchronously
            wp_schedule_single_event(time(), 'poker_refresh_statistics_async', array($post_id));
        }
    }

    /**
     * Asynchronous statistics refresh handler
     */
    public function async_refresh_statistics($tournament_id = null) {
        if (class_exists('Poker_Statistics_Engine')) {
            try {
                $stats_engine = Poker_Statistics_Engine::get_instance();
                $result = $stats_engine->calculate_all_statistics();

                if ($result) {
                    error_log("Poker Statistics: Async refresh completed for tournament {$tournament_id}");
                    update_option('poker_statistics_last_refresh', current_time('mysql'));
                } else {
                    error_log("Poker Statistics: Async refresh failed for tournament {$tournament_id}");
                }
            } catch (Exception $e) {
                error_log("Poker Statistics: Exception during async refresh: " . $e->getMessage());
            }
        }
    }

    /**
     * AJAX handler for data mart cleaning
     */
    public function ajax_clean_data_mart() {
        check_ajax_referer('poker_data_mart_cleaner', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'poker-tournament-import'));
        }

        $cleaning_type = isset($_POST['cleaning_type']) ? sanitize_text_field($_POST['cleaning_type']) : '';

        if (empty($cleaning_type)) {
            wp_send_json_error(array(
                'message' => __('Cleaning type is required.', 'poker-tournament-import')
            ));
        }

        $data_mart_cleaner = new Poker_Data_Mart_Cleaner();
        $result = false;
        $message = '';

        switch ($cleaning_type) {
            case 'statistics':
                $result = $data_mart_cleaner->clean_statistics_table();
                $message = $result ? __('Statistics cleaned successfully!', 'poker-tournament-import') : __('Failed to clean statistics.', 'poker-tournament-import');
                break;

            case 'financial':
                $result = $data_mart_cleaner->clean_financial_tables();
                $message = $result ? __('Financial data cleaned successfully!', 'poker-tournament-import') : __('Failed to clean financial data.', 'poker-tournament-import');
                break;

            case 'player_data':
                $result = $data_mart_cleaner->clean_player_data();
                $message = $result ? __('Player data cleaned successfully!', 'poker-tournament-import') : __('Failed to clean player data.', 'poker-tournament-import');
                break;

            case 'analytics':
                $result = $data_mart_cleaner->clean_analytics_tables();
                $message = $result ? __('Analytics cleaned successfully!', 'poker-tournament-import') : __('Failed to clean analytics.', 'poker-tournament-import');
                break;

            case 'options':
                $result = $data_mart_cleaner->clean_wordpress_options();
                $message = $result ? __('Options cleaned successfully!', 'poker-tournament-import') : __('Failed to clean options.', 'poker-tournament-import');
                break;

            case 'all':
                $result = $data_mart_cleaner->clean_all_data_mart();
                $message = $result ? __('All data mart cleaned successfully!', 'poker-tournament-import') : __('Failed to clean data mart.', 'poker-tournament-import');
                break;

            case 'reset_all':
                $result = $data_mart_cleaner->reset_all_plugin_data();
                $message = $result ? __('Complete reset successful!', 'poker-tournament-import') : __('Failed to reset plugin data.', 'poker-tournament-import');
                break;

            default:
                wp_send_json_error(array(
                    'message' => __('Invalid cleaning type.', 'poker-tournament-import')
                ));
                break;
        }

        if ($result) {
            wp_send_json_success(array(
                'message' => $message,
                'stats' => $data_mart_cleaner->get_data_mart_stats()
            ));
        } else {
            wp_send_json_error(array(
                'message' => $message
            ));
        }
    }

    /**
     * AJAX handler for chronological reconstruction
     */
    public function ajax_reconstruct_chronology() {
        check_ajax_referer('poker_series_tab_content', 'nonce');

        $tournament_id = intval($_POST['tournament_id']);

        if (empty($tournament_id)) {
            wp_send_json_error(array(
                'message' => __('Tournament ID is required.', 'poker-tournament-import')
            ));
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'poker_tournament_players';
        $tournament_uuid = get_post_meta($tournament_id, 'tournament_uuid', true);

        if (!$tournament_uuid) {
            wp_send_json_error(array(
                'message' => __('Tournament UUID not found.', 'poker-tournament-import')
            ));
        }

        // Get current player data
        $players = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name WHERE tournament_id = %s ORDER BY finish_position ASC",
            $tournament_uuid
        ));

        if (empty($players)) {
            wp_send_json_error(array(
                'message' => __('No player data found for this tournament.', 'poker-tournament-import')
            ));
        }

        // Apply chronological reconstruction algorithm
        $reconstructed_players = $this->reconstruct_chronological_order($players);

        if ($reconstructed_players) {
            // Update database with new chronological order
            foreach ($reconstructed_players as $index => $player) {
                $new_finish_position = $index + 1;
                $wpdb->update(
                    $table_name,
                    array('finish_position' => $new_finish_position),
                    array('id' => $player->id),
                    array('%d'),
                    array('%d')
                );
            }

            // Mark tournament as chronologically processed
            update_post_meta($tournament_id, '_chronologically_processed', true);
            update_post_meta($tournament_id, '_chronological_processing_date', current_time('mysql'));

            wp_send_json_success(array(
                'message' => __('Tournament has been successfully updated with chronological order!', 'poker-tournament-import')
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Chronological reconstruction failed. Please upload the original .tdt file.', 'poker-tournament-import')
            ));
        }
    }

    /**
     * AJAX handler for TDT file upload for existing tournament
     */
    public function ajax_upload_tdt_for_tournament() {
        check_ajax_referer('poker_series_tab_content', 'nonce');

        $tournament_id = intval($_POST['tournament_id']);

        if (empty($tournament_id)) {
            wp_send_json_error(array(
                'message' => __('Tournament ID is required.', 'poker-tournament-import')
            ));
        }

        if (!isset($_FILES['tdt_file']) || $_FILES['tdt_file']['error'] !== UPLOAD_ERR_OK) {
            wp_send_json_error(array(
                'message' => __('File upload failed. Please try again.', 'poker-tournament-import')
            ));
        }

        $file = $_FILES['tdt_file'];

        // Validate file type
        $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if ($file_extension !== 'tdt') {
            wp_send_json_error(array(
                'message' => __('Invalid file type. Please upload a .tdt file.', 'poker-tournament-import')
            ));
        }

        // Read file content
        $file_content = file_get_contents($file['tmp_name']);
        if ($file_content === false) {
            wp_send_json_error(array(
                'message' => __('Failed to read uploaded file.', 'poker-tournament-import')
            ));
        }

        // Parse the TDT file
        try {
            $parser = new Poker_Tournament_Parser();
            $tournament_data = $parser->parse_content($file_content);

            if (!$tournament_data || empty($tournament_data['players'])) {
                wp_send_json_error(array(
                    'message' => __('Invalid or empty TDT file.', 'poker-tournament-import')
                ));
            }

            // Store raw TDT content for real-time processing
            update_post_meta($tournament_id, '_tournament_raw_content', $file_content);

            // Get tournament UUID
            $tournament_uuid = get_post_meta($tournament_id, 'tournament_uuid', true);
            if (!$tournament_uuid) {
                $tournament_uuid = $tournament_data['metadata']['uuid'] ?? uniqid('tournament_');
                update_post_meta($tournament_id, 'tournament_uuid', $tournament_uuid);
            }

            // Update player data with chronological order from TDT
            global $wpdb;
            $table_name = $wpdb->prefix . 'poker_tournament_players';

            // Clear existing player data for this tournament
            $wpdb->delete(
                $table_name,
                array('tournament_id' => $tournament_uuid),
                array('%s')
            );

            // Insert updated player data in chronological order
            foreach ($tournament_data['players'] as $index => $player) {
                $wpdb->insert(
                    $table_name,
                    array(
                        'tournament_id' => $tournament_uuid,
                        'player_id' => $player['id'],
                        'finish_position' => $index + 1,
                        'winnings' => $player['winnings'] ?? 0,
                        'buyins' => $player['buyins'] ?? 1,
                        'rebuys' => $player['rebuys'] ?? 0,
                        'addons' => $player['addons'] ?? 0,
                        'hits' => $player['hits'] ?? 0,
                        'points' => $player['points'] ?? 0,
                    ),
                    array('%s', '%s', '%d', '%f', '%d', '%d', '%d', '%d', '%f')
                );
            }

            // Mark tournament as chronologically processed
            update_post_meta($tournament_id, '_chronologically_processed', true);
            update_post_meta($tournament_id, '_chronological_processing_date', current_time('mysql'));
            update_post_meta($tournament_id, '_tdt_file_uploaded', true);

            wp_send_json_success(array(
                'message' => __('Tournament has been successfully updated with chronological order from the .tdt file!', 'poker-tournament-import')
            ));

        } catch (Exception $e) {
            wp_send_json_error(array(
                'message' => __('Error parsing TDT file: ', 'poker-tournament-import') . $e->getMessage()
            ));
        }
    }

    /**
     * Reconstruct chronological order from buy-in data
     */
    private function reconstruct_chronological_order($players) {
        if (empty($players)) {
            return null;
        }

        // Advanced algorithm to reconstruct elimination order
        // Sort by multiple criteria to approximate chronological order

        // Primary sort: by winnings (descending - higher winnings = lasted longer)
        usort($players, function($a, $b) {
            // First compare winnings
            $winnings_diff = floatval($b->winnings) - floatval($a->winnings);
            if (abs($winnings_diff) > 0.01) {
                return $winnings_diff > 0 ? 1 : -1;
            }

            // Secondary sort: by points (descending)
            $points_diff = floatval($b->points) - floatval($a->points);
            if (abs($points_diff) > 0.01) {
                return $points_diff > 0 ? 1 : -1;
            }

            // Tertiary sort: by total buyins (descending - more buyins = played longer)
            $buyins_diff = ($b->buyins + $b->rebuys + $b->addons) - ($a->buyins + $a->rebuys + $a->addons);
            if ($buyins_diff !== 0) {
                return $buyins_diff > 0 ? 1 : -1;
            }

            // Final sort: keep original order as last resort
            return $a->finish_position - $b->finish_position;
        });

        // Validate the reconstructed order makes sense
        if ($this->is_valid_chronological_order($players)) {
            return $players;
        } else {
            return null;
        }
    }

    /**
     * Validate if the reconstructed order is logical
     */
    private function is_valid_chronological_order($players) {
        if (empty($players) || count($players) < 2) {
            return true;
        }

        // Basic validation: winner should have highest winnings
        $winner = $players[0];
        foreach (array_slice($players, 1) as $player) {
            if (floatval($player->winnings) > floatval($winner->winnings)) {
                return false;
            }
        }

        // Additional validation checks can be added here
        return true;
    }

    /**
     * Enhanced AJAX handler for statistics cleaning with real-time feedback
     */
    public function ajax_clean_statistics_enhanced() {
        check_ajax_referer('poker_data_mart_cleaner', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array(
                'message' => __('You do not have sufficient permissions to access this page.', 'poker-tournament-import')
            ));
        }

        $data_mart_cleaner = new Poker_Data_Mart_Cleaner();
        $result = $data_mart_cleaner->clean_statistics_table_enhanced();

        if ($result['success']) {
            wp_send_json_success(array(
                'message' => __('Statistics table cleaned successfully!', 'poker-tournament-import'),
                'records_removed' => $result['records_removed'],
                'verification' => $result['verification']
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Failed to clean statistics table.', 'poker-tournament-import'),
                'error' => $result['error']
            ));
        }
    }

    /**
     * Enhanced AJAX handler for financial data cleaning
     */
    public function ajax_clean_financial_enhanced() {
        check_ajax_referer('poker_data_mart_cleaner', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array(
                'message' => __('You do not have sufficient permissions to access this page.', 'poker-tournament-import')
            ));
        }

        $data_mart_cleaner = new Poker_Data_Mart_Cleaner();
        $result = $data_mart_cleaner->clean_financial_tables_enhanced();

        if ($result['success']) {
            wp_send_json_success(array(
                'message' => __('Financial data cleaned successfully!', 'poker-tournament-import'),
                'tables_cleaned' => $result['tables_cleaned'],
                'records_removed' => $result['total_records']
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Failed to clean financial data.', 'poker-tournament-import'),
                'errors' => $result['errors']
            ));
        }
    }

    /**
     * Enhanced AJAX handler for player data cleaning
     */
    public function ajax_clean_player_data_enhanced() {
        check_ajax_referer('poker_data_mart_cleaner', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array(
                'message' => __('You do not have sufficient permissions to access this page.', 'poker-tournament-import')
            ));
        }

        $data_mart_cleaner = new Poker_Data_Mart_Cleaner();
        $result = $data_mart_cleaner->clean_player_data_enhanced();

        if ($result['success']) {
            wp_send_json_success(array(
                'message' => __('Player data cleaned successfully!', 'poker-tournament-import'),
                'tables_cleaned' => $result['tables_cleaned'],
                'records_removed' => $result['total_records']
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Failed to clean player data.', 'poker-tournament-import'),
                'errors' => $result['errors']
            ));
        }
    }

    /**
     * Enhanced AJAX handler for analytics data cleaning
     */
    public function ajax_clean_analytics_enhanced() {
        check_ajax_referer('poker_data_mart_cleaner', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array(
                'message' => __('You do not have sufficient permissions to access this page.', 'poker-tournament-import')
            ));
        }

        $data_mart_cleaner = new Poker_Data_Mart_Cleaner();
        $result = $data_mart_cleaner->clean_analytics_tables_enhanced();

        if ($result['success']) {
            wp_send_json_success(array(
                'message' => __('Analytics data cleaned successfully!', 'poker-tournament-import'),
                'tables_cleaned' => $result['tables_cleaned'],
                'records_removed' => $result['total_records']
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Failed to clean analytics data.', 'poker-tournament-import'),
                'errors' => $result['errors']
            ));
        }
    }

    /**
     * Enhanced AJAX handler for options cleaning
     */
    public function ajax_clean_options_enhanced() {
        check_ajax_referer('poker_data_mart_cleaner', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array(
                'message' => __('You do not have sufficient permissions to access this page.', 'poker-tournament-import')
            ));
        }

        $data_mart_cleaner = new Poker_Data_Mart_Cleaner();
        $result = $data_mart_cleaner->clean_wordpress_options_enhanced();

        if ($result['success']) {
            wp_send_json_success(array(
                'message' => __('WordPress options cleaned successfully!', 'poker-tournament-import'),
                'options_cleaned' => $result['options_cleaned'],
                'total_options' => $result['total_options']
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Failed to clean WordPress options.', 'poker-tournament-import'),
                'errors' => $result['errors']
            ));
        }
    }

    /**
     * Enhanced AJAX handler for cleaning all data mart
     */
    public function ajax_clean_all_enhanced() {
        check_ajax_referer('poker_data_mart_cleaner', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array(
                'message' => __('You do not have sufficient permissions to access this page.', 'poker-tournament-import')
            ));
        }

        $data_mart_cleaner = new Poker_Data_Mart_Cleaner();
        $result = $data_mart_cleaner->clean_all_data_mart_enhanced();

        if ($result['success']) {
            wp_send_json_success(array(
                'message' => __('All data mart tables cleaned successfully!', 'poker-tournament-import'),
                'tables_cleaned' => $result['tables_cleaned'],
                'total_records' => $result['total_records']
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Some errors occurred during cleaning.', 'poker-tournament-import'),
                'errors' => $result['errors']
            ));
        }
    }

    /**
     * AJAX handler to get real-time cleaning status
     */
    public function ajax_get_cleaning_status() {
        check_ajax_referer('poker_data_mart_cleaner', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array(
                'message' => __('You do not have sufficient permissions to access this page.', 'poker-tournament-import')
            ));
        }

        $data_mart_cleaner = new Poker_Data_Mart_Cleaner();
        $status = $data_mart_cleaner->get_real_time_data_mart_status();

        wp_send_json_success($status);
    }

    /**
     * Load custom templates for our custom post types
     *
     * @param string $template The path to the template WordPress will load
     * @return string The modified template path
     */
    public function load_custom_templates($template) {
        // Check if this is a singular post of our custom post types
        if (is_singular('player')) {
            $custom_template = POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'templates/single-player.php';
            if (file_exists($custom_template)) {
                return $custom_template;
            }
        }

        if (is_singular('tournament')) {
            $custom_template = POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'templates/single-tournament.php';
            if (file_exists($custom_template)) {
                return $custom_template;
            }
        }

        if (is_singular('tournament_series')) {
            $custom_template = POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'templates/taxonomy-tournament_series.php';
            if (file_exists($custom_template)) {
                return $custom_template;
            }
        }

        if (is_singular('tournament_season')) {
            $custom_template = POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'templates/single-tournament_season.php';
            if (file_exists($custom_template)) {
                return $custom_template;
            }
        }

        if (is_post_type_archive('tournament')) {
            $custom_template = POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'templates/archive-tournament.php';
            if (file_exists($custom_template)) {
                return $custom_template;
            }
        }

        // Return original template if none of our conditions match
        return $template;
    }
}

/**
 * Global helper function for currency formatting
 * Accessible from both admin and frontend contexts
 *
 * @param float|int $amount The amount to format
 * @return string Formatted currency string with symbol
 */
if (!function_exists('poker_format_currency')) {
    function poker_format_currency($amount) {
        $symbol = get_option('poker_currency_symbol', '$');
        $position = get_option('poker_currency_position', 'prefix');

        // Format the amount with 2 decimal places
        $formatted_amount = number_format((float)$amount, 2, '.', ',');

        if ($position === 'postfix') {
            return $formatted_amount . $symbol;
        } else {
            return $symbol . $formatted_amount;
        }
    }
}

// Initialize the plugin
Poker_Tournament_Import::get_instance();