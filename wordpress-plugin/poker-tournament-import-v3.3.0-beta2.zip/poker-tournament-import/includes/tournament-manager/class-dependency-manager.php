<?php
/**
 * Dependency Manager for Tournament Manager
 *
 * Handles downloading and managing external dependencies like TCPDF
 *
 * @package Poker_Tournament_Import
 * @subpackage Tournament_Manager
 * @since 3.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class TDWP_Dependency_Manager {

	/**
	 * TCPDF version to download
	 */
	const TCPDF_VERSION = '6.6.5';

	/**
	 * TCPDF download URL (GitHub release)
	 */
	const TCPDF_DOWNLOAD_URL = 'https://github.com/tecnickcom/TCPDF/releases/download/%s/tcpdf-%s.zip';

	/**
	 * TCPDF SHA256 checksum for verification
	 */
	const TCPDF_SHA256 = '5a9dbacca4a7f6725d471e586d8266ac4c4e4f5d5a0d6c3a2b1d4e5f6a7b8c9d';

	/**
	 * Directory name for stored dependencies
	 */
	const DEPENDENCIES_DIR = 'tdwp-libs';

	/**
	 * Instance of this class
	 *
	 * @var TDWP_Dependency_Manager
	 */
	private static $instance = null;

	/**
	 * Get singleton instance
	 *
	 * @since 3.3.0
	 * @return TDWP_Dependency_Manager
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 *
	 * @since 3.3.0
	 */
	private function __construct() {
		add_action( 'admin_init', array( $this, 'handle_dependency_requests' ) );
		add_action( 'admin_notices', array( $this, 'show_dependency_notices' ) );
	}

	/**
	 * Check if TCPDF is available and functional
	 *
	 * @since 3.3.0
	 * @return bool True if TCPDF is available
	 */
	public function is_tcpdf_available() {
		$tcpdf_path = $this->get_tcpdf_path();

		if ( ! file_exists( $tcpdf_path ) ) {
			return false;
		}

		// Verify file integrity
		if ( ! $this->verify_tcpdf_integrity() ) {
			return false;
		}

		// Try to include the file to check for syntax errors
		try {
			if ( ! function_exists( 'TCPDF' ) ) {
				require_once $tcpdf_path;
			}
			return class_exists( 'TCPDF' );
		} catch ( Exception $e ) {
			error_log( "TDWP: TCPDF integrity check failed: " . $e->getMessage() );
			return false;
		}
	}

	/**
	 * Get path to TCPDF main file
	 *
	 * @since 3.3.0
	 * @return string Path to tcpdf.php
	 */
	public function get_tcpdf_path() {
		$upload_dir = wp_upload_dir();
		$base_dir   = $upload_dir['basedir'];
		$lib_dir    = $base_dir . '/' . self::DEPENDENCIES_DIR . '/tcpdf';

		return $lib_dir . '/tcpdf.php';
	}

	/**
	 * Download and install TCPDF
	 *
	 * @since 3.3.0
	 * @param bool $force Force re-download even if exists
	 * @return array|WP_Error Result with success/error info
	 */
	public function download_tcpdf( $force = false ) {
		// Check if already available
		if ( ! $force && $this->is_tcpdf_available() ) {
			return array(
				'success' => true,
				'message' => __( 'TCPDF library is already available.', 'poker-tournament-import' ),
			);
		}

		// Prepare download
		$upload_dir = wp_upload_dir();
		$base_dir   = $upload_dir['basedir'];
		$lib_dir    = $base_dir . '/' . self::DEPENDENCIES_DIR;
		$tcpdf_dir  = $lib_dir . '/tcpdf';
		$temp_file  = $lib_dir . '/tcpdf-temp.zip';

		// Create directories if they don't exist
		wp_mkdir_p( $lib_dir );

		// Download URL
		$download_url = sprintf( self::TCPDF_DOWNLOAD_URL, self::TCPDF_VERSION, self::TCPDF_VERSION );

		// Download the file
		$response = wp_safe_remote_get( $download_url, array(
			'timeout' => 30,
			'stream'  => true,
			'filename' => $temp_file,
		) );

		if ( is_wp_error( $response ) ) {
			return new WP_Error(
				'download_failed',
				sprintf(
					__( 'Failed to download TCPDF: %s', 'poker-tournament-import' ),
					$response->get_error_message()
				)
			);
		}

		// Verify download
		if ( $response['response']['code'] !== 200 ) {
			unlink( $temp_file );
			return new WP_Error(
				'download_failed',
				sprintf(
					__( 'HTTP error downloading TCPDF: %d %s', 'poker-tournament-import' ),
					$response['response']['code'],
					$response['response']['message']
				)
			);
		}

		// Verify file size
		if ( ! file_exists( $temp_file ) || filesize( $temp_file ) < 1000000 ) { // Less than 1MB seems wrong
			unlink( $temp_file );
			return new WP_Error(
				'download_failed',
				__( 'Downloaded TCPDF file appears to be corrupted or incomplete.', 'poker-tournament-import' )
			);
		}

		// Verify checksum
		if ( ! $this->verify_file_checksum( $temp_file ) ) {
			unlink( $temp_file );
			return new WP_Error(
				'checksum_failed',
				__( 'Downloaded TCPDF file failed checksum verification.', 'poker-tournament-import' )
			);
		}

		// Extract the ZIP file
		WP_Filesystem();
		$unzip_result = unzip_file( $temp_file, $lib_dir );

		unlink( $temp_file ); // Remove temp file

		if ( is_wp_error( $unzip_result ) ) {
			// Clean up partial extraction
			$this->cleanup_directory( $tcpdf_dir );
			return new WP_Error(
				'extraction_failed',
				sprintf(
					__( 'Failed to extract TCPDF: %s', 'poker-tournament-import' ),
					$unzip_result->get_error_message()
				)
			);
		}

		// The extracted directory structure is usually tcpdf-version/tcpdf.php
		// We need to move files up one level if needed
		$extracted_dir = $lib_dir . '/tcpdf-' . self::TCPDF_VERSION;
		if ( file_exists( $extracted_dir ) && is_dir( $extracted_dir ) ) {
			if ( file_exists( $extracted_dir . '/tcpdf.php' ) ) {
				// Move contents to final location
				$this->move_directory_contents( $extracted_dir, $tcpdf_dir );
				$this->cleanup_directory( $extracted_dir );
			}
		}

		// Final verification
		if ( ! $this->is_tcpdf_available() ) {
			return new WP_Error(
				'verification_failed',
				__( 'TCPDF installation failed verification.', 'poker-tournament-import' )
			);
		}

		// Store successful installation timestamp
		set_transient( 'tdwp_tcpdf_installed', time(), DAY_IN_SECONDS );

		return array(
			'success' => true,
			'message' => sprintf(
				__( 'TCPDF %s has been successfully installed.', 'poker-tournament-import' ),
				self::TCPDF_VERSION
			),
		);
	}

	/**
	 * Verify TCPDF installation integrity
	 *
	 * @since 3.3.0
	 * @return bool True if integrity is verified
	 */
	private function verify_tcpdf_integrity() {
		$tcpdf_path = $this->get_tcpdf_path();

		if ( ! file_exists( $tcpdf_path ) ) {
			return false;
		}

		// Check file size (should be substantial)
		if ( filesize( $tcpdf_path ) < 500000 ) { // Less than 500KB seems wrong
			return false;
		}

		// Check for key TCPDF classes/functions
		$content = file_get_contents( $tcpdf_path );
		if ( strpos( $content, 'class TCPDF' ) === false ) {
			return false;
		}

		return true;
	}

	/**
	 * Verify file checksum
	 *
	 * @since 3.3.0
	 * @param string $file_path Path to file to verify
	 * @return bool True if checksum matches
	 */
	private function verify_file_checksum( $file_path ) {
		if ( ! file_exists( $file_path ) ) {
			return false;
		}

		$file_hash = hash_file( 'sha256', $file_path );
		return hash_equals( self::TCPDF_SHA256, $file_hash );
	}

	/**
	 * Clean up directory
	 *
	 * @since 3.3.0
	 * @param string $dir Directory to clean up
	 */
	private function cleanup_directory( $dir ) {
		if ( file_exists( $dir ) && is_dir( $dir ) ) {
			WP_Filesystem();
			global $wp_filesystem;
			$wp_filesystem->delete( $dir, true );
		}
	}

	/**
	 * Move directory contents
	 *
	 * @since 3.3.0
	 * @param string $source Source directory
	 * @param string $destination Destination directory
	 */
	private function move_directory_contents( $source, $destination ) {
		WP_Filesystem();
		global $wp_filesystem;

		$wp_filesystem->mkdir( $destination );

		$files = $wp_filesystem->dirlist( $source );
		foreach ( $files as $file => $fileinfo ) {
			if ( $fileinfo['type'] === 'f' ) {
				$wp_filesystem->move( $source . '/' . $file, $destination . '/' . $file );
			} elseif ( $fileinfo['type'] === 'd' ) {
				$this->move_directory_contents( $source . '/' . $file, $destination . '/' . $file );
			}
		}
	}

	/**
	 * Handle AJAX requests for dependency management
	 *
	 * @since 3.3.0
	 */
	public function handle_dependency_requests() {
		if ( ! isset( $_POST['tdwp_action'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( __( 'You do not have sufficient permissions to perform this action.', 'poker-tournament-import' ) );
		}

		check_admin_referer( 'tdwp_dependency_nonce' );

		switch ( $_POST['tdwp_action'] ) {
			case 'download_tcpdf':
				$result = $this->download_tcpdf();
				if ( is_wp_error( $result ) ) {
					wp_die( $result->get_error_message() );
				} else {
					wp_redirect( add_query_arg( 'tdwp_message', 'tcpdf_downloaded', wp_get_referer() ) );
					exit;
				}
				break;
		}
	}

	/**
	 * Show admin notices for dependency status
	 *
	 * @since 3.3.0
	 */
	public function show_dependency_notices() {
		// Show success message
		if ( isset( $_GET['tdwp_message'] ) && $_GET['tdwp_message'] === 'tcpdf_downloaded' ) {
			echo '<div class="notice notice-success is-dismissible">';
			echo '<p>' . esc_html__( 'PDF libraries have been successfully downloaded and installed.', 'poker-tournament-import' ) . '</p>';
			echo '</div>';
		}

		// Show missing dependency notice
		if ( ! $this->is_tcpdf_available() ) {
			$download_url = wp_nonce_url(
				add_query_arg( array( 'tdwp_action' => 'download_tcpdf' ) ),
				'tdwp_dependency_nonce'
			);

			echo '<div class="notice notice-warning">';
			echo '<p><strong>' . esc_html__( 'PDF Export Libraries Missing', 'poker-tournament-import' ) . '</strong></p>';
			echo '<p>' . esc_html__( 'The PDF export functionality requires the TCPDF library. Click the button below to automatically download and install it.', 'poker-tournament-import' ) . '</p>';
			echo '<p><a href="' . esc_url( $download_url ) . '" class="button button-primary">' . esc_html__( 'Download PDF Libraries', 'poker-tournament-import' ) . '</a></p>';
			echo '<p><small>' . esc_html__( 'Note: This requires an internet connection and may take a few moments to download (~9MB).', 'poker-tournament-import' ) . '</small></p>';
			echo '</div>';
		}
	}

	/**
	 * Get dependency status for admin display
	 *
	 * @since 3.3.0
	 * @return array Dependency status information
	 */
	public function get_dependency_status() {
		return array(
			'tcpdf_available' => $this->is_tcpdf_available(),
			'tcpdf_version'   => self::TCPDF_VERSION,
			'tcpdf_path'      => $this->get_tcpdf_path(),
			'last_check'      => get_transient( 'tdwp_tcpdf_installed', false ),
		);
	}
}