<?php
/**
 * Transaction Logger for Tournament Manager
 *
 * Provides immutable audit log for all tournament financial operations.
 * This class implements append-only pattern - no UPDATE or DELETE operations
 * are exposed to maintain complete audit trail for compliance.
 *
 * Transaction Types:
 * - bust_out: Player elimination with finish position
 * - rebuy: Player rebuy during rebuy period
 * - add_on: Player add-on during add-on period
 * - chip_adjustment: Manual chip count correction
 * - late_registration: Player registration after tournament start
 *
 * @package Poker_Tournament_Import
 * @subpackage Tournament_Manager
 * @since 3.2.0
 */

// Prevent direct file access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Transaction logger class
 *
 * @since 3.2.0
 */
class TDWP_Transaction_Logger {

	/**
	 * Valid transaction types
	 *
	 * @var array
	 */
	const VALID_TYPES = array(
		'bust_out',
		'rebuy',
		'add_on',
		'chip_adjustment',
		'late_registration',
	);

	/**
	 * Log a transaction to the immutable audit log
	 *
	 * This method performs an INSERT operation only. No UPDATE or DELETE
	 * operations are allowed to maintain audit trail integrity.
	 *
	 * @since 3.2.0
	 * @param int    $tournament_id    Tournament ID.
	 * @param int    $player_id        Player ID.
	 * @param string $transaction_type Transaction type (must be in VALID_TYPES).
	 * @param float  $amount           Financial amount (optional, default 0).
	 * @param int    $chips            Chip count change (optional, default 0).
	 * @param string $reason           Reason for transaction (required for chip_adjustment).
	 * @return int|false Transaction ID on success, false on failure
	 */
	public static function log_transaction( $tournament_id, $player_id, $transaction_type, $amount = 0, $chips = 0, $reason = '' ) {
		global $wpdb;

		// Validate inputs
		$tournament_id = absint( $tournament_id );
		$player_id     = absint( $player_id );
		$amount        = floatval( $amount );
		$chips         = intval( $chips );
		$reason        = sanitize_text_field( $reason );

		// Validate transaction type
		if ( ! in_array( $transaction_type, self::VALID_TYPES, true ) ) {
			error_log( sprintf( 'Invalid transaction type: %s', $transaction_type ) );
			return false;
		}

		// Chip adjustments require a reason
		if ( 'chip_adjustment' === $transaction_type && empty( $reason ) ) {
			error_log( 'Chip adjustment requires a reason' );
			return false;
		}

		// Get current user ID
		$actor_user_id = get_current_user_id();
		if ( ! $actor_user_id ) {
			error_log( 'Transaction requires authenticated user' );
			return false;
		}

		// Insert transaction record
		$table_name = $wpdb->prefix . 'tdwp_transactions';
		$result     = $wpdb->insert(
			$table_name,
			array(
				'tournament_id'    => $tournament_id,
				'player_id'        => $player_id,
				'transaction_type' => $transaction_type,
				'amount'           => $amount,
				'chips'            => $chips,
				'reason'           => $reason,
				'actor_user_id'    => $actor_user_id,
				'created_at'       => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%s', '%f', '%d', '%s', '%d', '%s' )
		);

		if ( false === $result ) {
			error_log( sprintf( 'Failed to log transaction: %s', $wpdb->last_error ) );
			return false;
		}

		$transaction_id = $wpdb->insert_id;

		/**
		 * Fires after a transaction is logged
		 *
		 * @since 3.2.0
		 * @param int    $transaction_id   Transaction ID.
		 * @param int    $tournament_id    Tournament ID.
		 * @param int    $player_id        Player ID.
		 * @param string $transaction_type Transaction type.
		 * @param float  $amount           Financial amount.
		 * @param int    $chips            Chip count change.
		 */
		do_action( 'tdwp_transaction_logged', $transaction_id, $tournament_id, $player_id, $transaction_type, $amount, $chips );

		return $transaction_id;
	}

	/**
	 * Get all transactions for a tournament
	 *
	 * @since 3.2.0
	 * @param int   $tournament_id Tournament ID.
	 * @param array $args {
	 *     Optional query arguments.
	 *
	 *     @type string $transaction_type Filter by transaction type.
	 *     @type int    $player_id        Filter by player ID.
	 *     @type string $order_by         Order by column (default 'created_at').
	 *     @type string $order            Order direction ASC|DESC (default 'DESC').
	 *     @type int    $limit            Limit number of results.
	 *     @type int    $offset           Offset for pagination.
	 * }
	 * @return array Array of transaction objects
	 */
	public static function get_tournament_transactions( $tournament_id, $args = array() ) {
		global $wpdb;

		$tournament_id = absint( $tournament_id );
		if ( ! $tournament_id ) {
			return array();
		}

		// Parse arguments
		$defaults = array(
			'transaction_type' => '',
			'player_id'        => 0,
			'order_by'         => 'created_at',
			'order'            => 'DESC',
			'limit'            => 0,
			'offset'           => 0,
		);
		$args     = wp_parse_args( $args, $defaults );

		// Build query
		$table_name = $wpdb->prefix . 'tdwp_transactions';
		$where      = array( $wpdb->prepare( 'tournament_id = %d', $tournament_id ) );

		// Add optional filters
		if ( ! empty( $args['transaction_type'] ) ) {
			$where[] = $wpdb->prepare( 'transaction_type = %s', $args['transaction_type'] );
		}

		if ( ! empty( $args['player_id'] ) ) {
			$where[] = $wpdb->prepare( 'player_id = %d', absint( $args['player_id'] ) );
		}

		$where_clause = 'WHERE ' . implode( ' AND ', $where );

		// Validate order by
		$valid_order_by = array( 'id', 'created_at', 'transaction_type', 'amount', 'chips' );
		$order_by       = in_array( $args['order_by'], $valid_order_by, true ) ? $args['order_by'] : 'created_at';

		// Validate order direction
		$order = 'DESC' === strtoupper( $args['order'] ) ? 'DESC' : 'ASC';

		// Build limit clause
		$limit_clause = '';
		if ( $args['limit'] > 0 ) {
			$limit_clause = $wpdb->prepare( 'LIMIT %d', absint( $args['limit'] ) );
			if ( $args['offset'] > 0 ) {
				$limit_clause .= $wpdb->prepare( ' OFFSET %d', absint( $args['offset'] ) );
			}
		}

		// Execute query
		$query = "SELECT * FROM {$table_name} {$where_clause} ORDER BY {$order_by} {$order} {$limit_clause}";

		return $wpdb->get_results( $query );
	}

	/**
	 * Get transaction count for a tournament
	 *
	 * @since 3.2.0
	 * @param int    $tournament_id    Tournament ID.
	 * @param string $transaction_type Optional transaction type filter.
	 * @return int Transaction count
	 */
	public static function get_transaction_count( $tournament_id, $transaction_type = '' ) {
		global $wpdb;

		$tournament_id = absint( $tournament_id );
		if ( ! $tournament_id ) {
			return 0;
		}

		$table_name = $wpdb->prefix . 'tdwp_transactions';
		$where      = array( $wpdb->prepare( 'tournament_id = %d', $tournament_id ) );

		if ( ! empty( $transaction_type ) ) {
			$where[] = $wpdb->prepare( 'transaction_type = %s', $transaction_type );
		}

		$where_clause = 'WHERE ' . implode( ' AND ', $where );
		$query        = "SELECT COUNT(*) FROM {$table_name} {$where_clause}";

		return (int) $wpdb->get_var( $query );
	}

	/**
	 * Get transactions grouped by type for a tournament
	 *
	 * Useful for statistics and reporting
	 *
	 * @since 3.2.0
	 * @param int $tournament_id Tournament ID.
	 * @return array Array of objects with transaction_type, count, total_amount, total_chips
	 */
	public static function get_transaction_summary( $tournament_id ) {
		global $wpdb;

		$tournament_id = absint( $tournament_id );
		if ( ! $tournament_id ) {
			return array();
		}

		$table_name = $wpdb->prefix . 'tdwp_transactions';
		$query      = $wpdb->prepare(
			"SELECT
				transaction_type,
				COUNT(*) as count,
				SUM(amount) as total_amount,
				SUM(chips) as total_chips
			FROM {$table_name}
			WHERE tournament_id = %d
			GROUP BY transaction_type",
			$tournament_id
		);

		return $wpdb->get_results( $query );
	}
}
