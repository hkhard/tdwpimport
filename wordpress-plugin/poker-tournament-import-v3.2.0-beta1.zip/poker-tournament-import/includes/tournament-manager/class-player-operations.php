<?php
/**
 * Player Operations for Tournament Manager
 *
 * Handles live tournament player operations:
 * - Player bust-outs with automatic ranking
 * - Rebuys during rebuy period
 * - Add-ons during add-on period
 * - Chip count adjustments with audit trail
 *
 * All operations are logged via TDWP_Transaction_Logger for compliance.
 *
 * @package Poker_Tournament_Import
 * @subpackage Tournament_Manager
 * @since 3.2.0
 */

// Prevent direct file access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Player operations class
 *
 * @since 3.2.0
 */
class TDWP_Player_Operations {

	/**
	 * Process player bust-out
	 *
	 * - Updates player status to 'busted'
	 * - Calculates and assigns finish position (remaining players count)
	 * - Logs transaction
	 * - Triggers table rebalancing
	 * - Updates tournament live state
	 *
	 * @since 3.2.0
	 * @param int $tournament_id Tournament ID.
	 * @param int $player_id     Player ID (tournament_players.id not player.id).
	 * @return array|WP_Error Success array or WP_Error on failure
	 */
	public static function process_bustout( $tournament_id, $player_id ) {
		global $wpdb;

		$tournament_id = absint( $tournament_id );
		$player_id     = absint( $player_id );

		// Validate inputs
		if ( ! $tournament_id || ! $player_id ) {
			return new WP_Error( 'invalid_params', __( 'Invalid tournament or player ID', 'poker-tournament-import' ) );
		}

		// Get player data
		$player_table = $wpdb->prefix . 'tdwp_tournament_players';
		$player       = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$player_table} WHERE id = %d AND tournament_id = %d", $player_id, $tournament_id )
		);

		if ( ! $player ) {
			return new WP_Error( 'player_not_found', __( 'Player not found in tournament', 'poker-tournament-import' ) );
		}

		if ( 'busted' === $player->status ) {
			return new WP_Error( 'already_busted', __( 'Player already busted', 'poker-tournament-import' ) );
		}

		// Get remaining players count to calculate finish position
		$live_state_table = $wpdb->prefix . 'tdwp_tournament_live_state';
		$remaining        = $wpdb->get_var(
			$wpdb->prepare( "SELECT remaining_players FROM {$live_state_table} WHERE tournament_id = %d", $tournament_id )
		);

		if ( null === $remaining ) {
			return new WP_Error( 'tournament_not_found', __( 'Tournament not found', 'poker-tournament-import' ) );
		}

		// Finish position = current remaining players (last place of remaining)
		$finish_position = absint( $remaining );

		// Update player status
		$updated = $wpdb->update(
			$player_table,
			array(
				'status'          => 'busted',
				'finish_position' => $finish_position,
				'chip_count'      => 0,
				'updated_at'      => current_time( 'mysql' ),
			),
			array( 'id' => $player_id ),
			array( '%s', '%d', '%d', '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			return new WP_Error( 'update_failed', __( 'Failed to update player status', 'poker-tournament-import' ) );
		}

		// Update live state: decrement remaining players, increment busted count
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$live_state_table}
				SET remaining_players = remaining_players - 1,
				    busted_players_count = busted_players_count + 1,
				    updated_at = %s
				WHERE tournament_id = %d",
				current_time( 'mysql' ),
				$tournament_id
			)
		);

		// Log transaction
		$transaction_id = TDWP_Transaction_Logger::log_transaction(
			$tournament_id,
			$player->player_id,
			'bust_out',
			0,
			- $player->chip_count,
			sprintf( 'Busted out in position %d', $finish_position )
		);

		/**
		 * Fires after player busts out
		 *
		 * @since 3.2.0
		 * @param int $tournament_id   Tournament ID.
		 * @param int $player_id       Player ID.
		 * @param int $finish_position Finish position.
		 */
		do_action( 'tdwp_player_bustout', $tournament_id, $player_id, $finish_position );

		// Trigger table rebalancing if table manager exists
		if ( class_exists( 'TDWP_Table_Balancer' ) ) {
			TDWP_Table_Balancer::trigger_rebalance( $tournament_id );
		}

		return array(
			'success'          => true,
			'finish_position'  => $finish_position,
			'remaining'        => $remaining - 1,
			'transaction_id'   => $transaction_id,
			'message'          => sprintf(
				/* translators: %d: finish position */
				__( 'Player busted out in position %d', 'poker-tournament-import' ),
				$finish_position
			),
		);
	}

	/**
	 * Process player rebuy
	 *
	 * - Validates rebuy period is active
	 * - Checks player eligibility (rebuy count < max)
	 * - Adds starting chips to player
	 * - Increments rebuy counter
	 * - Updates prize pool
	 * - Logs transaction
	 *
	 * @since 3.2.0
	 * @param int   $tournament_id Tournament ID.
	 * @param int   $player_id     Player ID (tournament_players.id).
	 * @param float $amount        Rebuy amount paid.
	 * @return array|WP_Error Success array or WP_Error on failure
	 */
	public static function process_rebuy( $tournament_id, $player_id, $amount ) {
		global $wpdb;

		$tournament_id = absint( $tournament_id );
		$player_id     = absint( $player_id );
		$amount        = floatval( $amount );

		// Validate inputs
		if ( ! $tournament_id || ! $player_id || $amount <= 0 ) {
			return new WP_Error( 'invalid_params', __( 'Invalid parameters for rebuy', 'poker-tournament-import' ) );
		}

		// Get player data
		$player_table = $wpdb->prefix . 'tdwp_tournament_players';
		$player       = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$player_table} WHERE id = %d AND tournament_id = %d", $player_id, $tournament_id )
		);

		if ( ! $player ) {
			return new WP_Error( 'player_not_found', __( 'Player not found', 'poker-tournament-import' ) );
		}

		// TODO: Add rebuy period validation (check tournament template settings)
		// For now, allow rebuys if tournament is running

		// Get starting chip count from tournament template
		// For now, use a default of 10000 (this should come from tournament settings)
		$chips_to_add = 10000;

		// Calculate new chip count
		$new_chip_count = $player->chip_count + $chips_to_add;

		// Update player
		$updated = $wpdb->update(
			$player_table,
			array(
				'chip_count'     => $new_chip_count,
				'rebuys_count'   => $player->rebuys_count + 1,
				'paid_amount'    => $player->paid_amount + $amount,
				'updated_at'     => current_time( 'mysql' ),
			),
			array( 'id' => $player_id ),
			array( '%d', '%d', '%f', '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			return new WP_Error( 'update_failed', __( 'Failed to process rebuy', 'poker-tournament-import' ) );
		}

		// Update live state: increment rebuy count and prize pool
		$live_state_table = $wpdb->prefix . 'tdwp_tournament_live_state';
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$live_state_table}
				SET total_rebuys = total_rebuys + 1,
				    prize_pool = prize_pool + %f,
				    updated_at = %s
				WHERE tournament_id = %d",
				$amount,
				current_time( 'mysql' ),
				$tournament_id
			)
		);

		// Log transaction
		$transaction_id = TDWP_Transaction_Logger::log_transaction(
			$tournament_id,
			$player->player_id,
			'rebuy',
			$amount,
			$chips_to_add,
			sprintf( 'Rebuy #%d', $player->rebuys_count + 1 )
		);

		/**
		 * Fires after rebuy is processed
		 *
		 * @since 3.2.0
		 * @param int   $tournament_id  Tournament ID.
		 * @param int   $player_id      Player ID.
		 * @param float $amount         Rebuy amount.
		 * @param int   $chips          Chips added.
		 */
		do_action( 'tdwp_player_rebuy', $tournament_id, $player_id, $amount, $chips_to_add );

		return array(
			'success'         => true,
			'chips_added'     => $chips_to_add,
			'new_chip_count'  => $new_chip_count,
			'rebuys_total'    => $player->rebuys_count + 1,
			'transaction_id'  => $transaction_id,
			'message'         => sprintf(
				/* translators: %d: chip count */
				__( 'Rebuy processed. Added %d chips.', 'poker-tournament-import' ),
				$chips_to_add
			),
		);
	}

	/**
	 * Process player add-on
	 *
	 * - Validates add-on timing (typically during break)
	 * - Adds add-on chips to player
	 * - Increments add-on counter
	 * - Updates prize pool
	 * - Logs transaction
	 *
	 * @since 3.2.0
	 * @param int   $tournament_id Tournament ID.
	 * @param int   $player_id     Player ID (tournament_players.id).
	 * @param float $amount        Add-on amount paid.
	 * @return array|WP_Error Success array or WP_Error on failure
	 */
	public static function process_addon( $tournament_id, $player_id, $amount ) {
		global $wpdb;

		$tournament_id = absint( $tournament_id );
		$player_id     = absint( $player_id );
		$amount        = floatval( $amount );

		// Validate inputs
		if ( ! $tournament_id || ! $player_id || $amount <= 0 ) {
			return new WP_Error( 'invalid_params', __( 'Invalid parameters for add-on', 'poker-tournament-import' ) );
		}

		// Get player data
		$player_table = $wpdb->prefix . 'tdwp_tournament_players';
		$player       = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$player_table} WHERE id = %d AND tournament_id = %d", $player_id, $tournament_id )
		);

		if ( ! $player ) {
			return new WP_Error( 'player_not_found', __( 'Player not found', 'poker-tournament-import' ) );
		}

		if ( 'busted' === $player->status ) {
			return new WP_Error( 'player_busted', __( 'Busted players cannot purchase add-ons', 'poker-tournament-import' ) );
		}

		// Get add-on chip count (default 10000, should come from tournament settings)
		$chips_to_add = 10000;

		// Calculate new chip count
		$new_chip_count = $player->chip_count + $chips_to_add;

		// Update player
		$updated = $wpdb->update(
			$player_table,
			array(
				'chip_count'     => $new_chip_count,
				'addons_count'   => $player->addons_count + 1,
				'paid_amount'    => $player->paid_amount + $amount,
				'updated_at'     => current_time( 'mysql' ),
			),
			array( 'id' => $player_id ),
			array( '%d', '%d', '%f', '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			return new WP_Error( 'update_failed', __( 'Failed to process add-on', 'poker-tournament-import' ) );
		}

		// Update live state: increment add-on count and prize pool
		$live_state_table = $wpdb->prefix . 'tdwp_tournament_live_state';
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$live_state_table}
				SET total_addons = total_addons + 1,
				    prize_pool = prize_pool + %f,
				    updated_at = %s
				WHERE tournament_id = %d",
				$amount,
				current_time( 'mysql' ),
				$tournament_id
			)
		);

		// Log transaction
		$transaction_id = TDWP_Transaction_Logger::log_transaction(
			$tournament_id,
			$player->player_id,
			'add_on',
			$amount,
			$chips_to_add,
			'Add-on purchase'
		);

		/**
		 * Fires after add-on is processed
		 *
		 * @since 3.2.0
		 * @param int   $tournament_id Tournament ID.
		 * @param int   $player_id     Player ID.
		 * @param float $amount        Add-on amount.
		 * @param int   $chips         Chips added.
		 */
		do_action( 'tdwp_player_addon', $tournament_id, $player_id, $amount, $chips_to_add );

		return array(
			'success'         => true,
			'chips_added'     => $chips_to_add,
			'new_chip_count'  => $new_chip_count,
			'addons_total'    => $player->addons_count + 1,
			'transaction_id'  => $transaction_id,
			'message'         => sprintf(
				/* translators: %d: chip count */
				__( 'Add-on processed. Added %d chips.', 'poker-tournament-import' ),
				$chips_to_add
			),
		);
	}

	/**
	 * Process chip count adjustment
	 *
	 * Manual chip count correction with required reason for audit trail.
	 * Can be positive (chip correction up) or negative (chip correction down).
	 *
	 * @since 3.2.0
	 * @param int    $tournament_id Tournament ID.
	 * @param int    $player_id     Player ID (tournament_players.id).
	 * @param int    $adjustment    Chip adjustment amount (positive or negative).
	 * @param string $reason        Required reason for adjustment.
	 * @return array|WP_Error Success array or WP_Error on failure
	 */
	public static function process_chip_adjustment( $tournament_id, $player_id, $adjustment, $reason ) {
		global $wpdb;

		$tournament_id = absint( $tournament_id );
		$player_id     = absint( $player_id );
		$adjustment    = intval( $adjustment );
		$reason        = sanitize_text_field( $reason );

		// Validate inputs
		if ( ! $tournament_id || ! $player_id ) {
			return new WP_Error( 'invalid_params', __( 'Invalid tournament or player ID', 'poker-tournament-import' ) );
		}

		if ( 0 === $adjustment ) {
			return new WP_Error( 'zero_adjustment', __( 'Adjustment cannot be zero', 'poker-tournament-import' ) );
		}

		if ( empty( $reason ) ) {
			return new WP_Error( 'missing_reason', __( 'Reason is required for chip adjustments', 'poker-tournament-import' ) );
		}

		// Get player data
		$player_table = $wpdb->prefix . 'tdwp_tournament_players';
		$player       = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$player_table} WHERE id = %d AND tournament_id = %d", $player_id, $tournament_id )
		);

		if ( ! $player ) {
			return new WP_Error( 'player_not_found', __( 'Player not found', 'poker-tournament-import' ) );
		}

		// Calculate new chip count
		$new_chip_count = $player->chip_count + $adjustment;

		// Prevent negative chip counts
		if ( $new_chip_count < 0 ) {
			return new WP_Error(
				'negative_chips',
				sprintf(
					/* translators: %d: current chip count */
					__( 'Adjustment would result in negative chips. Current: %d', 'poker-tournament-import' ),
					$player->chip_count
				)
			);
		}

		// Update player chip count
		$updated = $wpdb->update(
			$player_table,
			array(
				'chip_count' => $new_chip_count,
				'updated_at' => current_time( 'mysql' ),
			),
			array( 'id' => $player_id ),
			array( '%d', '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			return new WP_Error( 'update_failed', __( 'Failed to update chip count', 'poker-tournament-import' ) );
		}

		// Log transaction
		$transaction_id = TDWP_Transaction_Logger::log_transaction(
			$tournament_id,
			$player->player_id,
			'chip_adjustment',
			0,
			$adjustment,
			$reason
		);

		/**
		 * Fires after chip adjustment
		 *
		 * @since 3.2.0
		 * @param int    $tournament_id Tournament ID.
		 * @param int    $player_id     Player ID.
		 * @param int    $adjustment    Chip adjustment amount.
		 * @param string $reason        Adjustment reason.
		 */
		do_action( 'tdwp_chip_adjustment', $tournament_id, $player_id, $adjustment, $reason );

		return array(
			'success'         => true,
			'adjustment'      => $adjustment,
			'old_chip_count'  => $player->chip_count,
			'new_chip_count'  => $new_chip_count,
			'transaction_id'  => $transaction_id,
			'message'         => sprintf(
				/* translators: 1: adjustment amount, 2: new chip count */
				__( 'Chip adjustment: %1$+d. New count: %2$d', 'poker-tournament-import' ),
				$adjustment,
				$new_chip_count
			),
		);
	}
}
