<?php
/**
 * Migration Tools Admin Page
 *
 * Admin interface for migrating tournament relationships and verifying data integrity
 */

// Prevent direct file access
if (!defined('ABSPATH')) {
    exit;
}

class Poker_Migration_Admin_Page {

    /**
     * Constructor
     */
    public function __construct() {
        $this->migration_tools = new Poker_Tournament_Migration_Tools();
        add_action('admin_notices', array($this, 'show_migration_notices'));
    }

    /**
     * Render migration tools page
     */
    public function render_migration_page() {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

            <?php $this->show_migration_status(); ?>
            <?php $this->show_migration_actions(); ?>
            <?php $this->show_verification_results(); ?>
        </div>
        <?php
    }

    /**
     * Show migration status
     */
    private function show_migration_status() {
        $migration_count = $this->migration_tools->get_migration_count();
        $verification = $this->migration_tools->verify_relationships();
        ?>
        <div class="migration-status-card">
            <h2><?php _e('Migration Status', 'poker-tournament-import'); ?></h2>
            <div class="status-grid">
                <div class="status-item">
                    <span class="status-number"><?php echo $verification['total']; ?></span>
                    <span class="status-label"><?php _e('Total Tournaments', 'poker-tournament-import'); ?></span>
                </div>
                <div class="status-item <?php echo $migration_count > 0 ? 'needs-attention' : 'good'; ?>">
                    <span class="status-number"><?php echo $migration_count; ?></span>
                    <span class="status-label"><?php _e('Need Migration', 'poker-tournament-import'); ?></span>
                </div>
                <div class="status-item">
                    <span class="status-number"><?php echo $verification['has_both']; ?></span>
                    <span class="status-label"><?php _e('Complete Relationships', 'poker-tournament-import'); ?></span>
                </div>
                <div class="status-item">
                    <span class="status-number"><?php echo $verification['has_neither']; ?></span>
                    <span class="status-label"><?php _e('No Relationships', 'poker-tournament-import'); ?></span>
                </div>
            </div>

            <?php if ($migration_count > 0): ?>
                <div class="migration-notice">
                    <p><strong><?php _e('Attention:', 'poker-tournament-import'); ?></strong>
                    <?php
                    printf(
                        __('%d tournaments need migration to fix series/season relationships.', 'poker-tournament-import'),
                        $migration_count
                    );
                    ?>
                    </p>
                </div>
            <?php else: ?>
                <div class="migration-success">
                    <p><strong><?php _e('Excellent!', 'poker-tournament-import'); ?></strong>
                    <?php _e('All tournaments have proper series/season relationships.', 'poker-tournament-import'); ?>
                    </p>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Show migration actions
     */
    private function show_migration_actions() {
        $migration_count = $this->migration_tools->get_migration_count();
        ?>
        <div class="migration-actions-card">
            <h2><?php _e('Migration Actions', 'poker-tournament-import'); ?></h2>

            <?php if ($migration_count > 0): ?>
                <div class="action-section">
                    <h3><?php _e('Bulk Migration', 'poker-tournament-import'); ?></h3>
                    <p><?php _e('Migrate all tournaments that are missing series/season relationships. This will:', 'poker-tournament-import'); ?></p>
                    <ul>
                        <li><?php _e('Find or create series posts based on tournament data', 'poker-tournament-import'); ?></li>
                        <li><?php _e('Find or create season posts based on tournament data', 'poker-tournament-import'); ?></li>
                        <li><?php _e('Link tournaments to their series and seasons', 'poker-tournament-import'); ?></li>
                        <li><?php _e('Apply tournament type/format/category taxonomies', 'poker-tournament-import'); ?></li>
                    </ul>

                    <form method="post" class="migration-form">
                        <?php wp_nonce_field('poker_migration_action', 'nonce'); ?>
                        <input type="hidden" name="poker_migration_action" value="migrate_all">
                        <p>
                            <button type="submit" class="button button-primary"
                                    onclick="return confirm('<?php
                                    esc_attr_e('This will migrate all tournaments. Are you sure?', 'poker-tournament-import');
                                    ?>')">
                                <?php _e('Migrate All Tournaments', 'poker-tournament-import'); ?>
                            </button>
                            <span class="migration-count">
                                (<?php printf(__('%d tournaments will be migrated', 'poker-tournament-import'), $migration_count); ?>)
                            </span>
                        </p>
                    </form>
                </div>
            <?php endif; ?>

            <div class="action-section">
                <h3><?php _e('Data Verification', 'poker-tournament-import'); ?></h3>
                <p><?php _e('Verify the integrity of tournament relationships and identify any issues.', 'poker-tournament-import'); ?></p>

                <form method="post" class="migration-form">
                    <?php wp_nonce_field('poker_migration_action', 'nonce'); ?>
                    <input type="hidden" name="poker_migration_action" value="verify">
                    <p>
                        <button type="submit" class="button">
                            <?php _e('Verify Relationships', 'poker-tournament-import'); ?>
                        </button>
                    </p>
                </form>
            </div>
        </div>
        <?php
    }

    /**
     * Show verification results
     */
    private function show_verification_results() {
        $verification_results = $this->migration_tools->get_admin_notice('verification_results');

        if ($verification_results) {
            $this->migration_tools->clear_admin_notice('verification_results');
            ?>
            <div class="verification-results-card">
                <h2><?php _e('Verification Results', 'poker-tournament-import'); ?></h2>

                <div class="verification-summary">
                    <h3><?php _e('Relationship Status Summary', 'poker-tournament-import'); ?></h3>
                    <table class="wp-list-table widefat striped">
                        <tr>
                            <td><?php _e('Total Tournaments', 'poker-tournament-import'); ?></td>
                            <td><?php echo $verification_results['total']; ?></td>
                        </tr>
                        <tr>
                            <td><?php _e('Have Series Relationship', 'poker-tournament-import'); ?></td>
                            <td><?php echo $verification_results['has_series']; ?></td>
                        </tr>
                        <tr>
                            <td><?php _e('Have Season Relationship', 'poker-tournament-import'); ?></td>
                            <td><?php echo $verification_results['has_season']; ?></td>
                        </tr>
                        <tr>
                            <td><?php _e('Have Both Relationships', 'poker-tournament-import'); ?></td>
                            <td><?php echo $verification_results['has_both']; ?></td>
                        </tr>
                        <tr>
                            <td><?php _e('Have No Relationships', 'poker-tournament-import'); ?></td>
                            <td><?php echo $verification_results['has_neither']; ?></td>
                        </tr>
                    </table>
                </div>

                <?php if (!empty($verification_results['orphaned_series']) || !empty($verification_results['orphaned_seasons'])): ?>
                    <div class="orphaned-relationships">
                        <h3><?php _e('Orphaned Relationships Found', 'poker-tournament-import'); ?></h3>

                        <?php if (!empty($verification_results['orphaned_series'])): ?>
                            <p><strong><?php _e('Tournaments with broken series relationships:', 'poker-tournament-import'); ?></strong></p>
                            <ul>
                                <?php foreach ($verification_results['orphaned_series'] as $tournament_id): ?>
                                    <li>
                                        <a href="<?php echo get_edit_post_link($tournament_id); ?>">
                                            <?php echo get_the_title($tournament_id); ?> (ID: <?php echo $tournament_id; ?>)
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>

                        <?php if (!empty($verification_results['orphaned_seasons'])): ?>
                            <p><strong><?php _e('Tournaments with broken season relationships:', 'poker-tournament-import'); ?></strong></p>
                            <ul>
                                <?php foreach ($verification_results['orphaned_seasons'] as $tournament_id): ?>
                                    <li>
                                        <a href="<?php echo get_edit_post_link($tournament_id); ?>">
                                            <?php echo get_the_title($tournament_id); ?> (ID: <?php echo $tournament_id; ?>)
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            <?php
        }

        $migration_results = $this->migration_tools->get_admin_notice('migration_results');
        if ($migration_results) {
            $this->migration_tools->clear_admin_notice('migration_results');
            ?>
            <div class="migration-results-card">
                <h2><?php _e('Migration Results', 'poker-tournament-import'); ?></h2>

                <div class="migration-summary">
                    <?php if ($migration_results['success'] > 0): ?>
                        <div class="success-notice">
                            <p><strong><?php _e('Migration Successful!', 'poker-tournament-import'); ?></strong></p>
                            <p><?php printf(__('%d tournaments were successfully migrated.', 'poker-tournament-import'), $migration_results['success']); ?></p>
                        </div>
                    <?php endif; ?>

                    <?php if ($migration_results['failed'] > 0): ?>
                        <div class="error-notice">
                            <p><strong><?php _e('Migration Issues Found', 'poker-tournament-import'); ?></strong></p>
                            <p><?php printf(__('%d tournaments could not be migrated.', 'poker-tournament-import'), $migration_results['failed']); ?></p>

                            <?php if (!empty($migration_results['errors'])): ?>
                                <h4><?php _e('Errors:', 'poker-tournament-import'); ?></h4>
                                <ul>
                                    <?php foreach ($migration_results['errors'] as $error): ?>
                                        <li><?php echo esc_html($error); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php
        }
    }

    /**
     * Show migration notices
     */
    public function show_migration_notices() {
        $screen = get_current_screen();
        if (!$screen || $screen->id !== 'poker-tournament-import_page_poker-migration-tools') {
            return;
        }

        // Show any admin notices here if needed
    }
}