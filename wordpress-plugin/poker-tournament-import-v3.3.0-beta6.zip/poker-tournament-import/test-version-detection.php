<?php
/**
 * Test script for version detection functionality
 *
 * This script can be used to test the dynamic version detection
 * system for tc-lib-pdf. Run it from the WordPress root directory
 * with: php -f test-version-detection.php
 *
 * @package Poker_Tournament_Import
 * @since 3.3.0
 */

// Load WordPress
$wordpress_base = dirname(__FILE__) . '/../../../../../../wp-config.php';
if (file_exists($wordpress_base)) {
    require_once($wordpress_base);
} else {
    echo "Error: WordPress not found. Please run this script from within WordPress.\n";
    exit(1);
}

// Load the dependency manager
require_once(plugin_dir_path(__FILE__) . 'includes/tournament-manager/class-dependency-manager.php');

// Initialize the dependency manager
$dependency_manager = TDWP_Dependency_Manager::get_instance();

echo "=== TDWP Version Detection Test ===\n\n";

// Test 1: Get latest version (with cache clear)
echo "Test 1: Getting latest version (cache cleared)...\n";
$latest_version = $dependency_manager->get_latest_version(true);
echo "Latest version: $latest_version\n";
echo "Expected format: x.y.z (e.g., 8.1.5)\n\n";

// Test 2: Get latest version (from cache)
echo "Test 2: Getting latest version (from cache)...\n";
$latest_version_cached = $dependency_manager->get_latest_version();
echo "Latest version (cached): $latest_version_cached\n";
echo "Cache working: " . ($latest_version === $latest_version_cached ? "YES" : "NO") . "\n\n";

// Test 3: Check for updates
echo "Test 3: Checking for updates...\n";
$update_info = $dependency_manager->check_for_updates();
echo "Installed version: " . $update_info['installed_version'] . "\n";
echo "Latest version: " . $update_info['latest_version'] . "\n";
echo "Update available: " . ($update_info['update_available'] ? "YES" : "NO") . "\n\n";

// Test 4: Get available versions
echo "Test 4: Getting available versions...\n";
$available_versions = $dependency_manager->get_available_versions();
echo "Available versions: " . implode(', ', array_slice($available_versions, 0, 5));
if (count($available_versions) > 5) {
    echo ", ... (showing first 5 of " . count($available_versions) . ")";
}
echo "\n\n";

// Test 5: Get dependency status
echo "Test 5: Getting dependency status...\n";
$status = $dependency_manager->get_dependency_status();
echo "TCPDF available: " . ($status['tcpdf_available'] ? "YES" : "NO") . "\n";
echo "Installed version: " . ($status['installed_version'] ?: 'Not installed') . "\n";
echo "Latest version: " . $status['latest_version'] . "\n";
echo "Update available: " . ($status['update_available'] ? "YES" : "NO") . "\n";
echo "TCPDF path: " . $status['tcpdf_path'] . "\n\n";

// Test 6: Test fallback mechanism
echo "Test 6: Testing fallback mechanism...\n";
$fallback_version = constant('TDWP_Dependency_Manager::FALLBACK_VERSION');
echo "Fallback version: $fallback_version\n";
echo "Fallback version format valid: " . (preg_match('/^\d+\.\d+\.\d+$/', $fallback_version) ? "YES" : "NO") . "\n\n";

// Test 7: Cache performance
echo "Test 7: Cache performance test...\n";
$iterations = 10;
$start_time = microtime(true);
for ($i = 0; $i < $iterations; $i++) {
    $dependency_manager->get_latest_version();
}
$end_time = microtime(true);
$total_time = $end_time - $start_time;
$avg_time = ($total_time / $iterations) * 1000; // Convert to milliseconds
echo "Average time for $iterations cached requests: " . number_format($avg_time, 2) . "ms\n\n";

echo "=== Test Complete ===\n";
echo "All tests completed successfully. The version detection system is working properly.\n";

// Cleanup
$dependency_manager->clear_version_cache();
echo "Version cache cleared.\n";
?>