<?php
/**
 * Live Tournament Wizard Admin Page
 *
 * Provides wizard interface for creating new live tournaments with options to:
 * - Start blank tournament
 * - Create from template
 * - Copy from existing tournament
 *
 * @package Poker_Tournament_Import
 * @subpackage Tournament_Manager
 * @since 3.1.0
 */

// Prevent direct file access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Live Tournament Wizard Page class
 *
 * @since 3.1.0
 */
class TDWP_Live_Tournament_Wizard {

	/**
	 * Constructor
	 *
	 * @since 3.1.0
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu_page' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );

		// AJAX handlers.
		add_action( 'wp_ajax_tdwp_create_live_tournament', array( $this, 'ajax_create_tournament' ) );
		add_action( 'wp_ajax_tdwp_get_template_data', array( $this, 'ajax_get_template_data' ) );
		add_action( 'wp_ajax_tdwp_get_tournament_data', array( $this, 'ajax_get_tournament_data' ) );
		add_action( 'wp_ajax_tdwp_wizard_autosave_draft', array( $this, 'ajax_autosave_draft' ) );
		add_action( 'wp_ajax_tdwp_wizard_get_draft', array( $this, 'ajax_get_draft' ) );
		add_action( 'wp_ajax_tdwp_wizard_discard_draft', array( $this, 'ajax_discard_draft' ) );

		// Log tournament_modified whenever a live_tournament post is updated (not newly created).
		add_action( 'save_post_live_tournament', array( $this, 'on_save_live_tournament' ), 20, 3 );
	}

	/**
	 * Hook: fires on save_post for live_tournament post type.
	 *
	 * Logs a tournament_modified event when an existing live_tournament is updated
	 * (excludes auto-saves and revisions).
	 *
	 * @since 3.7.0
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 * @param bool    $update  Whether this is an update (true) or new post (false).
	 */
	public function on_save_live_tournament( $post_id, $post, $update ) {
		// Only log modifications to existing posts.
		if ( ! $update ) {
			return;
		}

		// Skip auto-saves and revisions.
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$events = new TDWP_Tournament_Events();
		$events->log(
			$post_id,
			'tournament_modified',
			array(
				'post_status' => $post->post_status,
				'post_title'  => $post->post_title,
			)
		);
	}

	/**
	 * Add menu page
	 *
	 * @since 3.1.0
	 */
	public function add_menu_page() {
		add_submenu_page(
			'tdwp-tournament-manager',
			__( 'New Live Tournament', 'poker-tournament-import' ),
			__( 'New Live Tournament', 'poker-tournament-import' ),
			'manage_options',
			'tdwp-live-tournament-wizard',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Enqueue admin assets
	 *
	 * @since 3.1.0
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_assets( $hook ) {
		if ( 'tournament-manager_page_tdwp-live-tournament-wizard' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'tdwp-live-tournament-wizard',
			POKER_TOURNAMENT_IMPORT_PLUGIN_URL . 'assets/css/live-tournament-wizard.css',
			array(),
			POKER_TOURNAMENT_IMPORT_VERSION
		);

		wp_enqueue_script(
			'tdwp-live-tournament-wizard',
			POKER_TOURNAMENT_IMPORT_PLUGIN_URL . 'assets/js/live-tournament-wizard.js',
			array( 'jquery' ),
			POKER_TOURNAMENT_IMPORT_VERSION,
			true
		);

		$draft_data = $this->get_user_draft();

		wp_localize_script(
			'tdwp-live-tournament-wizard',
			'tdwpWizard',
			array(
				'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( 'tdwp_live_tournament_wizard' ),
				'draftNonce' => wp_create_nonce( 'tdwp_wizard_draft' ),
				'hasDraft'   => ! empty( $draft_data ),
				'draftMeta'  => $draft_data ? array(
					'name'      => isset( $draft_data['tournament_name'] ) ? esc_js( $draft_data['tournament_name'] ) : '',
					'savedAt'   => isset( $draft_data['_saved_at'] ) ? esc_js( $draft_data['_saved_at'] ) : '',
					'method'    => isset( $draft_data['creation_method'] ) ? esc_js( $draft_data['creation_method'] ) : '',
				) : null,
			)
		);
	}

	/**
	 * Render wizard page
	 *
	 * @since 3.1.0
	 */
	public function render_page() {
		?>
		<div class="wrap tdwp-wizard-wrap">
			<h1><?php esc_html_e( 'Create New Live Tournament', 'poker-tournament-import' ); ?></h1>

			<!-- Draft restore banner — shown by JS when a saved draft exists. -->
			<div id="tdwp-draft-restore-banner" class="notice notice-info" style="display: none;">
				<p>
					<strong><?php esc_html_e( 'Unsaved draft found.', 'poker-tournament-import' ); ?></strong>
					<?php esc_html_e( 'You have an unfinished tournament draft.', 'poker-tournament-import' ); ?>
					<span id="tdwp-draft-meta-summary"></span>
				</p>
				<p>
					<button type="button" class="button button-primary" id="btn-restore-draft"><?php esc_html_e( 'Restore Draft', 'poker-tournament-import' ); ?></button>
					<button type="button" class="button" id="btn-discard-draft"><?php esc_html_e( 'Discard', 'poker-tournament-import' ); ?></button>
				</p>
			</div>

			<!-- Auto-save status indicator -->
			<div id="tdwp-autosave-indicator" style="display: none;">
				<span id="tdwp-autosave-status"></span>
			</div>

			<div class="tdwp-wizard-container">
				<!-- Step 1: Choose creation method -->
				<div class="tdwp-wizard-step" id="step-method" style="display: block;">
					<h2><?php esc_html_e( 'Choose Creation Method', 'poker-tournament-import' ); ?></h2>

					<div class="tdwp-creation-methods">
						<div class="tdwp-method-card" data-method="blank">
							<div class="dashicons dashicons-plus-alt"></div>
							<h3><?php esc_html_e( 'Start Blank', 'poker-tournament-import' ); ?></h3>
							<p><?php esc_html_e( 'Create a new tournament from scratch', 'poker-tournament-import' ); ?></p>
							<button type="button" class="button button-primary tdwp-select-method"><?php esc_html_e( 'Select', 'poker-tournament-import' ); ?></button>
						</div>

						<div class="tdwp-method-card" data-method="template">
							<div class="dashicons dashicons-admin-page"></div>
							<h3><?php esc_html_e( 'From Template', 'poker-tournament-import' ); ?></h3>
							<p><?php esc_html_e( 'Use a pre-configured tournament template', 'poker-tournament-import' ); ?></p>
							<button type="button" class="button button-primary tdwp-select-method"><?php esc_html_e( 'Select', 'poker-tournament-import' ); ?></button>
						</div>

						<div class="tdwp-method-card" data-method="copy">
							<div class="dashicons dashicons-admin-post"></div>
							<h3><?php esc_html_e( 'Copy Tournament', 'poker-tournament-import' ); ?></h3>
							<p><?php esc_html_e( 'Copy settings from a previous tournament', 'poker-tournament-import' ); ?></p>
							<button type="button" class="button button-primary tdwp-select-method"><?php esc_html_e( 'Select', 'poker-tournament-import' ); ?></button>
						</div>
					</div>
				</div>

				<!-- Step 2: Configure tournament (method-specific) -->
				<div class="tdwp-wizard-step" id="step-configure" style="display: none;">
					<h2><?php esc_html_e( 'Configure Tournament', 'poker-tournament-import' ); ?></h2>

					<form id="tdwp-tournament-form">
						<?php wp_nonce_field( 'tdwp_live_tournament_wizard', 'tdwp_wizard_nonce' ); ?>
						<input type="hidden" name="creation_method" id="creation-method" value="">
						<!-- Fee-split and rake-mode fields populated by the apply-template flow (tdwp-l2l). -->
						<input type="hidden" name="entry_fee" id="tpl-entry-fee" value="0">
						<input type="hidden" name="prize_pool_contribution" id="tpl-prize-pool-contribution" value="0">
						<input type="hidden" name="rake_mode" id="tpl-rake-mode" value="percentage">
						<input type="hidden" name="rake_flat_amount" id="tpl-rake-flat-amount" value="0">

						<!-- Basic Info (all methods) -->
						<div class="tdwp-form-section">
							<h3><?php esc_html_e( 'Basic Information', 'poker-tournament-import' ); ?></h3>

							<table class="form-table">
								<tr>
									<th scope="row">
										<label for="tournament-name"><?php esc_html_e( 'Tournament Name', 'poker-tournament-import' ); ?> <span class="required">*</span></label>
									</th>
									<td>
										<input type="text" name="tournament_name" id="tournament-name" class="regular-text" required>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="buy-in"><?php esc_html_e( 'Buy-in Amount', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<input type="number" name="buy_in" id="buy-in" class="small-text" step="0.01" min="0">
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="starting-chips"><?php esc_html_e( 'Starting Chips', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<input type="number" name="starting_chips" id="starting-chips" class="small-text" step="1" min="0">
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="rebuy-cost"><?php esc_html_e( 'Rebuy Cost', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<input type="number" name="rebuy_cost" id="rebuy-cost" class="small-text" step="0.01" min="0" value="0">
										<p class="description"><?php esc_html_e( 'Cost for a rebuy. Leave 0 if no rebuys allowed.', 'poker-tournament-import' ); ?></p>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="rebuy-chips"><?php esc_html_e( 'Rebuy Chips', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<input type="number" name="rebuy_chips" id="rebuy-chips" class="small-text" step="1" min="0" value="0">
										<p class="description"><?php esc_html_e( 'Chip amount for a rebuy.', 'poker-tournament-import' ); ?></p>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="addon-cost"><?php esc_html_e( 'Add-on Cost', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<input type="number" name="addon_cost" id="addon-cost" class="small-text" step="0.01" min="0" value="0">
										<p class="description"><?php esc_html_e( 'Cost for add-on. Leave 0 if no add-ons allowed.', 'poker-tournament-import' ); ?></p>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="addon-chips"><?php esc_html_e( 'Add-on Chips', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<input type="number" name="addon_chips" id="addon-chips" class="small-text" step="1" min="0" value="0">
										<p class="description"><?php esc_html_e( 'Chip amount for add-on.', 'poker-tournament-import' ); ?></p>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="rake-percentage"><?php esc_html_e( 'Rake Percentage', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<input type="number" name="rake_percentage" id="rake-percentage" class="small-text" step="0.01" min="0" max="100" value="0">
										<span>%</span>
										<p class="description"><?php esc_html_e( 'Percentage of prize pool taken as rake/house fee.', 'poker-tournament-import' ); ?></p>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="is-practice"><?php esc_html_e( 'Practice Mode', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<label>
											<input type="checkbox" name="is_practice" id="is-practice" value="1">
											<?php esc_html_e( 'Exclude from statistics (for testing/practice)', 'poker-tournament-import' ); ?>
										</label>
									</td>
								</tr>
							</table>
						</div>

						<!-- Financial Policy Section -->
						<div class="tdwp-form-section tdwp-financial-policies">
							<h3><?php esc_html_e( 'Financial Policy', 'poker-tournament-import' ); ?></h3>
							<p class="description"><?php esc_html_e( 'Configure re-entry, rebuy, add-on, and bounty rules for this tournament.', 'poker-tournament-import' ); ?></p>

							<!-- Re-entry Policy -->
							<h4><?php esc_html_e( 'Re-entry Policy', 'poker-tournament-import' ); ?></h4>
							<table class="form-table">
								<tr>
									<th scope="row">
										<label for="allow-reentry"><?php esc_html_e( 'Allow Re-entry', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<label>
											<input type="checkbox" name="allow_reentry" id="allow-reentry" value="1">
											<?php esc_html_e( 'Players can re-enter after being eliminated', 'poker-tournament-import' ); ?>
										</label>
									</td>
								</tr>
								<tr class="reentry-options" style="display: none;">
									<th scope="row">
										<label for="reentry-cost"><?php esc_html_e( 'Re-entry Cost', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<input type="number" name="reentry_cost" id="reentry-cost" class="small-text" step="0.01" min="0" value="0">
										<p class="description"><?php esc_html_e( 'Cost for re-entering (usually same as buy-in)', 'poker-tournament-import' ); ?></p>
									</td>
								</tr>
								<tr class="reentry-options" style="display: none;">
									<th scope="row">
										<label for="reentry-chips"><?php esc_html_e( 'Re-entry Chips', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<input type="number" name="reentry_chips" id="reentry-chips" class="small-text" step="1" min="0" value="0">
										<p class="description"><?php esc_html_e( 'Chip amount for re-entry (usually same as starting chips)', 'poker-tournament-import' ); ?></p>
									</td>
								</tr>
								<tr class="reentry-options" style="display: none;">
									<th scope="row">
										<label for="reentry-limit"><?php esc_html_e( 'Re-entry Limit', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<input type="number" name="reentry_limit" id="reentry-limit" class="small-text" step="1" min="0" value="0">
										<p class="description"><?php esc_html_e( 'Maximum re-entries per player (0 = unlimited)', 'poker-tournament-import' ); ?></p>
									</td>
								</tr>
								<tr class="reentry-options" style="display: none;">
									<th scope="row">
										<label for="reentry-until-level"><?php esc_html_e( 'Re-entry Until Level', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<input type="number" name="reentry_until_level" id="reentry-until-level" class="small-text" step="1" min="0" value="0">
										<p class="description"><?php esc_html_e( 'Re-entry allowed until this level (0 = late reg only)', 'poker-tournament-import' ); ?></p>
									</td>
								</tr>
							</table>

							<!-- Rebuy Policy -->
							<h4><?php esc_html_e( 'Rebuy Policy', 'poker-tournament-import' ); ?></h4>
							<table class="form-table">
								<tr>
									<th scope="row">
										<label for="rebuy-until-level"><?php esc_html_e( 'Rebuy Until Level', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<input type="number" name="rebuy_until_level" id="rebuy-until-level" class="small-text" step="1" min="0" value="0">
										<p class="description"><?php esc_html_e( 'Rebuys allowed until this level (0 = no rebuys)', 'poker-tournament-import' ); ?></p>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="rebuy-chip-threshold"><?php esc_html_e( 'Rebuy Chip Threshold', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<input type="number" name="rebuy_chip_threshold" id="rebuy-chip-threshold" class="small-text" step="1" min="0" value="0">
										<p class="description"><?php esc_html_e( 'Can rebuy if chips below this amount (0 = no threshold)', 'poker-tournament-import' ); ?></p>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="rebuy-limit-per-player"><?php esc_html_e( 'Rebuy Limit Per Player', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<input type="number" name="rebuy_limit_per_player" id="rebuy-limit-per-player" class="small-text" step="1" min="0" value="0">
										<p class="description"><?php esc_html_e( 'Maximum rebuys per player (0 = unlimited)', 'poker-tournament-import' ); ?></p>
									</td>
								</tr>
							</table>

							<!-- Add-on Policy -->
							<h4><?php esc_html_e( 'Add-on Policy', 'poker-tournament-import' ); ?></h4>
							<table class="form-table">
								<tr>
									<th scope="row">
										<label for="addon-at-level"><?php esc_html_e( 'Add-on At Level', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<input type="number" name="addon_at_level" id="addon-at-level" class="small-text" step="1" min="0" value="0">
										<p class="description"><?php esc_html_e( 'Add-on available at this level (0 = no add-ons)', 'poker-tournament-import' ); ?></p>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="addon-until-level"><?php esc_html_e( 'Add-on Until Level', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<input type="number" name="addon_until_level" id="addon-until-level" class="small-text" step="1" min="0" value="0">
										<p class="description"><?php esc_html_e( 'Add-on available until this level (0 = same as start level)', 'poker-tournament-import' ); ?></p>
									</td>
								</tr>
							</table>

							<!-- Bounty/Knockout Policy -->
							<h4><?php esc_html_e( 'Bounty / Knockout Policy', 'poker-tournament-import' ); ?></h4>
							<table class="form-table">
								<tr>
									<th scope="row">
										<label for="bounty-type"><?php esc_html_e( 'Bounty Type', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<select name="bounty_type" id="bounty-type" class="regular-text">
											<option value="none" selected><?php esc_html_e( 'No Bounties', 'poker-tournament-import' ); ?></option>
											<option value="fixed"><?php esc_html_e( 'Fixed Bounty', 'poker-tournament-import' ); ?></option>
											<option value="pko"><?php esc_html_e( 'Progressive Knockout (PKO)', 'poker-tournament-import' ); ?></option>
										</select>
										<p class="description"><?php esc_html_e( 'Fixed: Full bounty to eliminator. PKO: Half to eliminator, half added to their bounty', 'poker-tournament-import' ); ?></p>
									</td>
								</tr>
								<tr class="bounty-options" style="display: none;">
									<th scope="row">
										<label for="bounty-amount"><?php esc_html_e( 'Bounty Amount', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<input type="number" name="bounty_amount" id="bounty-amount" class="small-text" step="0.01" min="0" value="0">
										<p class="description"><?php esc_html_e( 'Bounty amount per player (for Fixed or PKO starting amount)', 'poker-tournament-import' ); ?></p>
									</td>
								</tr>
								<tr class="bounty-options bounty-pko-only" style="display: none;">
									<th scope="row">
										<label for="bounty-percentage"><?php esc_html_e( 'PKO Split Percentage', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<input type="number" name="bounty_percentage" id="bounty-percentage" class="small-text" step="0.01" min="0" max="100" value="50">
										<span>%</span>
										<p class="description"><?php esc_html_e( 'Percentage awarded to eliminator (remaining goes to their bounty)', 'poker-tournament-import' ); ?></p>
									</td>
								</tr>
							</table>

							<!-- Late Registration Policy -->
							<h4><?php esc_html_e( 'Late Registration', 'poker-tournament-import' ); ?></h4>
							<table class="form-table">
								<tr>
									<th scope="row">
										<label for="late-reg-until-level"><?php esc_html_e( 'Late Reg Until Level', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<input type="number" name="late_reg_until_level" id="late-reg-until-level" class="small-text" step="1" min="0" value="0">
										<p class="description"><?php esc_html_e( 'Late registration allowed until this level (0 = no late reg)', 'poker-tournament-import' ); ?></p>
									</td>
								</tr>
							</table>
						</div>

						<!-- Template Selection (template method) -->
						<div class="tdwp-form-section" id="template-section" style="display: none;">
							<h3><?php esc_html_e( 'Select Template', 'poker-tournament-import' ); ?></h3>
							<table class="form-table">
								<tr>
									<th scope="row">
										<label for="template-select"><?php esc_html_e( 'Template', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<select name="template_id" id="template-select" class="regular-text">
											<option value=""><?php esc_html_e( 'Select a template...', 'poker-tournament-import' ); ?></option>
											<?php echo $this->get_template_options(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
										</select>
									</td>
								</tr>
							</table>
						</div>

						<!-- Tournament Selection (copy method) -->
						<div class="tdwp-form-section" id="copy-section" style="display: none;">
							<h3><?php esc_html_e( 'Select Tournament to Copy', 'poker-tournament-import' ); ?></h3>
							<table class="form-table">
								<tr>
									<th scope="row">
										<label for="source-tournament"><?php esc_html_e( 'Tournament', 'poker-tournament-import' ); ?></label>
									</th>
									<td>
										<select name="source_tournament_id" id="source-tournament" class="regular-text">
											<option value=""><?php esc_html_e( 'Select a tournament...', 'poker-tournament-import' ); ?></option>
											<?php echo $this->get_tournament_options(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
										</select>
									</td>
								</tr>
							</table>

							<h4><?php esc_html_e( 'Copy Options', 'poker-tournament-import' ); ?></h4>
							<fieldset>
								<label>
									<input type="checkbox" name="copy_players" value="1" checked>
									<?php esc_html_e( 'Copy Players', 'poker-tournament-import' ); ?>
								</label><br>
								<label>
									<input type="checkbox" name="copy_tables" value="1" checked>
									<?php esc_html_e( 'Copy Table Configuration', 'poker-tournament-import' ); ?>
								</label><br>
								<label>
									<input type="checkbox" name="copy_blinds" value="1" checked>
									<?php esc_html_e( 'Copy Blind Schedule', 'poker-tournament-import' ); ?>
								</label><br>
								<label>
									<input type="checkbox" name="copy_prizes" value="1" checked>
									<?php esc_html_e( 'Copy Prize Structure', 'poker-tournament-import' ); ?>
								</label>
							</fieldset>
						</div>

						<p class="submit">
							<button type="button" class="button" id="btn-back"><?php esc_html_e( 'Back', 'poker-tournament-import' ); ?></button>
							<button type="submit" class="button button-primary" id="btn-create"><?php esc_html_e( 'Create Tournament', 'poker-tournament-import' ); ?></button>
						</p>
					</form>
				</div>

				<!-- Step 3: Success -->
				<div class="tdwp-wizard-step" id="step-success" style="display: none;">
					<div class="tdwp-success-message">
						<div class="dashicons dashicons-yes-alt"></div>
						<h2><?php esc_html_e( 'Tournament Created Successfully!', 'poker-tournament-import' ); ?></h2>
						<p id="success-message"></p>
						<p>
							<a href="" class="button button-primary" id="btn-manage"><?php esc_html_e( 'Manage Tournament', 'poker-tournament-import' ); ?></a>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=tdwp-live-tournament-wizard' ) ); ?>" class="button"><?php esc_html_e( 'Create Another', 'poker-tournament-import' ); ?></a>
						</p>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Get template options for dropdown
	 *
	 * @since 3.1.0
	 * @return string HTML options.
	 */
	private function get_template_options() {
		global $wpdb;
		$table = $wpdb->prefix . 'tdwp_tournament_templates';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$templates = $wpdb->get_results( "SELECT id, name FROM {$table} ORDER BY name ASC" );

		$options = '';
		foreach ( $templates as $template ) {
			$options .= sprintf(
				'<option value="%d">%s</option>',
				esc_attr( $template->id ),
				esc_html( $template->name )
			);
		}

		return $options;
	}

	/**
	 * Get tournament options for dropdown
	 *
	 * @since 3.1.0
	 * @return string HTML options.
	 */
	private function get_tournament_options() {
		$tournaments = get_posts(
			array(
				'post_type'      => 'tournament',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);

		$options = '';
		foreach ( $tournaments as $tournament ) {
			$options .= sprintf(
				'<option value="%d">%s</option>',
				esc_attr( $tournament->ID ),
				esc_html( $tournament->post_title )
			);
		}

		return $options;
	}

	/**
	 * AJAX: Create live tournament
	 *
	 * @since 3.1.0
	 */
	public function ajax_create_tournament() {
		check_ajax_referer( 'tdwp_live_tournament_wizard', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Access denied', 'poker-tournament-import' ) ) );
		}

		$method = isset( $_POST['creation_method'] ) ? sanitize_text_field( wp_unslash( $_POST['creation_method'] ) ) : '';
		$name   = isset( $_POST['tournament_name'] ) ? sanitize_text_field( wp_unslash( $_POST['tournament_name'] ) ) : '';

		if ( empty( $name ) ) {
			wp_send_json_error( array( 'message' => __( 'Tournament name is required', 'poker-tournament-import' ) ) );
		}

		// Create live_tournament post.
		$post_id = wp_insert_post(
			array(
				'post_title'  => $name,
				'post_type'   => 'live_tournament',
				'post_status' => 'publish',
			)
		);

		if ( is_wp_error( $post_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Failed to create tournament', 'poker-tournament-import' ) ) );
		}

		// Save basic meta fields.
		$buy_in          = isset( $_POST['buy_in'] ) ? floatval( $_POST['buy_in'] ) : 0;
		$starting_chips  = isset( $_POST['starting_chips'] ) ? intval( $_POST['starting_chips'] ) : 0;
		$rebuy_cost      = isset( $_POST['rebuy_cost'] ) ? floatval( $_POST['rebuy_cost'] ) : 0;
		$rebuy_chips     = isset( $_POST['rebuy_chips'] ) ? intval( $_POST['rebuy_chips'] ) : 0;
		$addon_cost      = isset( $_POST['addon_cost'] ) ? floatval( $_POST['addon_cost'] ) : 0;
		$addon_chips     = isset( $_POST['addon_chips'] ) ? intval( $_POST['addon_chips'] ) : 0;
		$rake_percentage = isset( $_POST['rake_percentage'] ) ? floatval( $_POST['rake_percentage'] ) : 0;
		$is_practice     = isset( $_POST['is_practice'] ) && '1' === $_POST['is_practice'] ? 1 : 0;

		update_post_meta( $post_id, '_status', 'pending' );
		update_post_meta( $post_id, '_buy_in', $buy_in );
		update_post_meta( $post_id, '_starting_chips', $starting_chips );
		update_post_meta( $post_id, '_rebuy_cost', $rebuy_cost );
		update_post_meta( $post_id, '_rebuy_chips', $rebuy_chips );
		update_post_meta( $post_id, '_addon_cost', $addon_cost );
		update_post_meta( $post_id, '_addon_chips', $addon_chips );
		update_post_meta( $post_id, '_rake_percentage', $rake_percentage );
		update_post_meta( $post_id, '_creation_method', $method );
		update_post_meta( $post_id, '_is_practice', $is_practice );

		// Save financial policy fields (Beta 20).
		$allow_reentry           = isset( $_POST['allow_reentry'] ) && '1' === $_POST['allow_reentry'] ? 1 : 0;
		$reentry_cost            = isset( $_POST['reentry_cost'] ) ? floatval( $_POST['reentry_cost'] ) : 0;
		$reentry_chips           = isset( $_POST['reentry_chips'] ) ? intval( $_POST['reentry_chips'] ) : 0;
		$reentry_limit           = isset( $_POST['reentry_limit'] ) ? intval( $_POST['reentry_limit'] ) : 0;
		$reentry_until_level     = isset( $_POST['reentry_until_level'] ) ? intval( $_POST['reentry_until_level'] ) : 0;
		$rebuy_until_level       = isset( $_POST['rebuy_until_level'] ) ? intval( $_POST['rebuy_until_level'] ) : 0;
		$rebuy_chip_threshold    = isset( $_POST['rebuy_chip_threshold'] ) ? intval( $_POST['rebuy_chip_threshold'] ) : 0;
		$rebuy_limit_per_player  = isset( $_POST['rebuy_limit_per_player'] ) ? intval( $_POST['rebuy_limit_per_player'] ) : 0;
		$addon_at_level          = isset( $_POST['addon_at_level'] ) ? intval( $_POST['addon_at_level'] ) : 0;
		$addon_until_level       = isset( $_POST['addon_until_level'] ) ? intval( $_POST['addon_until_level'] ) : 0;
		$bounty_type             = isset( $_POST['bounty_type'] ) ? sanitize_text_field( wp_unslash( $_POST['bounty_type'] ) ) : 'none';
		$bounty_amount           = isset( $_POST['bounty_amount'] ) ? floatval( $_POST['bounty_amount'] ) : 0;
		$bounty_percentage       = isset( $_POST['bounty_percentage'] ) ? floatval( $_POST['bounty_percentage'] ) : 50;
		$late_reg_until_level    = isset( $_POST['late_reg_until_level'] ) ? intval( $_POST['late_reg_until_level'] ) : 0;

		// Fee-split / rake-mode fields (populated from template apply flow, tdwp-l2l).
		$entry_fee               = isset( $_POST['entry_fee'] ) ? floatval( $_POST['entry_fee'] ) : 0;
		$prize_pool_contribution = isset( $_POST['prize_pool_contribution'] ) ? floatval( $_POST['prize_pool_contribution'] ) : 0;
		$rake_mode_raw           = isset( $_POST['rake_mode'] ) ? sanitize_key( wp_unslash( $_POST['rake_mode'] ) ) : 'percentage';
		$rake_mode               = in_array( $rake_mode_raw, array( 'percentage', 'flat' ), true ) ? $rake_mode_raw : 'percentage';
		$rake_flat_amount        = isset( $_POST['rake_flat_amount'] ) ? floatval( $_POST['rake_flat_amount'] ) : 0;

		update_post_meta( $post_id, '_entry_fee', $entry_fee );
		update_post_meta( $post_id, '_prize_pool_contribution', $prize_pool_contribution );
		update_post_meta( $post_id, '_rake_mode', $rake_mode );
		update_post_meta( $post_id, '_rake_flat_amount', $rake_flat_amount );

		update_post_meta( $post_id, '_allow_reentry', $allow_reentry );
		update_post_meta( $post_id, '_reentry_cost', $reentry_cost );
		update_post_meta( $post_id, '_reentry_chips', $reentry_chips );
		update_post_meta( $post_id, '_reentry_limit', $reentry_limit );
		update_post_meta( $post_id, '_reentry_until_level', $reentry_until_level );
		update_post_meta( $post_id, '_rebuy_until_level', $rebuy_until_level );
		update_post_meta( $post_id, '_rebuy_chip_threshold', $rebuy_chip_threshold );
		update_post_meta( $post_id, '_rebuy_limit_per_player', $rebuy_limit_per_player );
		update_post_meta( $post_id, '_addon_at_level', $addon_at_level );
		update_post_meta( $post_id, '_addon_until_level', $addon_until_level );
		update_post_meta( $post_id, '_bounty_type', $bounty_type );
		update_post_meta( $post_id, '_bounty_amount', $bounty_amount );
		update_post_meta( $post_id, '_bounty_percentage', $bounty_percentage );
		update_post_meta( $post_id, '_late_reg_until_level', $late_reg_until_level );

		// Handle method-specific data.
		switch ( $method ) {
			case 'template':
				$this->create_from_template( $post_id, $_POST );
				break;
			case 'copy':
				$this->create_from_tournament( $post_id, $_POST );
				break;
			case 'blank':
			default:
				// Nothing extra for blank.
				break;
		}

		// Set as active tournament for current user.
		TDWP_Active_Tournament_Manager::set_active_tournament( get_current_user_id(), $post_id );

		// Log tournament_created history event.
		$events = new TDWP_Tournament_Events();
		$events->log(
			$post_id,
			'tournament_created',
			array(
				'name'            => $name,
				'creation_method' => $method,
			),
			false
		);

		// Discard any in-progress wizard draft now that the tournament is saved.
		delete_user_meta( get_current_user_id(), 'tdwp_wizard_draft' );

		wp_send_json_success(
			array(
				'message'       => __( 'Tournament created successfully', 'poker-tournament-import' ),
				'tournament_id' => $post_id,
				'manage_url'    => admin_url( 'admin.php?page=tdwp-live-control&tournament_id=' . $post_id ),
			)
		);
	}

	/**
	 * Create tournament from template
	 *
	 * @since 3.1.0
	 * @param int   $post_id Tournament post ID.
	 * @param array $data    Form data.
	 */
	private function create_from_template( $post_id, $data ) {
		$template_id = isset( $data['template_id'] ) ? intval( $data['template_id'] ) : 0;

		if ( ! $template_id ) {
			return;
		}

		update_post_meta( $post_id, '_template_id', $template_id );

		// Load template data and copy blind schedule, prize structure.
		global $wpdb;
		$table    = $wpdb->prefix . 'tdwp_tournament_templates';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$template = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $template_id ) );

		if ( $template ) {
			if ( ! empty( $template->blind_schedule_id ) ) {
				update_post_meta( $post_id, '_blind_schedule_id', $template->blind_schedule_id );
			}
			if ( ! empty( $template->prize_structure_id ) ) {
				update_post_meta( $post_id, '_prize_structure_id', $template->prize_structure_id );
			}
		}
	}

	/**
	 * Create tournament from existing tournament
	 *
	 * @since 3.1.0
	 * @param int   $post_id Tournament post ID.
	 * @param array $data    Form data.
	 */
	private function create_from_tournament( $post_id, $data ) {
		$source_id = isset( $data['source_tournament_id'] ) ? intval( $data['source_tournament_id'] ) : 0;

		if ( ! $source_id ) {
			return;
		}

		update_post_meta( $post_id, '_source_tournament_id', $source_id );

		// Copy options.
		$copy_players = isset( $data['copy_players'] ) && '1' === $data['copy_players'];
		$copy_tables  = isset( $data['copy_tables'] ) && '1' === $data['copy_tables'];
		$copy_blinds  = isset( $data['copy_blinds'] ) && '1' === $data['copy_blinds'];
		$copy_prizes  = isset( $data['copy_prizes'] ) && '1' === $data['copy_prizes'];

		// Copy blind schedule.
		if ( $copy_blinds ) {
			$blind_schedule_id = get_post_meta( $source_id, 'blind_schedule_id', true );
			if ( $blind_schedule_id ) {
				update_post_meta( $post_id, '_blind_schedule_id', $blind_schedule_id );
			}
		}

		// Copy prize structure.
		if ( $copy_prizes ) {
			$prize_structure_id = get_post_meta( $source_id, 'prize_structure_id', true );
			if ( $prize_structure_id ) {
				update_post_meta( $post_id, '_prize_structure_id', $prize_structure_id );
			}
		}

		// Copy players (Phase 3 - will implement when player system ready).
		if ( $copy_players ) {
			// TODO: Copy players from source tournament.
			update_post_meta( $post_id, '_copy_players_pending', true );
		}

		// Copy tables (Phase 3 - will implement when table system ready).
		if ( $copy_tables ) {
			// TODO: Copy table configuration from source tournament.
			update_post_meta( $post_id, '_copy_tables_pending', true );
		}
	}

	/**
	 * AJAX: Get template data for wizard apply flow (tdwp-l2l)
	 *
	 * Returns all financial, rebuy/add-on timing, and relation fields needed to
	 * pre-populate the creation form when the user chooses "From Template".
	 *
	 * @since 3.1.0
	 */
	public function ajax_get_template_data() {
		check_ajax_referer( 'tdwp_live_tournament_wizard', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Access denied', 'poker-tournament-import' ) ) );
		}

		$template_id = isset( $_POST['template_id'] ) ? absint( $_POST['template_id'] ) : 0;

		if ( ! $template_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid template ID', 'poker-tournament-import' ) ) );
		}

		$loader   = new TDWP_Tournament_Template();
		$template = $loader->get( $template_id, true );

		if ( ! $template ) {
			wp_send_json_error( array( 'message' => __( 'Template not found', 'poker-tournament-import' ) ) );
		}

		$payload = array(
			// Core identity.
			'id'   => (int) $template->id,
			'name' => $template->name,

			// Financial config.
			'buy_in'                  => (float) $template->buy_in,
			'entry_fee'               => (float) ( $template->entry_fee ?? 0 ),
			'prize_pool_contribution' => (float) ( $template->prize_pool_contribution ?? 0 ),
			'rake_percentage'         => (float) $template->rake_percentage,
			'rake_mode'               => isset( $template->rake_mode ) ? $template->rake_mode : 'percentage',
			'rake_flat_amount'        => (float) ( $template->rake_flat_amount ?? 0 ),

			// Chip values.
			'starting_chips' => (int) $template->starting_chips,
			'rebuy_cost'     => (float) $template->rebuy_cost,
			'rebuy_chips'    => (int) $template->rebuy_chips,
			'addon_cost'     => (float) $template->addon_cost,
			'addon_chips'    => (int) $template->addon_chips,

			// Rebuy / add-on timing (tdwp-vf9 fields).
			'rebuy_until_level'      => (int) ( $template->rebuy_until_level ?? 0 ),
			'rebuy_chip_threshold'   => (int) ( $template->rebuy_chip_threshold ?? 0 ),
			'rebuy_limit_per_player' => (int) ( $template->rebuy_limit_per_player ?? 0 ),
			'addon_at_level'         => (int) ( $template->addon_at_level ?? 0 ),
			'addon_until_level'      => (int) ( $template->addon_until_level ?? 0 ),

			// Relation references.
			'blind_schedule_id'  => (int) $template->blind_schedule_id,
			'prize_structure_id' => (int) $template->prize_structure_id,

			// Relation names for user-facing notice.
			'blind_schedule_name'  => isset( $template->blind_schedule ) && $template->blind_schedule
				? $template->blind_schedule->name
				: '',
			'prize_structure_name' => isset( $template->prize_structure ) && $template->prize_structure
				? $template->prize_structure->name
				: '',
		);

		wp_send_json_success( array( 'template' => $payload ) );
	}

	/**
	 * AJAX: Get tournament data
	 *
	 * @since 3.1.0
	 */
	public function ajax_get_tournament_data() {
		check_ajax_referer( 'tdwp_live_tournament_wizard', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Access denied', 'poker-tournament-import' ) ) );
		}

		$tournament_id = isset( $_POST['tournament_id'] ) ? intval( $_POST['tournament_id'] ) : 0;

		if ( ! $tournament_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid tournament ID', 'poker-tournament-import' ) ) );
		}

		$tournament = get_post( $tournament_id );

		if ( ! $tournament || 'tournament' !== $tournament->post_type ) {
			wp_send_json_error( array( 'message' => __( 'Tournament not found', 'poker-tournament-import' ) ) );
		}

		// Get tournament meta.
		$meta = array(
			'buy_in'              => get_post_meta( $tournament_id, 'buy_in', true ),
			'starting_chips'      => get_post_meta( $tournament_id, 'starting_chips', true ),
			'blind_schedule_id'   => get_post_meta( $tournament_id, 'blind_schedule_id', true ),
			'prize_structure_id'  => get_post_meta( $tournament_id, 'prize_structure_id', true ),
		);

		wp_send_json_success(
			array(
				'tournament' => $tournament,
				'meta'       => $meta,
			)
		);
	}

	// -------------------------------------------------------------------------
	// Draft persistence helpers (tdwp-67j)
	// -------------------------------------------------------------------------

	/**
	 * The allowed field keys for wizard draft storage.
	 *
	 * Keeps the user-meta blob predictable and prevents arbitrary key injection.
	 *
	 * @since 3.7.0
	 * @return array<string> List of allowed field names.
	 */
	private function draft_allowed_fields() {
		return array(
			'creation_method',
			'tournament_name',
			'buy_in',
			'starting_chips',
			'rebuy_cost',
			'rebuy_chips',
			'addon_cost',
			'addon_chips',
			'rake_percentage',
			'is_practice',
			'entry_fee',
			'prize_pool_contribution',
			'rake_mode',
			'rake_flat_amount',
			'allow_reentry',
			'reentry_cost',
			'reentry_chips',
			'reentry_limit',
			'reentry_until_level',
			'rebuy_until_level',
			'rebuy_chip_threshold',
			'rebuy_limit_per_player',
			'addon_at_level',
			'addon_until_level',
			'bounty_type',
			'bounty_amount',
			'bounty_percentage',
			'late_reg_until_level',
			'template_id',
			'source_tournament_id',
		);
	}

	/**
	 * Retrieve the current user's wizard draft from user meta.
	 *
	 * @since 3.7.0
	 * @return array|null Draft data array, or null when none exists.
	 */
	private function get_user_draft() {
		$user_id = get_current_user_id();
		if ( ! $user_id ) {
			return null;
		}

		$raw = get_user_meta( $user_id, 'tdwp_wizard_draft', true );
		if ( ! is_array( $raw ) || empty( $raw ) ) {
			return null;
		}

		return $raw;
	}

	/**
	 * AJAX: Auto-save wizard draft to user meta.
	 *
	 * Persists a sanitized subset of the in-progress form so a crash or
	 * accidental navigation can be recovered. Stored in user meta
	 * (`tdwp_wizard_draft`) as a serialised PHP array — no new table required.
	 *
	 * @since 3.7.0
	 */
	public function ajax_autosave_draft() {
		check_ajax_referer( 'tdwp_wizard_draft', 'draft_nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Access denied', 'poker-tournament-import' ) ) );
		}

		$user_id = get_current_user_id();

		$draft = array();

		foreach ( $this->draft_allowed_fields() as $field ) {
			if ( ! isset( $_POST[ $field ] ) ) {
				continue;
			}

			// Sanitize by field type.
			$raw = wp_unslash( $_POST[ $field ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

			switch ( $field ) {
				case 'tournament_name':
					$draft[ $field ] = sanitize_text_field( $raw );
					break;

				case 'creation_method':
				case 'bounty_type':
				case 'rake_mode':
					$draft[ $field ] = sanitize_key( $raw );
					break;

				case 'is_practice':
				case 'allow_reentry':
					$draft[ $field ] = '1' === (string) $raw ? 1 : 0;
					break;

				case 'buy_in':
				case 'rebuy_cost':
				case 'addon_cost':
				case 'rake_percentage':
				case 'entry_fee':
				case 'prize_pool_contribution':
				case 'rake_flat_amount':
				case 'reentry_cost':
				case 'bounty_amount':
				case 'bounty_percentage':
					$draft[ $field ] = (float) $raw;
					break;

				default:
					// Integer fields.
					$draft[ $field ] = absint( $raw );
					break;
			}
		}

		// Record when this draft was saved.
		$draft['_saved_at'] = current_time( 'mysql' );

		update_user_meta( $user_id, 'tdwp_wizard_draft', $draft );

		wp_send_json_success( array( 'saved_at' => $draft['_saved_at'] ) );
	}

	/**
	 * AJAX: Return the current user's wizard draft.
	 *
	 * @since 3.7.0
	 */
	public function ajax_get_draft() {
		check_ajax_referer( 'tdwp_wizard_draft', 'draft_nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Access denied', 'poker-tournament-import' ) ) );
		}

		$draft = $this->get_user_draft();

		if ( null === $draft ) {
			wp_send_json_error( array( 'message' => __( 'No draft found', 'poker-tournament-import' ) ) );
		}

		wp_send_json_success( array( 'draft' => $draft ) );
	}

	/**
	 * AJAX: Discard the current user's wizard draft.
	 *
	 * @since 3.7.0
	 */
	public function ajax_discard_draft() {
		check_ajax_referer( 'tdwp_wizard_draft', 'draft_nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Access denied', 'poker-tournament-import' ) ) );
		}

		delete_user_meta( get_current_user_id(), 'tdwp_wizard_draft' );

		wp_send_json_success( array( 'discarded' => true ) );
	}
}
