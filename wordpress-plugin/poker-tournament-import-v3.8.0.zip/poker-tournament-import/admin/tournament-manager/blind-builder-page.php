<?php
/**
 * Blind Builder Admin Page
 *
 * Handles the blind schedule builder interface in WordPress admin.
 *
 * @package    Poker_Tournament_Import
 * @subpackage Tournament_Manager
 * @since      3.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * TDWP Blind Builder Page Class
 *
 * Provides admin interface for creating and managing blind schedules.
 *
 * @since 3.0.0
 */
class TDWP_Blind_Builder_Page {

	/**
	 * Blind Schedule Manager instance
	 *
	 * @since 3.0.0
	 * @var TDWP_Blind_Schedule
	 */
	private $schedule_manager;

	/**
	 * Blind Level Manager instance
	 *
	 * @since 3.0.0
	 * @var TDWP_Blind_Level
	 */
	private $level_manager;

	/**
	 * Constructor
	 *
	 * @since 3.0.0
	 */
	public function __construct() {
		$this->schedule_manager = new TDWP_Blind_Schedule();
		$this->level_manager    = new TDWP_Blind_Level();

		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'admin_init', array( $this, 'handle_actions' ) );
		add_action( 'wp_ajax_tdwp_save_blind_levels', array( $this, 'ajax_save_levels' ) );
		add_action( 'wp_ajax_tdwp_get_blind_levels', array( $this, 'ajax_get_levels' ) );
		add_action( 'wp_ajax_tdwp_suggest_blind_schedule', array( $this, 'ajax_suggest_schedule' ) );
		add_action( 'wp_ajax_tdwp_apply_blind_template_to_tournament', array( $this, 'ajax_apply_template_to_tournament' ) );
		add_action( 'wp_ajax_tdwp_print_blind_schedule', array( $this, 'ajax_print_blind_schedule' ) );
		add_action( 'wp_ajax_tdwp_import_blind_csv', array( $this, 'ajax_import_blind_csv' ) );
	}

	/**
	 * Add admin menu
	 *
	 * @since 3.0.0
	 */
	public function add_admin_menu() {
		add_submenu_page(
			'tdwp-tournament-manager',
			__( 'Blind Builder', 'poker-tournament-import' ),
			__( 'Blind Builder', 'poker-tournament-import' ),
			'manage_options',
			'tdwp-blind-builder',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Enqueue CSS and JavaScript
	 *
	 * @since 3.0.0
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_assets( $hook ) {
		if ( 'tournament-manager_page_tdwp-blind-builder' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'tdwp-blind-builder-admin',
			POKER_TOURNAMENT_IMPORT_PLUGIN_URL . 'assets/css/blind-builder-admin.css',
			array(),
			POKER_TOURNAMENT_IMPORT_VERSION
		);

		wp_enqueue_script( 'jquery-ui-sortable' );

		wp_enqueue_script(
			'tdwp-blind-builder-admin',
			POKER_TOURNAMENT_IMPORT_PLUGIN_URL . 'assets/js/blind-builder-admin.js',
			array( 'jquery', 'jquery-ui-sortable' ),
			POKER_TOURNAMENT_IMPORT_VERSION,
			true
		);

		wp_localize_script(
			'tdwp-blind-builder-admin',
			'tdwpBlindBuilder',
			array(
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'nonce'       => wp_create_nonce( 'tdwp_blind_builder' ),
				'i18n'        => array(
					'confirmDelete'      => __( 'Are you sure you want to delete this schedule? This action cannot be undone.', 'poker-tournament-import' ),
					'confirmDeleteLevel' => __( 'Are you sure you want to delete this level?', 'poker-tournament-import' ),
					'errorSaving'        => __( 'Error saving levels. Please try again.', 'poker-tournament-import' ),
					'errorLoading'       => __( 'Error loading levels. Please refresh the page.', 'poker-tournament-import' ),
					'levelsSaved'        => __( 'Blind levels saved successfully.', 'poker-tournament-import' ),
					'errorSuggesting'          => __( 'Error generating suggestion. Please try again.', 'poker-tournament-import' ),
					'confirmLoadSuggest'       => __( 'This will replace your current levels with the generated schedule. Continue?', 'poker-tournament-import' ),
					'applyTemplateSuccess'     => __( 'Blind schedule applied to tournament successfully.', 'poker-tournament-import' ),
					'applyTemplateError'       => __( 'Error applying schedule to tournament. Please check the tournament ID and try again.', 'poker-tournament-import' ),
					'applyTemplateConfirm'     => __( 'This will replace the blind schedule currently assigned to that tournament. Continue?', 'poker-tournament-import' ),
				),
			)
		);
	}

	/**
	 * Handle form actions
	 *
	 * @since 3.0.0
	 */
	public function handle_actions() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $_GET['page'] ) || 'tdwp-blind-builder' !== $_GET['page'] ) {
			return;
		}

		if ( ! isset( $_GET['action'] ) ) {
			return;
		}

		$action = sanitize_text_field( wp_unslash( $_GET['action'] ) );
		// phpcs:enable

		if ( 'delete' === $action ) {
			$this->handle_delete();
		} elseif ( 'clone' === $action ) {
			$this->handle_clone();
		} elseif ( 'save' === $action ) {
			$this->handle_save();
		}
	}

	/**
	 * Handle schedule save
	 *
	 * @since 3.0.0
	 */
	private function handle_save() {
		// Verify nonce.
		if ( ! isset( $_POST['schedule_nonce'] ) ) {
			return;
		}

		$schedule_id = isset( $_POST['schedule_id'] ) ? absint( $_POST['schedule_id'] ) : 0;
		check_admin_referer( 'tdwp_save_schedule_' . $schedule_id, 'schedule_nonce' );

		// Check permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'poker-tournament-import' ) );
		}

		// Collect schedule data.
		$data = array(
			'name'               => isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '',
			'description'        => isset( $_POST['description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['description'] ) ) : '',
			'level_duration'     => isset( $_POST['level_duration'] ) ? absint( $_POST['level_duration'] ) : 15,
			'break_frequency'    => isset( $_POST['break_frequency'] ) ? absint( $_POST['break_frequency'] ) : 0,
			'break_duration'     => isset( $_POST['break_duration'] ) ? absint( $_POST['break_duration'] ) : 0,
			'is_default_turbo'   => isset( $_POST['is_default_turbo'] ) ? 1 : 0,
			'is_default_regular' => isset( $_POST['is_default_regular'] ) ? 1 : 0,
			'is_default_deep'    => isset( $_POST['is_default_deep'] ) ? 1 : 0,
		);

		// Create or update schedule.
		if ( $schedule_id > 0 ) {
			$result = $this->schedule_manager->update( $schedule_id, $data );
			$message = 'updated';
		} else {
			$result = $this->schedule_manager->create( $data );
			$schedule_id = $result;
			$message = 'created';
		}

		// Handle result.
		if ( is_wp_error( $result ) ) {
			wp_safe_redirect(
				add_query_arg(
					array(
						'page'    => 'tdwp-blind-builder',
						'message' => 'error',
						'details' => rawurlencode( $result->get_error_message() ),
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}

		// Redirect to edit page.
		wp_safe_redirect(
			add_query_arg(
				array(
					'page'        => 'tdwp-blind-builder',
					'action'      => 'edit',
					'schedule_id' => $schedule_id,
					'message'     => $message,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Handle schedule delete
	 *
	 * @since 3.0.0
	 */
	private function handle_delete() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $_GET['schedule_id'] ) ) {
			return;
		}

		$schedule_id = absint( $_GET['schedule_id'] );
		// phpcs:enable

		// Verify nonce.
		check_admin_referer( 'tdwp_delete_schedule_' . $schedule_id );

		// Check permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'poker-tournament-import' ) );
		}

		// Delete schedule.
		$result = $this->schedule_manager->delete( $schedule_id );

		// Handle result.
		if ( is_wp_error( $result ) ) {
			wp_safe_redirect(
				add_query_arg(
					array(
						'page'    => 'tdwp-blind-builder',
						'message' => 'error',
						'details' => rawurlencode( $result->get_error_message() ),
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}

		// Redirect to list page.
		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => 'tdwp-blind-builder',
					'message' => 'deleted',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Handle schedule clone
	 *
	 * @since 3.0.0
	 */
	private function handle_clone() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $_GET['schedule_id'] ) ) {
			return;
		}

		$schedule_id = absint( $_GET['schedule_id'] );
		// phpcs:enable

		// Verify nonce.
		check_admin_referer( 'tdwp_clone_schedule_' . $schedule_id );

		// Check permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'poker-tournament-import' ) );
		}

		// Clone schedule.
		$result = $this->schedule_manager->clone_schedule( $schedule_id );

		// Handle result.
		if ( is_wp_error( $result ) ) {
			wp_safe_redirect(
				add_query_arg(
					array(
						'page'    => 'tdwp-blind-builder',
						'message' => 'error',
						'details' => rawurlencode( $result->get_error_message() ),
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}

		// Redirect to edit cloned schedule.
		wp_safe_redirect(
			add_query_arg(
				array(
					'page'        => 'tdwp-blind-builder',
					'action'      => 'edit',
					'schedule_id' => $result,
					'message'     => 'cloned',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * AJAX handler for suggesting a blind schedule
	 *
	 * Accepts starting_chips, player_count, desired_duration, and style from
	 * $_POST and returns a draft schedule (levels array + summary) as JSON.
	 * The caller (blind-builder-admin.js) loads the draft into the level builder
	 * for review and editing before the user saves.
	 *
	 * @since 3.6.1
	 */
	public function ajax_suggest_schedule() {
		// Verify nonce.
		check_ajax_referer( 'tdwp_blind_builder', 'nonce' );

		// Check permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'poker-tournament-import' ) ) );
		}

		$params = array(
			'starting_chips'   => isset( $_POST['starting_chips'] ) ? absint( $_POST['starting_chips'] ) : 10000,
			'player_count'     => isset( $_POST['player_count'] ) ? absint( $_POST['player_count'] ) : 9,
			'desired_duration' => isset( $_POST['desired_duration'] ) ? absint( $_POST['desired_duration'] ) : 180,
			'style'            => isset( $_POST['style'] ) ? sanitize_key( $_POST['style'] ) : 'standard',
		);

		$result = TDWP_Blind_Schedule::suggest_schedule( $params );

		wp_send_json_success( $result );
	}

	/**
	 * AJAX handler: apply a blind schedule/template to a specific tournament.
	 *
	 * Clones the source schedule's levels into a new schedule and stores the
	 * resulting schedule ID on the tournament post via post meta
	 * (_tdwp_blind_schedule_id). If the tournament already has a previously
	 * applied schedule stored in that meta key, its levels are replaced.
	 *
	 * Expected POST params:
	 *   source_schedule_id (int) — the blind schedule to copy from.
	 *   tournament_id      (int) — the tournament post ID to apply it to.
	 *   nonce              (str) — tdwp_blind_builder nonce.
	 *
	 * @since 3.6.2
	 */
	public function ajax_apply_template_to_tournament() {
		// Verify nonce.
		check_ajax_referer( 'tdwp_blind_builder', 'nonce' );

		// Check permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'poker-tournament-import' ) ) );
		}

		$source_id     = isset( $_POST['source_schedule_id'] ) ? absint( $_POST['source_schedule_id'] ) : 0;
		$tournament_id = isset( $_POST['tournament_id'] ) ? absint( $_POST['tournament_id'] ) : 0;

		if ( 0 === $source_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid source schedule ID.', 'poker-tournament-import' ) ) );
		}

		if ( 0 === $tournament_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid tournament ID.', 'poker-tournament-import' ) ) );
		}

		// Verify the source schedule exists.
		$source = $this->schedule_manager->get( $source_id, true );
		if ( null === $source || is_wp_error( $source ) ) {
			wp_send_json_error( array( 'message' => __( 'Source schedule not found.', 'poker-tournament-import' ) ) );
		}

		// Verify the tournament post exists and is the correct post type.
		$post = get_post( $tournament_id );
		if ( null === $post ) {
			wp_send_json_error( array( 'message' => __( 'Tournament not found.', 'poker-tournament-import' ) ) );
		}

		// Reuse the existing schedule if the tournament already has one applied;
		// otherwise create a clone of the source.
		$existing_schedule_id = absint( get_post_meta( $tournament_id, '_tdwp_blind_schedule_id', true ) );

		if ( $existing_schedule_id > 0 ) {
			// Delete existing levels so we can replace them.
			$this->level_manager->delete_by_schedule( $existing_schedule_id );
			$target_schedule_id = $existing_schedule_id;
		} else {
			// Clone the source schedule (creates a new schedule row).
			$target_schedule_id = $this->schedule_manager->clone_schedule( $source_id );

			if ( is_wp_error( $target_schedule_id ) ) {
				wp_send_json_error( array( 'message' => $target_schedule_id->get_error_message() ) );
			}

			// Link to the tournament.
			update_post_meta( $tournament_id, '_tdwp_blind_schedule_id', $target_schedule_id );

			// Bridge (tdwp-cma.26): mirror the schedule ID onto the wizard-compatible
			// '_blind_schedule_id' meta key so any reader that resolves a tournament's
			// blind schedule via that key (set by the wizard on template-apply) also
			// sees the new schedule without requiring a DB join through the templates table.
			update_post_meta( $tournament_id, '_blind_schedule_id', $target_schedule_id );
		}

		// Additionally, update tdwp_tournament_templates.blind_schedule_id when the
		// tournament has a live-state row that links it to a specific template. This
		// ensures the canonical column reflects the applied schedule for any reader
		// that resolves via the templates table (e.g. the wizard status endpoint).
		global $wpdb;
		$live_state = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT template_id FROM {$wpdb->prefix}tdwp_tournament_live_state WHERE tournament_id = %d LIMIT 1",
				$tournament_id
			)
		);

		if ( $live_state && ! empty( $live_state->template_id ) ) {
			$wpdb->update(
				$wpdb->prefix . 'tdwp_tournament_templates',
				array( 'blind_schedule_id' => $target_schedule_id ),
				array( 'id'               => (int) $live_state->template_id ),
				array( '%d' ),
				array( '%d' )
			);
		}

		// Copy levels from source into target schedule.
		if ( ! empty( $source->levels ) ) {
			$order = 1;
			foreach ( $source->levels as $level ) {
				$level_data = array(
					'schedule_id'            => $target_schedule_id,
					'level_order'            => $order,
					'small_blind'            => (int) $level->small_blind,
					'big_blind'              => (int) $level->big_blind,
					'ante'                   => (int) $level->ante,
					'duration_minutes'       => (int) $level->duration_minutes,
					'is_break'               => (int) $level->is_break,
					'break_duration_minutes' => (int) $level->break_duration_minutes,
				);

				$result = $this->level_manager->create( $level_data );

				if ( is_wp_error( $result ) ) {
					wp_send_json_error( array( 'message' => $result->get_error_message() ) );
				}

				$order++;
			}
		}

		wp_send_json_success(
			array(
				'message'            => __( 'Blind schedule applied to tournament successfully.', 'poker-tournament-import' ),
				'schedule_id'        => $target_schedule_id,
				'tournament_id'      => $tournament_id,
				'levels_applied'     => isset( $source->levels ) ? count( $source->levels ) : 0,
			)
		);
	}

	/**
	 * AJAX handler for saving blind levels
	 *
	 * @since 3.0.0
	 */
	public function ajax_save_levels() {
		// Verify nonce.
		check_ajax_referer( 'tdwp_blind_builder', 'nonce' );

		// Check permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'poker-tournament-import' ) ) );
		}

		// Get schedule ID.
		$schedule_id = isset( $_POST['schedule_id'] ) ? absint( $_POST['schedule_id'] ) : 0;

		if ( 0 === $schedule_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid schedule ID.', 'poker-tournament-import' ) ) );
		}

		// Get levels data.
		$levels = isset( $_POST['levels'] ) ? json_decode( wp_unslash( $_POST['levels'] ), true ) : array();

		if ( ! is_array( $levels ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid levels data.', 'poker-tournament-import' ) ) );
		}

		// Delete existing levels.
		$this->level_manager->delete_by_schedule( $schedule_id );

		// Create new levels.
		$order = 1;
		foreach ( $levels as $level ) {
			$level_data = array(
				'schedule_id'            => $schedule_id,
				'level_order'            => $order,
				'small_blind'            => isset( $level['small_blind'] ) ? absint( $level['small_blind'] ) : 0,
				'big_blind'              => isset( $level['big_blind'] ) ? absint( $level['big_blind'] ) : 0,
				'ante'                   => isset( $level['ante'] ) ? absint( $level['ante'] ) : 0,
				'duration_minutes'       => isset( $level['duration_minutes'] ) ? absint( $level['duration_minutes'] ) : 15,
				'is_break'               => isset( $level['is_break'] ) ? absint( $level['is_break'] ) : 0,
				'break_duration_minutes' => isset( $level['break_duration_minutes'] ) ? absint( $level['break_duration_minutes'] ) : 0,
			);

			$result = $this->level_manager->create( $level_data );

			if ( is_wp_error( $result ) ) {
				wp_send_json_error( array( 'message' => $result->get_error_message() ) );
			}

			$order++;
		}

		wp_send_json_success( array( 'message' => __( 'Levels saved successfully.', 'poker-tournament-import' ) ) );
	}

	/**
	 * AJAX handler for getting blind levels
	 *
	 * @since 3.0.0
	 */
	public function ajax_get_levels() {
		// Verify nonce.
		check_ajax_referer( 'tdwp_blind_builder', 'nonce' );

		// Check permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'poker-tournament-import' ) ) );
		}

		// Get schedule ID.
		$schedule_id = isset( $_GET['schedule_id'] ) ? absint( $_GET['schedule_id'] ) : 0;

		if ( 0 === $schedule_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid schedule ID.', 'poker-tournament-import' ) ) );
		}

		// Get levels.
		$levels = $this->schedule_manager->get_levels( $schedule_id );

		wp_send_json_success( array( 'levels' => $levels ) );
	}

	/**
	 * Render main page
	 *
	 * @since 3.0.0
	 */
	public function render_page() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$action      = isset( $_GET['action'] ) ? sanitize_text_field( wp_unslash( $_GET['action'] ) ) : 'list';
		$schedule_id = isset( $_GET['schedule_id'] ) ? absint( $_GET['schedule_id'] ) : 0;
		$message     = isset( $_GET['message'] ) ? sanitize_text_field( wp_unslash( $_GET['message'] ) ) : '';
		// phpcs:enable

		?>
		<div class="wrap tdwp-blind-builder">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Blind Builder', 'poker-tournament-import' ); ?></h1>

			<?php if ( 'list' === $action ) : ?>
				<a href="<?php echo esc_url( add_query_arg( array( 'page' => 'tdwp-blind-builder', 'action' => 'new' ), admin_url( 'admin.php' ) ) ); ?>" class="page-title-action">
					<?php esc_html_e( 'Add New Schedule', 'poker-tournament-import' ); ?>
				</a>
			<?php elseif ( 'edit' === $action && $schedule_id > 0 ) : ?>
				<a href="<?php echo esc_url( add_query_arg( array( 'page' => 'tdwp-blind-builder' ), admin_url( 'admin.php' ) ) ); ?>" class="page-title-action">
					<?php esc_html_e( 'Back to Schedules', 'poker-tournament-import' ); ?>
				</a>
			<?php endif; ?>

			<hr class="wp-header-end">

			<?php $this->display_messages( $message ); ?>

			<?php
			if ( 'new' === $action || 'edit' === $action ) {
				$this->render_form( $schedule_id );
			} else {
				$this->render_list();
			}
			?>
		</div>
		<?php
	}

	/**
	 * Display admin messages
	 *
	 * @since 3.0.0
	 *
	 * @param string $message Message type.
	 */
	private function display_messages( $message ) {
		if ( empty( $message ) ) {
			return;
		}

		$messages = array(
			'created' => __( 'Schedule created successfully.', 'poker-tournament-import' ),
			'updated' => __( 'Schedule updated successfully.', 'poker-tournament-import' ),
			'deleted' => __( 'Schedule deleted successfully.', 'poker-tournament-import' ),
			'cloned'  => __( 'Schedule cloned successfully.', 'poker-tournament-import' ),
		);

		if ( 'error' === $message ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$details = isset( $_GET['details'] ) ? sanitize_text_field( wp_unslash( $_GET['details'] ) ) : '';
			?>
			<div class="notice notice-error is-dismissible">
				<p><?php echo esc_html( $details ); ?></p>
			</div>
			<?php
		} elseif ( isset( $messages[ $message ] ) ) {
			?>
			<div class="notice notice-success is-dismissible">
				<p><?php echo esc_html( $messages[ $message ] ); ?></p>
			</div>
			<?php
		}
	}

	/**
	 * Render schedules list
	 *
	 * @since 3.0.0
	 */
	private function render_list() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$search      = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$paged       = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		// phpcs:enable
		$per_page    = 20;

		$args = array(
			'search'      => $search,
			'page'        => $paged,
			'per_page'    => $per_page,
			'with_levels' => false,
		);

		$schedules = $this->schedule_manager->get_all( $args );
		$total     = $this->schedule_manager->get_total( array( 'search' => $search ) );

		?>
		<form method="get">
			<input type="hidden" name="page" value="tdwp-blind-builder">
			<?php
			wp_nonce_field( 'tdwp_blind_builder_search', 'search_nonce' );
			?>
			<p class="search-box">
				<label class="screen-reader-text" for="schedule-search-input"><?php esc_html_e( 'Search Schedules:', 'poker-tournament-import' ); ?></label>
				<input type="search" id="schedule-search-input" name="s" value="<?php echo esc_attr( $search ); ?>">
				<input type="submit" id="search-submit" class="button" value="<?php esc_attr_e( 'Search Schedules', 'poker-tournament-import' ); ?>">
			</p>
		</form>

		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th scope="col" class="column-name"><?php esc_html_e( 'Name', 'poker-tournament-import' ); ?></th>
					<th scope="col" class="column-duration"><?php esc_html_e( 'Level Duration', 'poker-tournament-import' ); ?></th>
					<th scope="col" class="column-breaks"><?php esc_html_e( 'Breaks', 'poker-tournament-import' ); ?></th>
					<th scope="col" class="column-levels"><?php esc_html_e( 'Levels', 'poker-tournament-import' ); ?></th>
					<th scope="col" class="column-date"><?php esc_html_e( 'Created', 'poker-tournament-import' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( empty( $schedules ) ) : ?>
					<tr>
						<td colspan="5"><?php esc_html_e( 'No schedules found.', 'poker-tournament-import' ); ?></td>
					</tr>
				<?php else : ?>
					<?php foreach ( $schedules as $schedule ) : ?>
						<?php
						$levels = $this->schedule_manager->get_levels( $schedule->id );
						$edit_url = add_query_arg(
							array(
								'page'        => 'tdwp-blind-builder',
								'action'      => 'edit',
								'schedule_id' => $schedule->id,
							),
							admin_url( 'admin.php' )
						);
						$delete_url = wp_nonce_url(
							add_query_arg(
								array(
									'page'        => 'tdwp-blind-builder',
									'action'      => 'delete',
									'schedule_id' => $schedule->id,
								),
								admin_url( 'admin.php' )
							),
							'tdwp_delete_schedule_' . $schedule->id
						);
						$clone_url = wp_nonce_url(
							add_query_arg(
								array(
									'page'        => 'tdwp-blind-builder',
									'action'      => 'clone',
									'schedule_id' => $schedule->id,
								),
								admin_url( 'admin.php' )
							),
							'tdwp_clone_schedule_' . $schedule->id
						);
						$print_url = wp_nonce_url(
							add_query_arg(
								array(
									'action'      => 'tdwp_print_blind_schedule',
									'schedule_id' => $schedule->id,
								),
								admin_url( 'admin-ajax.php' )
							),
							'tdwp_print_blind_schedule',
							'nonce'
						);
						?>
						<tr>
							<td class="column-name">
								<strong>
									<a href="<?php echo esc_url( $edit_url ); ?>">
										<?php echo esc_html( $schedule->name ); ?>
									</a>
								</strong>
								<div class="row-actions">
									<span class="edit">
										<a href="<?php echo esc_url( $edit_url ); ?>"><?php esc_html_e( 'Edit', 'poker-tournament-import' ); ?></a> |
									</span>
									<span class="clone">
										<a href="<?php echo esc_url( $clone_url ); ?>"><?php esc_html_e( 'Clone', 'poker-tournament-import' ); ?></a> |
									</span>
									<span class="print">
										<a href="<?php echo esc_url( $print_url ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Print', 'poker-tournament-import' ); ?></a> |
									</span>
									<span class="delete">
										<a href="<?php echo esc_url( $delete_url ); ?>" class="submitdelete"><?php esc_html_e( 'Delete', 'poker-tournament-import' ); ?></a>
									</span>
								</div>
							</td>
							<td class="column-duration">
								<?php
								/* translators: %d: level duration in minutes */
								echo esc_html( sprintf( __( '%d minutes', 'poker-tournament-import' ), $schedule->level_duration ) );
								?>
							</td>
							<td class="column-breaks">
								<?php if ( $schedule->break_frequency > 0 ) : ?>
									<?php
									/* translators: 1: break frequency, 2: break duration */
									echo esc_html( sprintf( __( 'Every %1$d levels (%2$d min)', 'poker-tournament-import' ), $schedule->break_frequency, $schedule->break_duration ) );
									?>
								<?php else : ?>
									<?php esc_html_e( 'None', 'poker-tournament-import' ); ?>
								<?php endif; ?>
							</td>
							<td class="column-levels">
								<?php echo absint( count( $levels ) ); ?>
							</td>
							<td class="column-date">
								<?php echo esc_html( mysql2date( get_option( 'date_format' ), $schedule->created_at ) ); ?>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>

		<?php $this->render_csv_import_form(); ?>

		<?php
		// Pagination.
		$total_pages = ceil( $total / $per_page );
		if ( $total_pages > 1 ) {
			?>
			<div class="tablenav bottom">
				<div class="tablenav-pages">
					<?php
					echo wp_kses(
						paginate_links(
							array(
								'base'      => add_query_arg( 'paged', '%#%' ),
								'format'    => '',
								'current'   => $paged,
								'total'     => $total_pages,
								'prev_text' => __( '&laquo; Previous', 'poker-tournament-import' ),
								'next_text' => __( 'Next &raquo;', 'poker-tournament-import' ),
							)
						),
						array(
							'a'    => array(
								'class' => array(),
								'href'  => array(),
							),
							'span' => array(
								'class'       => array(),
								'aria-hidden' => array(),
							),
						)
					);
					?>
				</div>
			</div>
			<?php
		}
	}

	/**
	 * Render schedule form
	 *
	 * @since 3.0.0
	 *
	 * @param int $schedule_id Schedule ID (0 for new).
	 */
	private function render_form( $schedule_id ) {
		$schedule = null;
		$levels   = array();

		if ( $schedule_id > 0 ) {
			$schedule = $this->schedule_manager->get( $schedule_id, true );

			if ( null === $schedule ) {
				?>
				<div class="notice notice-error">
					<p><?php esc_html_e( 'Schedule not found.', 'poker-tournament-import' ); ?></p>
				</div>
				<?php
				return;
			}

			$levels = isset( $schedule->levels ) ? $schedule->levels : array();
		}

		?>
		<form method="post" action="<?php echo esc_url( add_query_arg( array( 'page' => 'tdwp-blind-builder', 'action' => 'save' ), admin_url( 'admin.php' ) ) ); ?>" class="tdwp-schedule-form">
			<?php wp_nonce_field( 'tdwp_save_schedule_' . $schedule_id, 'schedule_nonce' ); ?>
			<input type="hidden" name="schedule_id" value="<?php echo esc_attr( $schedule_id ); ?>">

			<h2><?php echo $schedule_id > 0 ? esc_html__( 'Edit Schedule', 'poker-tournament-import' ) : esc_html__( 'New Schedule', 'poker-tournament-import' ); ?></h2>

			<table class="form-table">
				<tbody>
					<tr>
						<th scope="row">
							<label for="schedule-name"><?php esc_html_e( 'Schedule Name', 'poker-tournament-import' ); ?> <span class="required">*</span></label>
						</th>
						<td>
							<input type="text" name="name" id="schedule-name" class="regular-text" value="<?php echo $schedule ? esc_attr( $schedule->name ) : ''; ?>" required>
							<p class="description"><?php esc_html_e( 'Enter a descriptive name for this blind schedule.', 'poker-tournament-import' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="schedule-description"><?php esc_html_e( 'Description', 'poker-tournament-import' ); ?></label>
						</th>
						<td>
							<textarea name="description" id="schedule-description" rows="3" class="large-text"><?php echo $schedule ? esc_textarea( $schedule->description ) : ''; ?></textarea>
							<p class="description"><?php esc_html_e( 'Optional description of this blind schedule.', 'poker-tournament-import' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="level-duration"><?php esc_html_e( 'Level Duration', 'poker-tournament-import' ); ?> <span class="required">*</span></label>
						</th>
						<td>
							<input type="number" name="level_duration" id="level-duration" class="small-text" value="<?php echo $schedule ? esc_attr( $schedule->level_duration ) : '15'; ?>" min="1" max="120" required>
							<span><?php esc_html_e( 'minutes', 'poker-tournament-import' ); ?></span>
							<p class="description"><?php esc_html_e( 'Duration of each blind level in minutes.', 'poker-tournament-import' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="break-frequency"><?php esc_html_e( 'Break Frequency', 'poker-tournament-import' ); ?></label>
						</th>
						<td>
							<input type="number" name="break_frequency" id="break-frequency" class="small-text" value="<?php echo $schedule ? esc_attr( $schedule->break_frequency ) : '0'; ?>" min="0" max="20">
							<span><?php esc_html_e( 'levels (0 for no auto-breaks)', 'poker-tournament-import' ); ?></span>
							<p class="description"><?php esc_html_e( 'Automatically insert breaks every X levels.', 'poker-tournament-import' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="break-duration"><?php esc_html_e( 'Break Duration', 'poker-tournament-import' ); ?></label>
						</th>
						<td>
							<input type="number" name="break_duration" id="break-duration" class="small-text" value="<?php echo $schedule ? esc_attr( $schedule->break_duration ) : '0'; ?>" min="0" max="60">
							<span><?php esc_html_e( 'minutes', 'poker-tournament-import' ); ?></span>
							<p class="description"><?php esc_html_e( 'Duration of automatic breaks.', 'poker-tournament-import' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<?php esc_html_e( 'Default Templates', 'poker-tournament-import' ); ?>
						</th>
						<td>
							<fieldset>
								<label>
									<input type="checkbox" name="is_default_turbo" value="1" <?php checked( $schedule && $schedule->is_default_turbo, 1 ); ?>>
									<?php esc_html_e( 'Turbo Default', 'poker-tournament-import' ); ?>
								</label><br>
								<label>
									<input type="checkbox" name="is_default_regular" value="1" <?php checked( $schedule && $schedule->is_default_regular, 1 ); ?>>
									<?php esc_html_e( 'Regular Default', 'poker-tournament-import' ); ?>
								</label><br>
								<label>
									<input type="checkbox" name="is_default_deep" value="1" <?php checked( $schedule && $schedule->is_default_deep, 1 ); ?>>
									<?php esc_html_e( 'Deep Stack Default', 'poker-tournament-import' ); ?>
								</label>
								<p class="description"><?php esc_html_e( 'Mark this schedule as default for template suggestions.', 'poker-tournament-import' ); ?></p>
							</fieldset>
						</td>
					</tr>
				</tbody>
			</table>

			<p class="submit">
				<input type="submit" name="submit" id="submit" class="button button-primary" value="<?php esc_attr_e( 'Save Schedule', 'poker-tournament-import' ); ?>">
			</p>
		</form>

		<?php if ( $schedule_id > 0 ) : ?>
			<hr>
			<h2><?php esc_html_e( 'Blind Levels', 'poker-tournament-import' ); ?></h2>
			<?php $this->render_level_builder( $schedule_id, $levels ); ?>
		<?php endif; ?>
		<?php
	}

	/**
	 * Render level builder
	 *
	 * @since 3.0.0
	 *
	 * @param int   $schedule_id Schedule ID.
	 * @param array $levels      Existing levels.
	 */
	private function render_level_builder( $schedule_id, $levels ) {
		?>
		<div class="tdwp-level-builder" data-schedule-id="<?php echo esc_attr( $schedule_id ); ?>">
			<div class="tdwp-suggest-schedule-panel">
				<h3><?php esc_html_e( 'Suggest Schedule', 'poker-tournament-import' ); ?></h3>
				<p class="description"><?php esc_html_e( 'Generate a draft blind schedule from your tournament parameters. You can edit or discard it afterwards.', 'poker-tournament-import' ); ?></p>
				<div class="tdwp-suggest-fields">
					<label>
						<?php esc_html_e( 'Starting Chips', 'poker-tournament-import' ); ?>
						<input type="number" id="suggest-starting-chips" value="10000" min="500" step="500" class="small-text">
					</label>
					<label>
						<?php esc_html_e( 'Players', 'poker-tournament-import' ); ?>
						<input type="number" id="suggest-player-count" value="9" min="2" max="500" class="small-text">
					</label>
					<label>
						<?php esc_html_e( 'Target Duration (min)', 'poker-tournament-import' ); ?>
						<input type="number" id="suggest-duration" value="180" min="20" max="1440" class="small-text">
					</label>
					<label>
						<?php esc_html_e( 'Style', 'poker-tournament-import' ); ?>
						<select id="suggest-style">
							<option value="turbo"><?php esc_html_e( 'Turbo (~10 min/level)', 'poker-tournament-import' ); ?></option>
							<option value="standard" selected><?php esc_html_e( 'Standard (~15 min/level)', 'poker-tournament-import' ); ?></option>
							<option value="deep"><?php esc_html_e( 'Deep Stack (~25 min/level)', 'poker-tournament-import' ); ?></option>
						</select>
					</label>
					<button type="button" class="button button-secondary" id="generate-schedule">
						<?php esc_html_e( 'Generate', 'poker-tournament-import' ); ?>
					</button>
				</div>
				<p id="suggest-summary" class="tdwp-suggest-summary" style="display:none;"></p>
			</div>

			<div class="level-builder-controls">
				<button type="button" class="button button-secondary" id="add-blind-level">
					<?php esc_html_e( 'Add Blind Level', 'poker-tournament-import' ); ?>
				</button>
				<button type="button" class="button button-secondary" id="add-break-level">
					<?php esc_html_e( 'Add Break', 'poker-tournament-import' ); ?>
				</button>
				<button type="button" class="button button-primary" id="save-levels">
					<?php esc_html_e( 'Save All Levels', 'poker-tournament-import' ); ?>
				</button>
			</div>

			<div class="levels-list-container">
				<table class="wp-list-table widefat fixed striped levels-list">
					<thead>
						<tr>
							<th class="column-drag">&nbsp;</th>
							<th class="column-order"><?php esc_html_e( '#', 'poker-tournament-import' ); ?></th>
							<th class="column-sb"><?php esc_html_e( 'Small Blind', 'poker-tournament-import' ); ?></th>
							<th class="column-bb"><?php esc_html_e( 'Big Blind', 'poker-tournament-import' ); ?></th>
							<th class="column-ante"><?php esc_html_e( 'Ante', 'poker-tournament-import' ); ?></th>
							<th class="column-type"><?php esc_html_e( 'Type', 'poker-tournament-import' ); ?></th>
							<th class="column-actions"><?php esc_html_e( 'Actions', 'poker-tournament-import' ); ?></th>
						</tr>
					</thead>
					<tbody id="levels-sortable">
						<?php if ( ! empty( $levels ) ) : ?>
							<?php foreach ( $levels as $level ) : ?>
								<?php $this->render_level_row( $level ); ?>
							<?php endforeach; ?>
						<?php else : ?>
							<tr class="no-levels">
								<td colspan="7"><?php esc_html_e( 'No levels yet. Click "Add Blind Level" to get started.', 'poker-tournament-import' ); ?></td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>
			</div>

			<div class="level-preview">
				<h3><?php esc_html_e( 'Schedule Preview', 'poker-tournament-import' ); ?></h3>
				<div id="schedule-preview"></div>
			</div>

			<div class="tdwp-apply-template-panel">
				<h3><?php esc_html_e( 'Apply to Tournament', 'poker-tournament-import' ); ?></h3>
				<p class="description">
					<?php esc_html_e( 'Copy this schedule\'s levels into a specific tournament. The tournament will receive its own editable copy of the levels.', 'poker-tournament-import' ); ?>
				</p>
				<div class="tdwp-apply-fields">
					<label for="apply-tournament-id">
						<?php esc_html_e( 'Tournament ID', 'poker-tournament-import' ); ?>
						<input type="number" id="apply-tournament-id" min="1" class="small-text" placeholder="<?php esc_attr_e( 'e.g. 42', 'poker-tournament-import' ); ?>">
					</label>
					<button type="button" id="apply-template-to-tournament" class="button button-secondary"
						data-schedule-id="<?php echo esc_attr( $schedule_id ); ?>">
						<?php esc_html_e( 'Apply Schedule', 'poker-tournament-import' ); ?>
					</button>
				</div>
				<p id="apply-template-result" class="tdwp-apply-result" style="display:none;"></p>
			</div>
		</div>

		<!-- Level row template -->
		<script type="text/template" id="blind-level-template">
			<tr class="level-row" data-level-type="blind">
				<td class="column-drag"><span class="dashicons dashicons-menu"></span></td>
				<td class="column-order"><span class="level-number">1</span></td>
				<td class="column-sb"><input type="number" class="small-blind" value="25" min="1"></td>
				<td class="column-bb"><input type="number" class="big-blind" value="50" min="1"></td>
				<td class="column-ante"><input type="number" class="ante" value="0" min="0"></td>
				<td class="column-type"><?php esc_html_e( 'Blind Level', 'poker-tournament-import' ); ?></td>
				<td class="column-actions">
					<button type="button" class="button button-small delete-level"><?php esc_html_e( 'Delete', 'poker-tournament-import' ); ?></button>
				</td>
			</tr>
		</script>

		<script type="text/template" id="break-level-template">
			<tr class="level-row level-break" data-level-type="break">
				<td class="column-drag"><span class="dashicons dashicons-menu"></span></td>
				<td class="column-order"><span class="level-number">1</span></td>
				<td class="column-sb" colspan="3">
					<strong><?php esc_html_e( 'BREAK', 'poker-tournament-import' ); ?></strong> -
					<input type="number" class="break-length" value="15" min="1" max="60"> <?php esc_html_e( 'minutes', 'poker-tournament-import' ); ?>
				</td>
				<td class="column-type"><?php esc_html_e( 'Break', 'poker-tournament-import' ); ?></td>
				<td class="column-actions">
					<button type="button" class="button button-small delete-level"><?php esc_html_e( 'Delete', 'poker-tournament-import' ); ?></button>
				</td>
			</tr>
		</script>
		<?php
	}

	/**
	 * Render single level row
	 *
	 * @since 3.0.0
	 *
	 * @param object $level Level object.
	 */
	private function render_level_row( $level ) {
		if ( 1 === absint( $level->is_break ) ) {
			?>
			<tr class="level-row level-break" data-level-type="break">
				<td class="column-drag"><span class="dashicons dashicons-menu"></span></td>
				<td class="column-order"><span class="level-number"><?php echo esc_html( $level->level_order ); ?></span></td>
				<td class="column-sb" colspan="3">
					<strong><?php esc_html_e( 'BREAK', 'poker-tournament-import' ); ?></strong> -
					<input type="number" class="break-length" value="<?php echo esc_attr( $level->break_duration_minutes ); ?>" min="1" max="60"> <?php esc_html_e( 'minutes', 'poker-tournament-import' ); ?>
				</td>
				<td class="column-type"><?php esc_html_e( 'Break', 'poker-tournament-import' ); ?></td>
				<td class="column-actions">
					<button type="button" class="button button-small delete-level"><?php esc_html_e( 'Delete', 'poker-tournament-import' ); ?></button>
				</td>
			</tr>
			<?php
		} else {
			?>
			<tr class="level-row" data-level-type="blind">
				<td class="column-drag"><span class="dashicons dashicons-menu"></span></td>
				<td class="column-order"><span class="level-number"><?php echo esc_html( $level->level_order ); ?></span></td>
				<td class="column-sb"><input type="number" class="small-blind" value="<?php echo esc_attr( $level->small_blind ); ?>" min="1"></td>
				<td class="column-bb"><input type="number" class="big-blind" value="<?php echo esc_attr( $level->big_blind ); ?>" min="1"></td>
				<td class="column-ante"><input type="number" class="ante" value="<?php echo esc_attr( $level->ante ); ?>" min="0"></td>
				<td class="column-type"><?php esc_html_e( 'Blind Level', 'poker-tournament-import' ); ?></td>
				<td class="column-actions">
					<button type="button" class="button button-small delete-level"><?php esc_html_e( 'Delete', 'poker-tournament-import' ); ?></button>
				</td>
			</tr>
			<?php
		}
	}
	/**
	 * Render the CSV import form for blind schedules.
	 *
	 * Displayed inline on the schedule list page.
	 *
	 * @since 3.7.0
	 */
	private function render_csv_import_form() {
		?>
		<div class="tdwp-blind-csv-import" style="margin-top:2em;">
			<h2><?php esc_html_e( 'Import Blind Schedule from CSV', 'poker-tournament-import' ); ?></h2>
			<p class="description">
				<?php
				esc_html_e(
					'Upload a CSV with columns: small_blind, big_blind, ante, duration_minutes, is_break, break_duration_minutes. The first row must be a header.',
					'poker-tournament-import'
				);
				?>
			</p>
			<form method="post" enctype="multipart/form-data" id="tdwp-blind-csv-import-form">
				<?php wp_nonce_field( 'tdwp_import_blind_csv', 'tdwp_import_blind_nonce' ); ?>
				<input type="hidden" name="action" value="tdwp_import_blind_csv">
				<table class="form-table">
					<tr>
						<th scope="row">
							<label for="tdwp-blind-csv-schedule-name"><?php esc_html_e( 'Schedule Name', 'poker-tournament-import' ); ?></label>
						</th>
						<td>
							<input type="text"
								id="tdwp-blind-csv-schedule-name"
								name="schedule_name"
								class="regular-text"
								required
								placeholder="<?php esc_attr_e( 'e.g. Friday Night 20-min Levels', 'poker-tournament-import' ); ?>">
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="tdwp-blind-csv-file"><?php esc_html_e( 'CSV File', 'poker-tournament-import' ); ?></label>
						</th>
						<td>
							<input type="file" id="tdwp-blind-csv-file" name="blind_csv" accept=".csv">
						</td>
					</tr>
				</table>
				<?php submit_button( __( 'Import Schedule', 'poker-tournament-import' ), 'secondary', 'tdwp_blind_csv_submit' ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * AJAX: output a print-friendly blind schedule HTML page.
	 *
	 * Opens as a standalone page the user can print or save-as-PDF via the browser.
	 *
	 * @since 3.7.0
	 */
	public function ajax_print_blind_schedule() {
		check_ajax_referer( 'tdwp_print_blind_schedule', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'poker-tournament-import' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$schedule_id = isset( $_GET['schedule_id'] ) ? absint( $_GET['schedule_id'] ) : 0;

		if ( 0 === $schedule_id ) {
			wp_die( esc_html__( 'Invalid schedule ID.', 'poker-tournament-import' ) );
		}

		$schedule = $this->schedule_manager->get( $schedule_id );

		if ( null === $schedule || is_wp_error( $schedule ) ) {
			wp_die( esc_html__( 'Schedule not found.', 'poker-tournament-import' ) );
		}

		$levels     = $this->schedule_manager->get_levels( $schedule_id );
		$print_date = date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) );
		$css_url    = esc_url( POKER_TOURNAMENT_IMPORT_PLUGIN_URL . 'assets/css/tdwp-print.css' );
		$site_name  = esc_html( get_bloginfo( 'name' ) );

		// Calculate totals.
		$total_minutes = 0;
		foreach ( $levels as $level ) {
			$total_minutes += absint( $level->duration_minutes );
		}
		$total_time = sprintf(
			/* translators: 1: hours, 2: minutes */
			__( '%1$dh %2$dm', 'poker-tournament-import' ),
			floor( $total_minutes / 60 ),
			$total_minutes % 60
		);

		header( 'Content-Type: text/html; charset=UTF-8' );
		?>
<!DOCTYPE html>
<html lang="<?php echo esc_attr( get_bloginfo( 'language' ) ); ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $site_name; ?> &mdash; <?php echo esc_html( $schedule->name ); ?></title>
<link rel="stylesheet" href="<?php echo $css_url; ?>">
</head>
<body>
<h1><?php echo esc_html( $schedule->name ); ?></h1>
<p class="tdwp-print-meta">
	<?php echo $site_name; ?> &mdash;
	<?php
	echo esc_html(
		sprintf(
			/* translators: 1: level count, 2: total time, 3: print date */
			__( '%1$d levels &bull; Total time: %2$s &bull; Printed %3$s', 'poker-tournament-import' ),
			count( $levels ),
			$total_time,
			$print_date
		)
	);
	?>
</p>

<div class="tdwp-print-actions">
	<button class="tdwp-print-btn" onclick="window.print()">
		<?php esc_html_e( 'Print / Save as PDF', 'poker-tournament-import' ); ?>
	</button>
</div>

<?php if ( empty( $levels ) ) : ?>
	<p><?php esc_html_e( 'No levels found for this schedule.', 'poker-tournament-import' ); ?></p>
<?php else : ?>
<table>
	<thead>
		<tr>
			<th><?php esc_html_e( '#', 'poker-tournament-import' ); ?></th>
			<th><?php esc_html_e( 'Small Blind', 'poker-tournament-import' ); ?></th>
			<th><?php esc_html_e( 'Big Blind', 'poker-tournament-import' ); ?></th>
			<th><?php esc_html_e( 'Ante', 'poker-tournament-import' ); ?></th>
			<th><?php esc_html_e( 'Duration', 'poker-tournament-import' ); ?></th>
			<th><?php esc_html_e( 'Type', 'poker-tournament-import' ); ?></th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ( $levels as $level ) : ?>
		<?php $is_break = 1 === absint( $level->is_break ); ?>
		<tr<?php echo $is_break ? ' class="tdwp-break-row"' : ''; ?>>
			<td><?php echo esc_html( $level->level_order ); ?></td>
			<?php if ( $is_break ) : ?>
			<td colspan="3"><?php esc_html_e( '— Break —', 'poker-tournament-import' ); ?></td>
			<?php else : ?>
			<td><?php echo esc_html( number_format_i18n( $level->small_blind ) ); ?></td>
			<td><?php echo esc_html( number_format_i18n( $level->big_blind ) ); ?></td>
			<td><?php echo esc_html( number_format_i18n( $level->ante ) ); ?></td>
			<?php endif; ?>
			<td>
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d: duration in minutes */
						__( '%d min', 'poker-tournament-import' ),
						$level->duration_minutes
					)
				);
				?>
			</td>
			<td>
				<?php echo $is_break ? esc_html__( 'Break', 'poker-tournament-import' ) : esc_html__( 'Blind', 'poker-tournament-import' ); ?>
			</td>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>
<?php endif; ?>
</body>
</html>
		<?php
		exit;
	}

	/**
	 * AJAX: import a blind schedule from an uploaded CSV file.
	 *
	 * Creates a new schedule + bulk-inserts validated levels.
	 * Reports per-row errors in the same format as the player importer.
	 *
	 * @since 3.7.0
	 */
	public function ajax_import_blind_csv() {
		// Verify nonce (POST form, not wp_ajax in the typical sense — we use admin_post
		// behaviour via the form submit, but register as AJAX for flexibility).
		if ( ! isset( $_POST['tdwp_import_blind_nonce'] )
			|| ! wp_verify_nonce( sanitize_key( $_POST['tdwp_import_blind_nonce'] ), 'tdwp_import_blind_csv' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'poker-tournament-import' ) );
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'poker-tournament-import' ) );
		}

		$schedule_name = isset( $_POST['schedule_name'] ) ? sanitize_text_field( wp_unslash( $_POST['schedule_name'] ) ) : '';

		if ( empty( $schedule_name ) ) {
			wp_redirect(
				add_query_arg(
					array(
						'page'    => 'tdwp-blind-builder',
						'message' => 'error',
						'details' => urlencode( __( 'Schedule name is required.', 'poker-tournament-import' ) ),
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}

		// Validate uploaded file.
		if ( empty( $_FILES['blind_csv']['tmp_name'] ) || ! is_uploaded_file( $_FILES['blind_csv']['tmp_name'] ) ) {
			wp_redirect(
				add_query_arg(
					array(
						'page'    => 'tdwp-blind-builder',
						'message' => 'error',
						'details' => urlencode( __( 'Please select a CSV file to upload.', 'poker-tournament-import' ) ),
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}

		$file_name = isset( $_FILES['blind_csv']['name'] ) ? sanitize_file_name( wp_unslash( $_FILES['blind_csv']['name'] ) ) : '';
		$extension = strtolower( pathinfo( $file_name, PATHINFO_EXTENSION ) );

		if ( 'csv' !== $extension ) {
			wp_redirect(
				add_query_arg(
					array(
						'page'    => 'tdwp-blind-builder',
						'message' => 'error',
						'details' => urlencode( __( 'Only CSV files are supported.', 'poker-tournament-import' ) ),
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}

		// phpcs:disable WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$content = file_get_contents( $_FILES['blind_csv']['tmp_name'] );
		// phpcs:enable

		if ( false === $content ) {
			wp_redirect(
				add_query_arg(
					array(
						'page'    => 'tdwp-blind-builder',
						'message' => 'error',
						'details' => urlencode( __( 'Failed to read uploaded file.', 'poker-tournament-import' ) ),
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}

		$importer = new TDWP_Blind_CSV_Importer();
		$parsed   = $importer->parse_csv_content( $content );

		if ( 0 === $parsed['valid'] ) {
			$error_summary = __( 'No valid rows found in CSV.', 'poker-tournament-import' );
			if ( ! empty( $parsed['errors'] ) ) {
				$first = $parsed['errors'][0];
				$error_summary = $first['message'];
			}
			wp_redirect(
				add_query_arg(
					array(
						'page'    => 'tdwp-blind-builder',
						'message' => 'error',
						'details' => urlencode( $error_summary ),
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}

		// Create the new schedule.
		$schedule_id = $this->schedule_manager->create(
			array(
				'name'        => $schedule_name,
				'description' => '',
			)
		);

		if ( is_wp_error( $schedule_id ) ) {
			wp_redirect(
				add_query_arg(
					array(
						'page'    => 'tdwp-blind-builder',
						'message' => 'error',
						'details' => urlencode( $schedule_id->get_error_message() ),
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}

		// Normalize and bulk-insert levels.
		$levels      = $importer->normalize_rows( $parsed['rows'] );
		$insert_result = $this->level_manager->bulk_create( $schedule_id, $levels );

		if ( is_wp_error( $insert_result ) ) {
			wp_redirect(
				add_query_arg(
					array(
						'page'    => 'tdwp-blind-builder',
						'message' => 'error',
						'details' => urlencode( $insert_result->get_error_message() ),
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}

		wp_redirect(
			add_query_arg(
				array(
					'page'    => 'tdwp-blind-builder',
					'message' => 'created',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}
}

// Initialize the page.
new TDWP_Blind_Builder_Page();
