/**
 * Blind Builder Admin JavaScript
 *
 * @package Poker_Tournament_Import
 * @subpackage Tournament_Manager
 * @since 3.0.0
 */

(function ($) {
  'use strict';

  /**
   * Blind Builder Manager
   *
   * @since 3.0.0
   */
  var TDWPBlindBuilder = {
    /**
     * Initialize
     *
     * @since 3.0.0
     */
    init: function () {
      this.bindEvents();
      this.initSortable();
      this.updatePreview();
    },

    /**
     * Bind event handlers
     *
     * @since 3.0.0
     */
    bindEvents: function () {
      // Delete confirmation
      $('.submitdelete').on('click', function (e) {
        if (!confirm(tdwpBlindBuilder.i18n.confirmDelete)) {
          e.preventDefault();
          return false;
        }
      });

      // Add blind level
      $('#add-blind-level').on('click', this.addBlindLevel.bind(this));

      // Add break level
      $('#add-break-level').on('click', this.addBreakLevel.bind(this));

      // Delete level
      $(document).on('click', '.delete-level', this.deleteLevel.bind(this));

      // Save levels
      $('#save-levels').on('click', this.saveLevels.bind(this));

      // Suggest schedule
      $('#generate-schedule').on('click', this.suggestSchedule.bind(this));

      // Apply schedule to tournament
      $('#apply-template-to-tournament').on('click', this.applyTemplateToTournament.bind(this));

      // Update preview on input change
      $(document).on('input', '.level-row input', this.updatePreview.bind(this));
    },

    /**
     * Initialize sortable functionality
     *
     * @since 3.0.0
     */
    initSortable: function () {
      var self = this;

      $('#levels-sortable').sortable({
        handle: '.column-drag',
        placeholder: 'ui-sortable-placeholder',
        cursor: 'move',
        axis: 'y',
        opacity: 0.8,
        update: function () {
          self.renumberLevels();
          self.updatePreview();
        },
      });
    },

    /**
     * Add blind level
     *
     * @since 3.0.0
     */
    addBlindLevel: function () {
      var template = $('#blind-level-template').html();
      var $row = $(template);

      // Remove "no levels" message if present
      $('.no-levels').remove();

      // Append to table
      $('#levels-sortable').append($row);

      // Renumber and update preview
      this.renumberLevels();
      this.updatePreview();

      // Focus first input
      $row.find('.small-blind').focus();
    },

    /**
     * Add break level
     *
     * @since 3.0.0
     */
    addBreakLevel: function () {
      var template = $('#break-level-template').html();
      var $row = $(template);

      // Remove "no levels" message if present
      $('.no-levels').remove();

      // Append to table
      $('#levels-sortable').append($row);

      // Renumber and update preview
      this.renumberLevels();
      this.updatePreview();

      // Focus break length input
      $row.find('.break-length').focus();
    },

    /**
     * Delete level
     *
     * @since 3.0.0
     */
    deleteLevel: function (e) {
      e.preventDefault();

      if (!confirm(tdwpBlindBuilder.i18n.confirmDeleteLevel)) {
        return;
      }

      $(e.currentTarget).closest('.level-row').remove();

      // Show "no levels" message if no levels remain
      if ($('#levels-sortable .level-row').length === 0) {
        $('#levels-sortable').html(
          '<tr class="no-levels"><td colspan="7">' +
            'No levels yet. Click "Add Blind Level" to get started.</td></tr>'
        );
      }

      this.renumberLevels();
      this.updatePreview();
    },

    /**
     * Renumber levels
     *
     * @since 3.0.0
     */
    renumberLevels: function () {
      $('#levels-sortable .level-row').each(function (index) {
        $(this)
          .find('.level-number')
          .text(index + 1);
      });
    },

    /**
     * Collect levels data
     *
     * @since 3.0.0
     *
     * @return {Array} Array of level objects
     */
    collectLevels: function () {
      var levels = [];

      $('#levels-sortable .level-row').each(function () {
        var $row = $(this);
        var type = $row.data('level-type');

        var level = {
          level_order: $row.find('.level-number').text(),
          is_break: type === 'break' ? 1 : 0,
          duration_minutes: 15, // Default duration
        };

        if (type === 'break') {
          level.break_duration_minutes = parseInt($row.find('.break-length').val(), 10) || 15;
          level.small_blind = 0;
          level.big_blind = 0;
          level.ante = 0;
        } else {
          level.small_blind = parseInt($row.find('.small-blind').val(), 10) || 0;
          level.big_blind = parseInt($row.find('.big-blind').val(), 10) || 0;
          level.ante = parseInt($row.find('.ante').val(), 10) || 0;
          level.break_duration_minutes = 0;
        }

        levels.push(level);
      });

      return levels;
    },

    /**
     * Save levels via AJAX
     *
     * @since 3.0.0
     */
    saveLevels: function () {
      var scheduleId = $('.tdwp-level-builder').data('schedule-id');
      var levels = this.collectLevels();

      if (levels.length === 0) {
        alert('Please add at least one blind level.');
        return;
      }

      // Validate levels
      var validation = this.validateLevels(levels);
      if (!validation.valid) {
        alert(validation.message);
        return;
      }

      var $button = $('#save-levels');
      $button.addClass('is-busy').prop('disabled', true);

      $.ajax({
        url: tdwpBlindBuilder.ajaxUrl,
        type: 'POST',
        data: {
          action: 'tdwp_save_blind_levels',
          nonce: tdwpBlindBuilder.nonce,
          schedule_id: scheduleId,
          levels: JSON.stringify(levels),
        },
        success: function (response) {
          if (response.success) {
            alert(tdwpBlindBuilder.i18n.levelsSaved);
          } else {
            alert(response.data.message || tdwpBlindBuilder.i18n.errorSaving);
          }
        },
        error: function () {
          alert(tdwpBlindBuilder.i18n.errorSaving);
        },
        complete: function () {
          $button.removeClass('is-busy').prop('disabled', false);
        },
      });
    },

    /**
     * Validate levels data
     *
     * @since 3.0.0
     *
     * @param {Array} levels Levels array
     * @return {Object} Validation result
     */
    validateLevels: function (levels) {
      for (var i = 0; i < levels.length; i++) {
        var level = levels[i];

        if (level.is_break === 0) {
          // Validate blind levels
          if (level.big_blind <= 0) {
            return {
              valid: false,
              message: 'Level ' + (i + 1) + ': Big blind must be greater than zero.',
            };
          }

          if (level.small_blind <= 0) {
            return {
              valid: false,
              message: 'Level ' + (i + 1) + ': Small blind must be greater than zero.',
            };
          }

          if (level.small_blind >= level.big_blind) {
            return {
              valid: false,
              message: 'Level ' + (i + 1) + ': Small blind must be less than big blind.',
            };
          }

          if (level.ante < 0) {
            return {
              valid: false,
              message: 'Level ' + (i + 1) + ': Ante cannot be negative.',
            };
          }
        } else {
          // Validate break levels
          if (level.break_duration_minutes <= 0) {
            return {
              valid: false,
              message: 'Level ' + (i + 1) + ': Break duration must be greater than zero.',
            };
          }

          if (level.break_duration_minutes > 60) {
            return {
              valid: false,
              message: 'Level ' + (i + 1) + ': Break duration cannot exceed 60 minutes.',
            };
          }
        }
      }

      return { valid: true };
    },

    /**
     * Update schedule preview.
     *
     * Renders each level row plus a summary line showing total tournament
     * duration and the average starting stack (assuming no eliminations).
     *
     * Total duration = sum of all level durations including breaks.
     * Play-level duration defaults to the schedule's "Level Duration" field
     * (#level-duration) so it stays consistent with the schedule header.
     *
     * Average stack assumption: all chips remain in play (no eliminations),
     * so avg stack = starting chips per the "Starting Chips" suggest field.
     * This is labeled clearly so users understand the assumption.
     *
     * @since 3.0.0 (extended 3.6.2)
     */
    updatePreview: function () {
      var $preview = $('#schedule-preview');
      var levels = this.collectLevels();

      if (levels.length === 0) {
        $preview.html(
          '<div class="preview-empty">No levels to preview. Add blind levels to see the structure.</div>'
        );
        return;
      }

      // Read schedule-level defaults for the summary calculations.
      var defaultLevelMins = parseInt($('#level-duration').val(), 10) || 15;
      var startingChips = parseInt($('#suggest-starting-chips').val(), 10) || 0;

      // Compute total duration and play/break counts.
      var totalMins = 0;
      var playCount = 0;
      var breakCount = 0;

      for (var j = 0; j < levels.length; j++) {
        if (levels[j].is_break === 1) {
          totalMins += levels[j].break_duration_minutes || 0;
          breakCount++;
        } else {
          totalMins += defaultLevelMins;
          playCount++;
        }
      }

      var html = '';

      // Summary bar.
      var hours = Math.floor(totalMins / 60);
      var mins = totalMins % 60;
      var timeStr = hours > 0 ? hours + 'h ' + mins + 'm' : mins + ' min';

      html += '<div class="preview-summary">';
      html +=
        '<span class="preview-summary-item"><strong>Total duration:</strong> ' +
        timeStr +
        '</span>';
      html +=
        '<span class="preview-summary-item"><strong>Play levels:</strong> ' + playCount + '</span>';
      html +=
        '<span class="preview-summary-item"><strong>Breaks:</strong> ' + breakCount + '</span>';
      if (startingChips > 0) {
        html +=
          '<span class="preview-summary-item"><strong>Avg stack at start:</strong> ' +
          this.formatNumber(startingChips) +
          ' <em>(full field, no eliminations assumed)</em></span>';
      }
      html += '</div>';

      // Per-level rows.
      for (var i = 0; i < levels.length; i++) {
        var level = levels[i];

        if (level.is_break === 1) {
          html += '<div class="preview-level preview-break">';
          html += '<div class="preview-level-number">' + (i + 1) + '</div>';
          html +=
            '<div class="preview-level-blinds">BREAK - ' +
            level.break_duration_minutes +
            ' minutes</div>';
          html += '<div class="preview-level-ante">&nbsp;</div>';
          html += '</div>';
        } else {
          var anteText = level.ante > 0 ? 'Ante: ' + this.formatNumber(level.ante) : 'No ante';

          html += '<div class="preview-level">';
          html += '<div class="preview-level-number">' + (i + 1) + '</div>';
          html += '<div class="preview-level-blinds">';
          html += '<strong>' + this.formatNumber(level.small_blind) + '</strong> / ';
          html += '<strong>' + this.formatNumber(level.big_blind) + '</strong>';
          html += '</div>';
          html += '<div class="preview-level-ante">' + anteText + '</div>';
          html += '</div>';
        }
      }

      $preview.html(html);
    },

    /**
     * Format number with thousand separators
     *
     * @since 3.0.0
     *
     * @param {number} num Number to format
     * @return {string} Formatted number
     */
    formatNumber: function (num) {
      return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    },

    /**
     * Request a suggested schedule from the server and load it into the builder.
     *
     * Reads the four suggestion inputs, calls the AJAX endpoint, confirms with
     * the user before replacing any existing levels, then delegates to
     * loadSuggestedLevels().
     *
     * @since 3.6.1
     */
    suggestSchedule: function () {
      var startingChips = parseInt($('#suggest-starting-chips').val(), 10) || 10000;
      var playerCount = parseInt($('#suggest-player-count').val(), 10) || 9;
      var duration = parseInt($('#suggest-duration').val(), 10) || 180;
      var style = $('#suggest-style').val() || 'standard';

      if ($('#levels-sortable .level-row').length > 0) {
        if (!confirm(tdwpBlindBuilder.i18n.confirmLoadSuggest)) {
          return;
        }
      }

      var $btn = $('#generate-schedule');
      $btn.addClass('is-busy').prop('disabled', true);
      $('#suggest-summary').hide();

      var self = this;

      $.ajax({
        url: tdwpBlindBuilder.ajaxUrl,
        type: 'POST',
        data: {
          action: 'tdwp_suggest_blind_schedule',
          nonce: tdwpBlindBuilder.nonce,
          starting_chips: startingChips,
          player_count: playerCount,
          desired_duration: duration,
          style: style,
        },
        success: function (response) {
          if (response.success) {
            self.loadSuggestedLevels(response.data);
          } else {
            alert(
              (response.data && response.data.message) || tdwpBlindBuilder.i18n.errorSuggesting
            );
          }
        },
        error: function () {
          alert(tdwpBlindBuilder.i18n.errorSuggesting);
        },
        complete: function () {
          $btn.removeClass('is-busy').prop('disabled', false);
        },
      });
    },

    /**
     * Populate the level builder with a suggestion result.
     *
     * Clears the existing rows and creates one <tr> per level using the same
     * DOM structure as the existing Add Blind Level / Add Break templates so
     * the user can edit and save normally.
     *
     * @since 3.6.1
     *
     * @param {Object} data Server response: { levels, estimated_total_minutes,
     *                       level_count, break_count }
     */
    loadSuggestedLevels: function (data) {
      var levels = data.levels || [];
      var $tbody = $('#levels-sortable');

      $tbody.empty();

      if (levels.length === 0) {
        $tbody.html('<tr class="no-levels"><td colspan="7">No levels to load.</td></tr>');
        return;
      }

      var blindLevelTpl = $('#blind-level-template').html();
      var breakLevelTpl = $('#break-level-template').html();

      for (var i = 0; i < levels.length; i++) {
        var level = levels[i];

        if (level.is_break) {
          var $row = $(breakLevelTpl);
          $row.find('.break-length').val(level.break_duration_minutes || 15);
          $tbody.append($row);
        } else {
          var $brow = $(blindLevelTpl);
          $brow.find('.small-blind').val(level.small_blind || 0);
          $brow.find('.big-blind').val(level.big_blind || 0);
          $brow.find('.ante').val(level.ante || 0);
          $tbody.append($brow);
        }
      }

      this.renumberLevels();
      this.updatePreview();

      // Show the summary line.
      var totalMins = parseInt(data.estimated_total_minutes, 10) || 0;
      var hours = Math.floor(totalMins / 60);
      var mins = totalMins % 60;
      var timeStr = hours > 0 ? hours + 'h ' + mins + 'm' : mins + ' min';
      $('#suggest-summary')
        .text(
          data.level_count +
            ' play levels, ' +
            data.break_count +
            ' break(s) — estimated ' +
            timeStr
        )
        .show();
    },

    /**
     * Apply the current schedule to a specific tournament via AJAX.
     *
     * Reads the tournament ID from #apply-tournament-id, confirms with the
     * user, then POSTs to the tdwp_apply_blind_template_to_tournament action.
     * The server clones the schedule levels into the tournament's own copy.
     *
     * @since 3.6.2
     */
    applyTemplateToTournament: function () {
      var tournamentId = parseInt($('#apply-tournament-id').val(), 10) || 0;

      if (tournamentId <= 0) {
        alert('Please enter a valid tournament ID.');
        return;
      }

      if (!confirm(tdwpBlindBuilder.i18n.applyTemplateConfirm)) {
        return;
      }

      var scheduleId = parseInt($('#apply-template-to-tournament').data('schedule-id'), 10) || 0;

      if (scheduleId <= 0) {
        alert(tdwpBlindBuilder.i18n.applyTemplateError);
        return;
      }

      var $btn = $('#apply-template-to-tournament');
      var $result = $('#apply-template-result');
      $btn.addClass('is-busy').prop('disabled', true);
      $result.hide();

      $.ajax({
        url: tdwpBlindBuilder.ajaxUrl,
        type: 'POST',
        data: {
          action: 'tdwp_apply_blind_template_to_tournament',
          nonce: tdwpBlindBuilder.nonce,
          source_schedule_id: scheduleId,
          tournament_id: tournamentId,
        },
        success: function (response) {
          if (response.success) {
            $result
              .text(tdwpBlindBuilder.i18n.applyTemplateSuccess)
              .removeClass('notice-error')
              .addClass('notice-success')
              .show();
          } else {
            $result
              .text(
                (response.data && response.data.message) || tdwpBlindBuilder.i18n.applyTemplateError
              )
              .removeClass('notice-success')
              .addClass('notice-error')
              .show();
          }
        },
        error: function () {
          $result
            .text(tdwpBlindBuilder.i18n.applyTemplateError)
            .removeClass('notice-success')
            .addClass('notice-error')
            .show();
        },
        complete: function () {
          $btn.removeClass('is-busy').prop('disabled', false);
        },
      });
    },
  };

  /**
   * Initialize when DOM is ready
   */
  $(document).ready(function () {
    if ($('.tdwp-level-builder').length > 0) {
      TDWPBlindBuilder.init();
    }
  });
})(jQuery);
