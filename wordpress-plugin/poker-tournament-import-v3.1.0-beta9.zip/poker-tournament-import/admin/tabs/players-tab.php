<?php
/**
 * Players Tab Content (Stub for Week 3)
 *
 * @package Poker_Tournament_Import
 * @since 3.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="players-tab-content stub-content">
	<div class="stub-message">
		<h2><?php esc_html_e( 'Player Operations', 'poker-tournament-import' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Coming in Phase 2 Week 3', 'poker-tournament-import' ); ?></p>

		<div class="feature-preview">
			<h3><?php esc_html_e( 'Planned Features:', 'poker-tournament-import' ); ?></h3>
			<ul class="feature-list">
				<li><?php esc_html_e( 'Bust-out Processing with automatic rankings', 'poker-tournament-import' ); ?></li>
				<li><?php esc_html_e( 'Rebuy & Add-on Processing', 'poker-tournament-import' ); ?></li>
				<li><?php esc_html_e( 'Late Registration Management', 'poker-tournament-import' ); ?></li>
				<li><?php esc_html_e( 'Chip Count Adjustments', 'poker-tournament-import' ); ?></li>
				<li><?php esc_html_e( 'Transaction Log & Audit Trail', 'poker-tournament-import' ); ?></li>
			</ul>
		</div>
	</div>
</div>
