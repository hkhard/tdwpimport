/**
 * Tournament Control JS
 * Tab switching, minimized indicator
 */

(function($) {
    'use strict';

    const TournamentControl = {
        currentTab: 'timer',

        init: function() {
            this.bindEvents();
            this.bindPlayerEvents();
            this.initMinimizedClock();
        },

        bindEvents: function() {
            // Tab switching
            $('.tdwp-tab-button').on('click', this.switchTab.bind(this));

            // Modal close buttons
            $('.modal-close').on('click', function() {
                $(this).closest('.tdwp-modal').hide();
            });

            // Click outside modal to close
            $('.tdwp-modal').on('click', function(e) {
                if ($(e.target).hasClass('tdwp-modal')) {
                    $(this).hide();
                }
            });
        },

        switchTab: function(e) {
            const $button = $(e.currentTarget);
            const tab = $button.data('tab');

            if (tab === this.currentTab) {
                return;
            }

            // Update buttons
            $('.tdwp-tab-button').removeClass('active');
            $button.addClass('active');

            // Update panels
            $('.tdwp-tab-panel').removeClass('active');
            $('#tab-' + tab).addClass('active');

            // Update minimized clock visibility
            if (tab === 'timer') {
                $('#tdwp-minimized-clock').hide();
            } else {
                $('#tdwp-minimized-clock').show();
            }

            this.currentTab = tab;

            // Trigger event for other scripts
            $(document).trigger('tdwp:tabChanged', [tab]);
        },

        initMinimizedClock: function() {
            // Initially hidden (timer tab is active by default)
            $('#tdwp-minimized-clock').hide();
        },

        updateMinimizedClock: function(level, time, blinds) {
            $('#mini-level').text(level);
            $('#mini-time').text(time);
            $('#mini-blinds').text(blinds);
        },

        showNotice: function(message, type) {
            type = type || 'success';

            const $notice = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');

            $('.tdwp-tournament-control h1').after($notice);

            // Auto-dismiss after 3 seconds
            setTimeout(function() {
                $notice.fadeOut(function() {
                    $(this).remove();
                });
            }, 3000);
        },

        showModal: function(modalId) {
            $('#' + modalId).show();
        },

        hideModal: function(modalId) {
            $('#' + modalId).hide();
        },

        // Player Management Methods
        bindPlayerEvents: function() {
            // Add player button
            $('#btn-add-player').on('click', this.openAddPlayerModal.bind(this));

            // Modal close buttons
            $('#add-player-modal .tdwp-modal-close, #btn-cancel-add').on('click', this.closeAddPlayerModal.bind(this));

            // Confirm add player
            $('#btn-confirm-add').on('click', this.addPlayer.bind(this));

            // Remove player buttons
            $(document).on('click', '.btn-remove-player', this.handleRemovePlayer.bind(this));

            // Player status change
            $(document).on('change', '.player-status-select', this.handleStatusChange.bind(this));
        },

        openAddPlayerModal: function() {
            // Reset form
            $('#player-select').val('');
            $('#player-status').val('registered');
            $('#paid-amount').val('0');
            this.showModal('add-player-modal');
        },

        closeAddPlayerModal: function() {
            this.hideModal('add-player-modal');
        },

        addPlayer: function() {
            const playerId = $('#player-select').val();
            const status = $('#player-status').val();
            const paidAmount = $('#paid-amount').val();
            const tournamentId = $('#tournament-id').val();

            if (!playerId) {
                this.showNotice('Please select a player', 'error');
                return;
            }

            const $button = $('#btn-confirm-add');
            const originalText = $button.text();
            $button.prop('disabled', true).text('Adding...');

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'tdwp_tm_add_player',
                    nonce: tdwpTournamentManager.nonce,
                    tournament_id: tournamentId,
                    player_id: playerId,
                    status: status,
                    paid_amount: paidAmount
                },
                success: (response) => {
                    if (response.success) {
                        this.showNotice(response.data.message, 'success');
                        this.closeAddPlayerModal();
                        // Reload page to show updated roster
                        location.reload();
                    } else {
                        this.showNotice(response.data.message || 'Failed to add player', 'error');
                    }
                },
                error: () => {
                    this.showNotice('An error occurred while adding the player', 'error');
                },
                complete: () => {
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },

        handleRemovePlayer: function(e) {
            const $button = $(e.currentTarget);
            const playerId = $button.data('player-id');
            const playerName = $button.closest('tr').find('td:first strong').text();

            if (!confirm('Remove ' + playerName + ' from this tournament?')) {
                return;
            }

            this.removePlayer(playerId, $button);
        },

        removePlayer: function(playerId, $button) {
            const tournamentId = $('#tournament-id').val();
            const originalText = $button.text();

            $button.prop('disabled', true).text('Removing...');

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'tdwp_tm_remove_player',
                    nonce: tdwpTournamentManager.nonce,
                    tournament_id: tournamentId,
                    player_id: playerId
                },
                success: (response) => {
                    if (response.success) {
                        this.showNotice(response.data.message, 'success');
                        // Reload page to show updated roster
                        location.reload();
                    } else {
                        this.showNotice(response.data.message || 'Failed to remove player', 'error');
                        $button.prop('disabled', false).text(originalText);
                    }
                },
                error: () => {
                    this.showNotice('An error occurred while removing the player', 'error');
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },

        handleStatusChange: function(e) {
            const $select = $(e.currentTarget);
            const playerId = $select.data('player-id');
            const newStatus = $select.val();
            const oldStatus = $select.data('old-status') || $select.val();

            // Store old status in case we need to revert
            $select.data('old-status', oldStatus);

            this.updatePlayerStatus(playerId, newStatus, $select);
        },

        updatePlayerStatus: function(playerId, status, $select) {
            const tournamentId = $('#tournament-id').val();

            $select.prop('disabled', true);

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'tdwp_tm_update_player_status',
                    nonce: tdwpTournamentManager.nonce,
                    tournament_id: tournamentId,
                    player_id: playerId,
                    status: status
                },
                success: (response) => {
                    if (response.success) {
                        this.showNotice(response.data.message, 'success');
                        // Update stored old status
                        $select.data('old-status', status);
                    } else {
                        this.showNotice(response.data.message || 'Failed to update status', 'error');
                        // Revert to old status
                        $select.val($select.data('old-status'));
                    }
                },
                error: () => {
                    this.showNotice('An error occurred while updating status', 'error');
                    // Revert to old status
                    $select.val($select.data('old-status'));
                },
                complete: () => {
                    $select.prop('disabled', false);
                }
            });
        }
    };

    // Initialize on document ready
    $(document).ready(function() {
        TournamentControl.init();
    });

    // Export to global scope for other scripts
    window.TournamentControl = TournamentControl;

})(jQuery);
