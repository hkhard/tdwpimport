<?php
/**
 * Players Tab Content - Tournament Roster
 *
 * @package Poker_Tournament_Import
 * @since 3.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get registered players.
$players = TDWP_Tournament_Player_Manager::get_tournament_players( $tournament_id );
$player_count = count( $players );

// Get all available players for autocomplete.
$all_players = get_posts(
	array(
		'post_type'      => 'player',
		'post_status'    => 'publish',
		'posts_per_page' => -1,
		'orderby'        => 'title',
		'order'          => 'ASC',
	)
);
?>

<div class="players-tab-content">
	<div class="players-header">
		<h2><?php esc_html_e( 'Tournament Roster', 'poker-tournament-import' ); ?></h2>
		<div class="players-actions">
			<button type="button" id="btn-add-player" class="button button-primary">
				<?php esc_html_e( 'Add Player', 'poker-tournament-import' ); ?>
			</button>
			<span class="player-count"><?php echo esc_html( sprintf( __( 'Total Players: %d', 'poker-tournament-import' ), $player_count ) ); ?></span>
		</div>
	</div>

	<!-- Add Player Modal -->
	<div id="add-player-modal" class="tdwp-modal" style="display:none;">
		<div class="tdwp-modal-content">
			<div class="tdwp-modal-header">
				<h3><?php esc_html_e( 'Add Player to Tournament', 'poker-tournament-import' ); ?></h3>
				<span class="tdwp-modal-close">&times;</span>
			</div>
			<div class="tdwp-modal-body">
				<div class="form-row">
					<label for="player-select"><?php esc_html_e( 'Select Player', 'poker-tournament-import' ); ?></label>
					<select id="player-select" class="regular-text">
						<option value=""><?php esc_html_e( 'Choose a player...', 'poker-tournament-import' ); ?></option>
						<?php foreach ( $all_players as $player ) : ?>
							<option value="<?php echo esc_attr( $player->ID ); ?>">
								<?php echo esc_html( $player->post_title ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="form-row">
					<label for="player-status"><?php esc_html_e( 'Status', 'poker-tournament-import' ); ?></label>
					<select id="player-status">
						<option value="registered"><?php esc_html_e( 'Registered', 'poker-tournament-import' ); ?></option>
						<option value="paid"><?php esc_html_e( 'Paid', 'poker-tournament-import' ); ?></option>
						<option value="checked_in"><?php esc_html_e( 'Checked In', 'poker-tournament-import' ); ?></option>
					</select>
				</div>
				<div class="form-row">
					<label for="paid-amount"><?php esc_html_e( 'Paid Amount', 'poker-tournament-import' ); ?></label>
					<input type="number" id="paid-amount" step="0.01" min="0" value="0">
				</div>
			</div>
			<div class="tdwp-modal-footer">
				<button type="button" id="btn-cancel-add" class="button"><?php esc_html_e( 'Cancel', 'poker-tournament-import' ); ?></button>
				<button type="button" id="btn-confirm-add" class="button button-primary"><?php esc_html_e( 'Add Player', 'poker-tournament-import' ); ?></button>
			</div>
		</div>
	</div>

	<!-- Players Table -->
	<?php if ( $player_count > 0 ) : ?>
		<table class="wp-list-table widefat fixed striped players-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Player', 'poker-tournament-import' ); ?></th>
					<th><?php esc_html_e( 'Status', 'poker-tournament-import' ); ?></th>
					<th><?php esc_html_e( 'Registered', 'poker-tournament-import' ); ?></th>
					<th><?php esc_html_e( 'Paid', 'poker-tournament-import' ); ?></th>
					<th><?php esc_html_e( 'Rebuys', 'poker-tournament-import' ); ?></th>
					<th><?php esc_html_e( 'Add-ons', 'poker-tournament-import' ); ?></th>
					<th><?php esc_html_e( 'Seat', 'poker-tournament-import' ); ?></th>
					<th><?php esc_html_e( 'Actions', 'poker-tournament-import' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $players as $player_reg ) : ?>
					<?php
					$player_post = get_post( $player_reg->player_id );
					if ( ! $player_post ) {
						continue;
					}
					?>
					<tr data-player-id="<?php echo esc_attr( $player_reg->player_id ); ?>">
						<td><strong><?php echo esc_html( $player_post->post_title ); ?></strong></td>
						<td>
							<select class="player-status-select" data-player-id="<?php echo esc_attr( $player_reg->player_id ); ?>">
								<option value="registered" <?php selected( $player_reg->status, 'registered' ); ?>><?php esc_html_e( 'Registered', 'poker-tournament-import' ); ?></option>
								<option value="paid" <?php selected( $player_reg->status, 'paid' ); ?>><?php esc_html_e( 'Paid', 'poker-tournament-import' ); ?></option>
								<option value="checked_in" <?php selected( $player_reg->status, 'checked_in' ); ?>><?php esc_html_e( 'Checked In', 'poker-tournament-import' ); ?></option>
								<option value="active" <?php selected( $player_reg->status, 'active' ); ?>><?php esc_html_e( 'Active', 'poker-tournament-import' ); ?></option>
								<option value="eliminated" <?php selected( $player_reg->status, 'eliminated' ); ?>><?php esc_html_e( 'Eliminated', 'poker-tournament-import' ); ?></option>
							</select>
						</td>
						<td><?php echo esc_html( gmdate( 'Y-m-d H:i', strtotime( $player_reg->registration_date ) ) ); ?></td>
						<td>$<?php echo esc_html( number_format( (float) $player_reg->paid_amount, 2 ) ); ?></td>
						<td><?php echo esc_html( $player_reg->rebuys_count ); ?></td>
						<td><?php echo esc_html( $player_reg->addons_count ); ?></td>
						<td><?php echo $player_reg->seat_assignment ? esc_html( $player_reg->seat_assignment ) : '—'; ?></td>
						<td>
							<button type="button" class="button button-small btn-remove-player" data-player-id="<?php echo esc_attr( $player_reg->player_id ); ?>">
								<?php esc_html_e( 'Remove', 'poker-tournament-import' ); ?>
							</button>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php else : ?>
		<div class="no-players-message">
			<p><?php esc_html_e( 'No players registered yet. Click "Add Player" to start.', 'poker-tournament-import' ); ?></p>
		</div>
	<?php endif; ?>
</div>
