<?php
/**
 * Dependency Manager for Tournament Manager
 *
 * Handles downloading and managing external dependencies like TCPDF
 *
 * @package Poker_Tournament_Import
 * @subpackage Tournament_Manager
 * @since 3.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class TDWP_Dependency_Manager {

	/**
	 * tc-lib GitHub repository API endpoint
	 */
	const GITHUB_API_URL = 'https://api.github.com/repos/tecnickcom/tc-lib-pdf/git/refs/tags';

	/**
	 * tc-lib GitHub repository URL for fallback
	 */
	const GITHUB_REPO_URL = 'https://github.com/tecnickcom/tc-lib-pdf';

	/**
	 * tc-lib-pdf download URL (GitHub tag archive)
	 */
	const TCPDF_DOWNLOAD_URL = 'https://github.com/tecnickcom/tc-lib-pdf/archive/refs/tags/%s.zip';

	/**
	 * Default fallback version if dynamic detection fails
	 */
	const FALLBACK_VERSION = '8.1.5';

	/**
	 * Cache expiration time for version information (12 hours)
	 */
	const VERSION_CACHE_EXPIRATION = 12 * HOUR_IN_SECONDS;

	/**
	 * Directory name for stored dependencies
	 */
/**
	 * Library installation directory path
	 *
	 * @since 3.3.0
	 * @var string
	 */
	private $library_install_dir;

	/**
	 * TCPDF library installation path
	 *
	 * @since 3.3.0
	 * @var string
	 */
	private $tcpdf_path;
	const DEPENDENCIES_DIR = 'tdwp-libs';

	/**
	 * TCPDF 6.x GitHub repository API endpoint (preferred)
	 */
	const GITHUB_API_URL_TCPDF6 = 'https://api.github.com/repos/tecnickcom/TCPDF/git/refs/tags';

	/**
	 * TCPDF 6.x GitHub repository URL (preferred)
	 */
	const GITHUB_REPO_URL_TCPDF6 = 'https://github.com/tecnickcom/TCPDF';

	/**
	 * TCPDF 6.x download URL (preferred)
	 */
	const TCPDF6_DOWNLOAD_URL = 'https://github.com/tecnickcom/TCPDF/archive/refs/tags/%s.zip';

	/**
	 * Version preference configuration (6 preferred, 8 fallback)
	 */
	const PREFERRED_MAJOR_VERSION = 6;

	/**
	 * Default TCPDF 6.x version if dynamic detection fails
	 */
	const TCPDF6_FALLBACK_VERSION = '6.10.0';

	/**
	 * Instance of this class
	 *
	 * @var TDWP_Dependency_Manager
	 */
	private static $instance = null;

	/**
	 * Get singleton instance
	 *
	 * @since 3.3.0
	 * @return TDWP_Dependency_Manager
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Current installed version
	 */
	private $current_version;

	/**
     * Constructor
     *
     * @since 3.3.0
     */
    private function __construct() {
        $this->init_library_paths();
        $this->library_install_dir = dirname( __DIR__ ) . '/vendor/';
        $this->tcpdf_path = $this->library_install_dir . 'tcpdf/';

        // Ensure dependencies directory exists
        if ( ! file_exists( $this->library_install_dir ) ) {
            wp_mkdir_p( $this->library_install_dir );
        }

        // Set current version from installed library or default
        $this->current_version = $this->get_installed_version();

        // Schedule version check if not already scheduled
        if ( ! wp_next_scheduled( 'tdwp_check_library_updates' ) ) {
            wp_schedule_event( time(), 'daily', 'tdwp_check_library_updates' );
        }

        add_action( 'admin_init', array( $this, 'handle_dependency_requests' ) );
        add_action( 'admin_init', array( $this, 'handle_tcpdf_download_fallback' ) );
        add_action( 'admin_notices', array( $this, 'show_dependency_notices' ) );
    }

/**
	 * Initialize library paths and directory structure
	 *
	 * @since 3.3.0
	 * @return void
	 */
	private function init_library_paths() {
		// Set up base library directory
		$this->library_install_dir = dirname( __DIR__ ) . '/vendor/';
		$this->tcpdf_path = $this->library_install_dir . 'tcpdf/';

		// Ensure base directories exist
		if ( ! file_exists( $this->library_install_dir ) ) {
			wp_mkdir_p( $this->library_install_dir );
		}

		// Ensure TCPDF directory exists
		if ( ! file_exists( $this->tcpdf_path ) ) {
			wp_mkdir_p( $this->tcpdf_path );
		}

		// Set proper permissions (755 for directories)
		if ( function_exists( 'chmod' ) ) {
			@chmod( $this->library_install_dir, 0755 );
			@chmod( $this->tcpdf_path, 0755 );
		}
	}

	/**
	 * Remove directory and all its contents recursively
	 *
	 * @since 3.3.0
	 * @param string $dir Directory path to remove
	 * @return bool Success status
	 */
	private function remove_directory( $dir ) {
		if ( ! file_exists( $dir ) ) {
			return true;
		}

		if ( ! is_dir( $dir ) ) {
			return unlink( $dir );
		}

		// Use WordPress Filesystem API for safety
		WP_Filesystem();
		global $wp_filesystem;

		if ( ! $wp_filesystem ) {
			// Fallback to manual removal
			$files = array_diff( scandir( $dir ), array( '.', '..' ) );
			foreach ( $files as $file ) {
				$path = $dir . '/' . $file;
				is_dir( $path ) ? $this->remove_directory( $path ) : unlink( $path );
			}
			return rmdir( $dir );
		}

		return $wp_filesystem->rmdir( $dir, true );
	}

	/**
	 * Get TCPDF installation directory path
	 *
	 * @since 3.3.0
	 * @return string TCPDF directory path
	 */
	private function get_tcpdf_directory() {
		return $this->tcpdf_path;
	}

	/**
	 * Handle dependency management requests from admin interface
	 *
	 * @since 3.3.0
	 * @return void
	 */
	public function handle_dependency_requests() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Insufficient permissions' );
		}

		// Handle form submissions
		if ( isset( $_POST['action'] ) && $_POST['action'] === 'tdwp_update_library' ) {
			check_admin_referer( 'tdwp_update_library' );
			
			$result = $this->download_tcpdf();
			
			if ( $result['success'] ) {
				add_action( 'admin_notices', function() use ( $result ) {
					printf(
						'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
						esc_html( $result['message'] )
					);
				});
			} else {
				add_action( 'admin_notices', function() use ( $result ) {
					printf(
						'<div class="notice notice-error is-dismissible"><p>%s</p></div>',
						esc_html( $result['message'] )
					);
				});
			}
		}

		// Handle version rollback
		if ( isset( $_POST['action'] ) && $_POST['action'] === 'tdwp_rollback_version' ) {
			check_admin_referer( 'tdwp_rollback_version' );
			
			$version = sanitize_text_field( $_POST['version'] ?? '' );
			$result = $this->download_specific_version( $version );
			
			if ( $result['success'] ) {
				add_action( 'admin_notices', function() use ( $result ) {
					printf(
						'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
						esc_html( $result['message'] )
					);
				});
			} else {
				add_action( 'admin_notices', function() use ( $result ) {
					printf(
						'<div class="notice notice-error is-dismissible"><p>%s</p></div>',
						esc_html( $result['message'] )
					);
				});
			}
		}

		// Handle manual upload
		if ( isset( $_POST['action'] ) && $_POST['action'] === 'tdwp_upload_library' ) {
			check_admin_referer( 'tdwp_upload_library' );
			
			if ( isset( $_FILES['library_file'] ) && $_FILES['library_file']['error'] === UPLOAD_ERR_OK ) {
				$file = $_FILES['library_file'];
				
				// Validate file type
				if ( ! $file['name'] || ! strtolower( substr( $file['name'], -4 ) ) === '.zip' ) {
					add_action( 'admin_notices', function() {
						echo '<div class="notice notice-error is-dismissible"><p>Please upload a valid ZIP file.</p></div>';
					});
					return;
				}

				$result = $this->process_uploaded_library( $file );
				
				if ( $result['success'] ) {
					add_action( 'admin_notices', function() use ( $result ) {
						printf(
							'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
							esc_html( $result['message'] )
						);
					});
				} else {
					add_action( 'admin_notices', function() use ( $result ) {
						printf(
							'<div class="notice notice-error is-dismissible"><p>%s</p></div>',
							esc_html( $result['message'] )
						);
					});
				}
			}
		}
	}

	/**
     * Show dependency status notices in admin
     *
     * @since 3.3.0
     * @return void
     */
    public function show_dependency_notices() {
        // Show TCPDF download notices first (on all admin pages)
        $this->show_tcpdf_download_notices();

        $screen = get_current_screen();
        
        // Only show dependency manager notices on dependency manager page
        if ( ! $screen || $screen->id !== 'poker-tournament-import_page_tdwp-dependency-manager' ) {
            return;
        }

        // Check TCPDF availability
        $updates = $this->check_updates();

        switch ( $updates['status'] ) {
            case 'not_installed':
                echo '<div class="notice notice-error is-dismissible">';
                echo '<p><strong>PDF Library Not Installed:</strong> PDF export functionality is not available. Please install the tc-lib-pdf library to enable PDF exports.</p>';
                echo '</div>';
                break;
                
            case 'update_available':
                echo '<div class="notice notice-warning is-dismissible">';
                echo '<p><strong>Update Available:</strong> A newer version of the PDF library is available. Current: ' . esc_html( $updates['current'] ) . ', Latest: ' . esc_html( $updates['latest'] ) . '.</p>';
                echo '</div>';
                break;
                
            case 'current':
                echo '<div class="notice notice-success is-dismissible">';
                echo '<p><strong>PDF Library:</strong> Your PDF library is up to date (version ' . esc_html( $updates['current'] ) . ').</p>';
                echo '</div>';
                break;
                
            case 'error':
                echo '<div class="notice notice-error is-dismissible">';
                echo '<p><strong>Version Check Failed:</strong> Unable to check for PDF library updates. Please check your internet connection.</p>';
                echo '</div>';
                break;
        }
    }

    /**
     * Show TCPDF download notices
     *
     * @since 3.3.0
     * @return void
     */
    private function show_tcpdf_download_notices() {
        $notices = get_transient( 'tdwp_admin_notices', array() );
        
        if ( empty( $notices ) ) {
            return;
        }

        // Remove notices older than 24 hours
        $current_time = time();
        $valid_notices = array();
        
        foreach ( $notices as $notice ) {
            if ( $current_time - $notice['timestamp'] < DAY_IN_SECONDS ) {
                $valid_notices[] = $notice;
            }
        }

        // Display valid notices
        foreach ( $valid_notices as $notice ) {
            $class = 'notice-info';
            
            switch ( $notice['type'] ) {
                case 'success':
                    $class = 'notice-success';
                    break;
                case 'error':
                    $class = 'notice-error';
                    break;
                case 'warning':
                    $class = 'notice-warning';
                    break;
            }
            
            echo '<div class="notice ' . esc_attr( $class ) . ' is-dismissible">';
            echo '<p>' . wp_kses_post( $notice['message'] ) . '</p>';
            echo '</div>';
        }

        // Update transient with only valid notices
        if ( count( $valid_notices ) !== count( $notices ) ) {
            set_transient( 'tdwp_admin_notices', $valid_notices, DAY_IN_SECONDS );
        }
    }

	/**
	 * Process uploaded library ZIP file
	 *
	 * @since 3.3.0
	 * @param array $file Uploaded file data from $_FILES
	 * @return array Operation result
	 */
	private function process_uploaded_library( $file ) {
		$temp_file = $file['tmp_name'];
		
		// Validate ZIP file
		if ( filesize( $temp_file ) < 1000000 ) { // Less than 1MB seems wrong
			return array(
				'success' => false,
				'message' => 'Uploaded file appears corrupted or too small.'
			);
		}

		// Extract to temporary directory first
		$temp_extract_dir = $this->library_install_dir . 'upload_temp/';
		if ( file_exists( $temp_extract_dir ) ) {
			$this->remove_directory( $temp_extract_dir );
		}

		WP_Filesystem();
		global $wp_filesystem;
		
		$unzip_result = unzip_file( $temp_file, $this->library_install_dir );
		
		if ( is_wp_error( $unzip_result ) ) {
			return array(
				'success' => false,
				'message' => 'Failed to extract ZIP file: ' . $unzip_result->get_error_message()
			);
		}

		// Clean up temp file
		unlink( $temp_file );

		// Try to detect and rename the extracted directory
		$extracted_dirs = glob( $this->library_install_dir . 'tc-lib-pdf-*', GLOB_ONLYDIR );
		$tcpdf_dirs = glob( $this->library_install_dir . 'tcpdf*', GLOB_ONLYDIR );
		
		if ( ! empty( $extracted_dirs ) ) {
			// Remove existing installation and rename new one
			if ( file_exists( $this->tcpdf_path ) ) {
				$this->remove_directory( $this->tcpdf_path );
			}
			
			$new_dir = $extracted_dirs[0];
			if ( ! rename( $new_dir, $this->tcpdf_path ) ) {
				return array(
					'success' => false,
					'message' => 'Failed to rename extracted directory. Check permissions.'
				);
			}
		} elseif ( ! empty( $tcpdf_dirs ) ) {
			// Already correctly named
			$this->tcpdf_path = $tcpdf_dirs[0];
		} else {
			return array(
				'success' => false,
				'message' => 'Could not find tc-lib-pdf directory in uploaded ZIP.'
			);
		}

		// Update current version
		$this->current_version = $this->get_installed_version();
		
		// Clear caches
		delete_transient( 'tdwp_latest_tcpdf_version' );
		delete_transient( 'tdwp_available_tcpdf_versions' );

		return array(
			'success' => true,
			'message' => 'Successfully installed PDF library from uploaded file',
			'version' => $this->current_version
		);
	}

  	  /**
     * Get the latest preferred PDF library version
     * 
     * Uses the preference algorithm: TCPDF 6.x preferred, tc-lib-pdf 8.x fallback
     *
     * @since 3.3.0
     * @return string|false Latest preferred version number or false on failure
     */
    public function get_latest_version() {
        // Use the new preference algorithm
        return $this->get_preferred_version();
    }

/**
	 * Get the latest TCPDF 6.x version from GitHub API
	 *
	 * @since 3.3.0
	 * @return string|false Latest TCPDF 6.x version number or false on failure
	 */
	public function get_tcpdf6_latest_version() {
		$cached_version = get_transient( 'tdwp_latest_tcpdf6_version' );
		
		if ( $cached_version !== false ) {
			return $cached_version;
		}

		$response = wp_remote_get( self::GITHUB_API_URL_TCPDF6, array(
			'timeout' => 10,
			'headers' => array(
				'Accept' => 'application/vnd.github.v3+json',
				'User-Agent' => 'Poker-Tournament-Import/' . POKER_TOURNAMENT_IMPORT_VERSION
			)
		));

		if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
			error_log( 'TDWP: Failed to fetch latest TCPDF 6.x version: ' . (is_wp_error( $response ) ? $response->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code( $response )) );
			return false;
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( ! isset( $data[0]['ref'] ) ) {
			error_log( 'TDWP: Unexpected GitHub API response structure for TCPDF 6.x' );
			return false;
		}

		// Extract version from refs/tags/X.Y.Z format
		$latest_tag = $data[0]['ref'];
		$version = str_replace( 'refs/tags/', '', $latest_tag );

		// Validate version format (should be X.Y.Z)
		if ( ! preg_match( '/^\d+\.\d+\.\d+$/', $version ) ) {
			error_log( "TDWP: Invalid TCPDF 6.x version format from GitHub: $version" );
			return false;
		}

		// Filter for 6.x versions only
		if ( strpos( $version, '6.' ) !== 0 ) {
			error_log( "TDWP: Non-6.x version found in TCPDF repository: $version" );
			return false;
		}

		// Cache for 24 hours
		set_transient( 'tdwp_latest_tcpdf6_version', $version, DAY_IN_SECONDS );
		
		return $version;
	}

	/**
	 * Get available TCPDF 6.x versions for rollback
	 *
	 * @since 3.3.0
	 * @return array List of available TCPDF 6.x versions
	 */
	public function get_tcpdf6_available_versions() {
		$cached_versions = get_transient( 'tdwp_tcpdf6_available_versions' );
		
		if ( $cached_versions !== false ) {
			return $cached_versions;
		}

		$response = wp_remote_get( self::GITHUB_API_URL_TCPDF6, array(
			'timeout' => 10,
			'headers' => array(
				'Accept' => 'application/vnd.github.v3+json',
				'User-Agent' => 'Poker-Tournament-Import/' . POKER_TOURNAMENT_IMPORT_VERSION
			)
		));

		if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
			error_log( 'TDWP: Failed to fetch TCPDF 6.x versions' );
			return array();
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		$versions = array();
		foreach ( $data as $release ) {
			if ( isset( $release['ref'] ) ) {
				$version = str_replace( 'refs/tags/', '', $release['ref'] );
				if ( preg_match( '/^6\.\d+\.\d+$/', $version ) ) {
					$versions[] = $version;
				}
			}
			}

		// Sort versions (newest first)
		usort( $versions, 'version_compare' );
		$versions = array_reverse( $versions );

		// Cache for 7 days
		set_transient( 'tdwp_tcpdf6_available_versions', $versions, WEEK_IN_SECONDS );
		
		return $versions;
	}

/**
	 * Get the preferred PDF library version based on preference algorithm
	 * 
	 * Preference Logic:
	 * 1. Try to get latest TCPDF 6.x version (preferred)
	 * 2. If 6.x unavailable, fallback to latest tc-lib-pdf 8.x
	 * 3. If both unavailable, return configured fallback version
	 *
	 * @since 3.3.0
	 * @return string|false Preferred version number or false on total failure
	 */
	public function get_preferred_version() {
		// Try TCPDF 6.x first (preferred)
		$tcpdf6_version = $this->get_tcpdf6_latest_version();
		
		if ( $tcpdf6_version !== false ) {
			error_log( "TDWP: Selected TCPDF 6.x version: $tcpdf6_version (preferred)" );
			return $tcpdf6_version;
		}
		
		// Fallback to tc-lib-pdf 8.x
		$tclib8_versions = $this->get_tclib8_available_versions();
		
		if ( ! empty( $tclib8_versions ) ) {
			$latest_tclib8 = $tclib8_versions[0]; // Already sorted descending
			error_log( "TDWP: Selected tc-lib-pdf 8.x version: $latest_tclib8 (fallback)" );
			return $latest_tclib8;
		}
		
		// Ultimate fallback to hardcoded version
		error_log( "TDWP: Using ultimate fallback version: " . self::TCPDF6_FALLBACK_VERSION );
		return self::TCPDF6_FALLBACK_VERSION;
	}

	/**
	 * Get available versions from both repositories with lineage labels
	 * 
	 * Merges TCPDF 6.x and tc-lib-pdf 8.x versions with clear lineage identification
	 *
	 * @since 3.3.0
	 * @return array Available versions with lineage information
	 */
	public function get_available_versions_with_lineage() {
		$versions = array();
		
		// Get TCPDF 6.x versions
		$tcpdf6_versions = $this->get_tcpdf6_available_versions();
		foreach ( $tcpdf6_versions as $version ) {
			$versions[] = array(
				'version' => $version,
				'lineage' => 'TCPDF 6.x (Legacy)',
				'repository' => 'tecnickcom/TCPDF',
				'preferred' => true,
				'major' => 6
			);
		}
		
		// Get tc-lib-pdf 8.x versions
		$tclib8_versions = $this->get_tclib8_available_versions();
		foreach ( $tclib8_versions as $version ) {
			$versions[] = array(
				'version' => $version,
				'lineage' => 'tc-lib-pdf 8.x (Modern)',
				'repository' => 'tecnickcom/tc-lib-pdf',
				'preferred' => false,
				'major' => 8
			);
		}
		
		// Sort by major version (6.x first) then by version number descending
		usort( $versions, function( $a, $b ) {
			if ( $a['major'] !== $b['major'] ) {
				return $a['major'] < $b['major'] ? -1 : 1; // 6.x before 8.x
			}
			// Within same major, sort by version number descending
			return version_compare( $b['version'], $a['version'] );
		});
		
		return $versions;
	}

	/**
	 * Filter versions by major version number
	 *
	 * @since 3.3.0
	 * @param array  $versions Array of version strings
	 * @param string $major    Major version number (e.g., '6' or '8')
	 * @return array Filtered versions
	 */
	public function filter_versions_by_major( $versions, $major ) {
		return array_filter( $versions, function( $version ) use ( $major ) {
			return strpos( $version, $major . '.' ) === 0;
		});
	}

	/**
	 * Refresh version cache for both repositories
	 *
	 * @since 3.3.0
	 * @return array Cache refresh results
	 */
	public function refresh_version_cache() {
		$results = array(
			'tcpdf6' => false,
			'tclib8' => false,
			'combined' => false
		);
		
		// Clear existing caches
		delete_transient( 'tdwp_latest_tcpdf6_version' );
		delete_transient( 'tdwp_available_tcpdf6_versions' );
		delete_transient( 'tdwp_latest_tclib8_version' );
		delete_transient( 'tdwp_available_tclib8_versions' );
		
		// Refresh TCPDF 6.x
		$tcpdf6_latest = $this->get_tcpdf6_latest_version();
		$tcpdf6_available = $this->get_tcpdf6_available_versions();
		$results['tcpdf6'] = ( $tcpdf6_latest !== false && ! empty( $tcpdf6_available ) );
		
		// Refresh tc-lib-pdf 8.x
		$tclib8_available = $this->get_tclib8_available_versions();
		$results['tclib8'] = ! empty( $tclib8_available );
		
		// Combined success
		$results['combined'] = $results['tcpdf6'] && $results['tclib8'];
		
		error_log( 'TDWP: Version cache refresh results: ' . print_r( $results, true ) );
		
		return $results;
	}

	/**
	 * Get available tc-lib-pdf 8.x versions for fallback
	 *
	 * @since 3.3.0
	 * @return array List of available tc-lib-pdf 8.x versions
	 */
	public function get_tclib8_available_versions() {
		$cached_versions = get_transient( 'tdwp_tclib8_available_versions' );
		
		if ( $cached_versions !== false ) {
			return $cached_versions;
		}

		$response = wp_remote_get( self::GITHUB_API_URL, array(
			'timeout' => 10,
			'headers' => array(
				'Accept' => 'application/vnd.github.v3+json',
				'User-Agent' => 'Poker-Tournament-Import/' . POKER_TOURNAMENT_IMPORT_VERSION
			)
		));

		if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
			error_log( 'TDWP: Failed to fetch tc-lib-pdf 8.x versions' );
			return array();
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		$versions = array();
		foreach ( $data as $release ) {
			if ( isset( $release['ref'] ) ) {
				$version = str_replace( 'refs/tags/', '', $release['ref'] );
				if ( preg_match( '/^8\.\d+\.\d+$/', $version ) ) {
					$versions[] = $version;
				}
			}
		}

		// Sort versions (newest first)
		usort( $versions, 'version_compare' );
		$versions = array_reverse( $versions );

		// Cache for 7 days
		set_transient( 'tdwp_tclib8_available_versions', $versions, WEEK_IN_SECONDS );
		
		return $versions;
	}

    /**
     * Get currently installed tc-lib-pdf version
     *
     * @since 3.3.0
     * @return string Current version number
     */
    public function get_installed_version() {
        $config_file = $this->tcpdf_path . 'config/tcpdf_config.php';
        
        if ( ! file_exists( $config_file ) ) {
            return 'Not installed';
        }

        // Try to read version from composer.json if available
        $composer_file = $this->tcpdf_path . 'composer.json';
        if ( file_exists( $composer_file ) ) {
            $composer_data = json_decode( file_get_contents( $composer_file ), true );
            if ( isset( $composer_data['version'] ) ) {
                return $composer_data['version'];
            }
        }

        // Fallback: try to detect from TCPDF_CONFIG_BIG main constant
        if ( file_exists( $config_file ) ) {
            $content = file_get_contents( $config_file );
            if ( preg_match( '/define\s*\(\s*\'TCPDF_MAJOR_VERSION\'\s*,\s*[\'"](\d+)[\'"]\s*\)/', $content, $matches ) ) {
                $major = $matches[1];
                if ( preg_match( '/define\s*\(\s*\'TCPDF_MINOR_VERSION\'\s*,\s*[\'"](\d+)[\'"]\s*\)/', $content, $matches ) ) {
                    $minor = $matches[1];
                    if ( preg_match( '/define\s*\(\s*\'TCPDF_PATCH_VERSION\'\s*,\s*[\'"](\d+)[\'"]\s*\)/', $content, $matches ) ) {
                        $patch = $matches[1];
                        return "$major.$minor.$patch";
                    }
                }
            }
        }

        return 'Unknown';
    }

    /**
     * Check if updates are available
     *
     * @since 3.3.0
     * @return array Update status information
     */
    public function check_updates() {
        $current = $this->get_installed_version();
        $latest = $this->get_latest_version();

        if ( $latest === false ) {
            return array(
                'status' => 'error',
                'message' => 'Unable to check for updates',
                'current' => $current,
                'latest' => 'Unknown'
            );
        }

        if ( $current === 'Not installed' ) {
            return array(
                'status' => 'not_installed',
                'message' => 'PDF library not installed',
                'current' => $current,
                'latest' => $latest
            );
        }

        if ( version_compare( $current, $latest, '<' ) ) {
            return array(
                'status' => 'update_available',
                'message' => "Update available: $latest",
                'current' => $current,
                'latest' => $latest
            );
        }

        return array(
            'status' => 'current',
            'message' => 'Up to date',
            'current' => $current,
            'latest' => $latest
        );
    }

    /**
     * Get available versions for rollback (with lineage information)
     *
     * @since 3.3.0
     * @return array List of available versions with lineage data
     */
    public function get_available_versions() {
        // Use new lineage-aware version system
        $lineage_versions = $this->get_available_versions_with_lineage();
        
        // Convert to simple format for backward compatibility
        $versions = array();
        foreach ( $lineage_versions as $version_info ) {
            $versions[] = $version_info['version'];
        }
        
        return $versions;
    }

    /**
     * Download specific version from appropriate repository
     * 
     * Automatically detects whether version is TCPDF 6.x or tc-lib-pdf 8.x
     * and uses the correct repository and structure handling
     *
     * @since 3.3.0
     * @param string $version Version to download
     * @return array Operation result
     */
    public function download_specific_version( $version ) {
        // Validate version format
        if ( ! preg_match( '/^\d+\.\d+\.\d+$/', $version ) ) {
            return array(
                'success' => false,
                'message' => 'Invalid version format'
            );
        }

        // Determine version type and repository
        $is_tcpdf6 = strpos( $version, '6.' ) === 0;
        $is_tclib8 = strpos( $version, '8.' ) === 0;

        if ( $is_tcpdf6 ) {
            // Use TCPDF 6.x repository
            $download_url = sprintf( self::TCPDF6_DOWNLOAD_URL, $version );
            $expected_dir = $this->library_install_dir . "TCPDF-$version/";
            $repository = 'tecnickcom/TCPDF';
        } elseif ( $is_tclib8 ) {
            // Use tc-lib-pdf 8.x repository
            $download_url = sprintf( self::TCPDF_DOWNLOAD_URL, $version );
            $expected_dir = $this->library_install_dir . "tc-lib-pdf-$version/";
            $repository = 'tecnickcom/tc-lib-pdf';
        } else {
            return array(
                'success' => false,
                'message' => "Version $version is not supported (must be 6.x or 8.x)"
            );
        }

        error_log( "TDWP: Downloading version $version from repository $repository" );

        $temp_file = download_url( $download_url, 300 );

        if ( is_wp_error( $temp_file ) ) {
            $error_code = $temp_file->get_error_code();
            $error_message = $temp_file->get_error_message();

            // Enhanced error messages
            if ( 'http_404' === $error_code ) {
                return array(
                    'success' => false,
                    'message' => "Version $version not found in $repository. Please check available versions."
                );
            } elseif ( 'http_request_failed' === $error_code && strpos( $error_message, 'SSL' ) !== false ) {
                return array(
                    'success' => false,
                    'message' => 'SSL connection failed. Server may not allow outbound HTTPS connections.'
                );
            } elseif ( 'timeout' === $error_code ) {
                return array(
                    'success' => false,
                    'message' => 'Download timeout. GitHub may be temporarily unavailable.'
                );
            } else {
                return array(
                    'success' => false,
                    'message' => "Download failed ($error_code): $error_message"
                );
            }
        }

        // Verify ZIP file integrity
        if ( filesize( $temp_file ) < 1000000 ) { // Less than 1MB seems wrong
            unlink( $temp_file );
            return array(
                'success' => false,
                'message' => 'Downloaded file appears corrupted or incomplete.'
            );
        }

        // Remove existing installation
        if ( file_exists( $this->tcpdf_path ) ) {
            $this->remove_directory( $this->tcpdf_path );
        }

        // Unzip the file
        WP_Filesystem();
        global $wp_filesystem;
        
        $unzip_result = unzip_file( $temp_file, $this->library_install_dir );
        
        // Cleanup temp file
        unlink( $temp_file );

        if ( is_wp_error( $unzip_result ) ) {
            return array(
                'success' => false,
                'message' => 'Failed to extract ZIP file: ' . $unzip_result->get_error_message()
            );
        }

        // Handle different directory structures
        $installation_success = false;
        
        if ( $is_tcpdf6 && file_exists( $expected_dir ) ) {
            // TCPDF 6.x: Rename to standard tcpdf directory
            if ( rename( $expected_dir, $this->tcpdf_path ) ) {
                $installation_success = true;
                error_log( "TDWP: Successfully installed TCPDF 6.x version $version" );
            }
        } elseif ( $is_tclib8 && file_exists( $expected_dir ) ) {
            // tc-lib-pdf 8.x: Rename to standard tcpdf directory
            if ( rename( $expected_dir, $this->tcpdf_path ) ) {
                $installation_success = true;
                error_log( "TDWP: Successfully installed tc-lib-pdf 8.x version $version" );
            }
        } else {
            // Try to detect what was extracted
            $extracted_dirs = glob( $this->library_install_dir . '*', GLOB_ONLYDIR );
            $found_dir = '';
            
            foreach ( $extracted_dirs as $dir ) {
                if ( basename( $dir ) !== '.' && basename( $dir ) !== '..' && 
                     strpos( basename( $dir ), 'tcpdf' ) !== false ) {
                    $found_dir = $dir;
                    break;
                }
            }
            
            if ( $found_dir && rename( $found_dir, $this->tcpdf_path ) ) {
                $installation_success = true;
                error_log( "TDWP: Successfully installed detected directory for version $version" );
            }
        }

        if ( ! $installation_success ) {
            return array(
                'success' => false,
                'message' => "Failed to locate or rename expected directory after extraction. Expected: $expected_dir"
            );
        }

        // Apply PHP 8.2+ compatibility patches if needed (TCPDF 6.x only)
        if ( $is_tcpdf6 && $this->php_version_requires_patches() ) {
            error_log( "TDWP: Applying PHP 8.2+ compatibility patches for TCPDF 6.x version $version" );
            
            $patch_result = $this->apply_php82_compatibility_patches( $this->tcpdf_path );
            
            if ( ! $patch_result['success'] ) {
                error_log( "TDWP: WARNING - Some patches failed: " . implode( ', ', $patch_result['errors'] ) );
                // Don't fail installation entirely, but log the issue
            } else {
                error_log( "TDWP: Successfully applied {$patch_result['patches_applied']} compatibility patches" );
            }
        }

        // Validate installation after patching
        $validation_result = $this->validate_tcpdf_installation();
        
        if ( ! $validation_result['success'] ) {
            // If validation fails, try fallback to tc-lib-pdf 8.x for TCPDF 6.x installations
            if ( $is_tcpdf6 ) {
                error_log( "TDWP: TCPDF 6.x validation failed, attempting fallback to tc-lib-pdf 8.x" );
                
                // Remove failed TCPDF 6.x installation
                $this->remove_directory( $this->tcpdf_path );
                
                // Get latest tc-lib-pdf 8.x version
                $tclib8_versions = $this->get_tclib8_available_versions();
                if ( ! empty( $tclib8_versions ) ) {
                    $fallback_version = $tclib8_versions[0];
                    error_log( "TDWP: Falling back to tc-lib-pdf 8.x version $fallback_version" );
                    
                    // Recursively call this method with tc-lib-pdf 8.x version
                    return $this->download_specific_version( $fallback_version );
                } else {
                    return array(
                        'success' => false,
                        'message' => 'TCPDF 6.x installation failed and tc-lib-pdf 8.x fallback unavailable. Validation errors: ' . implode( ', ', $validation_result['errors'] )
                    );
                }
            } else {
                return array(
                    'success' => false,
                    'message' => 'Installation validation failed: ' . implode( ', ', $validation_result['errors'] )
                );
            }
        }

        // Create compatibility layer for older code expecting TCPDF constants
        $this->create_compatibility_layer( $version );

        // Update installed version
        $this->current_version = $version;

        // Clear version cache to force refresh
        $this->refresh_version_cache();

        $lineage = $is_tcpdf6 ? 'TCPDF 6.x (Legacy)' : 'tc-lib-pdf 8.x (Modern)';
        $patch_info = '';
        
        if ( $is_tcpdf6 && $this->php_version_requires_patches() ) {
            $patch_info = ' with PHP 8.2+ compatibility patches';
        }
        
        return array(
            'success' => true,
            'message' => "Successfully installed $lineage version $version$patch_info",
            'version' => $version,
            'lineage' => $lineage,
            'repository' => $repository,
            'validation' => $validation_result
        );
    }

/**
     * Apply PHP 8.2+ compatibility patches to TCPDF installation
     * 
     * Automatically patches deprecated curly brace syntax in TCPDF 6.x files
     *
     * @since 3.3.0
     * @param string $directory Path to TCPDF installation directory
     * @return array Patching results
     */
    public function apply_php82_compatibility_patches( $directory ) {
        $results = array(
            'files_scanned' => 0,
            'files_patched' => 0,
            'patches_applied' => 0,
            'errors' => array(),
            'success' => true
        );

        if ( ! is_dir( $directory ) ) {
            $results['success'] = false;
            $results['errors'][] = 'TCPDF directory not found: ' . $directory;
            return $results;
        }

        error_log( "TDWP: Applying PHP 8.2+ compatibility patches to TCPDF in: $directory" );

        // Get all PHP files recursively
        $iterator = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $directory ) );
        $php_files = new RegexIterator( $iterator, '/^.+\.php$/i', RecursiveRegexIterator::GET_MATCH );

        foreach ( $php_files as $file ) {
            $file_path = $file[0];
            $results['files_scanned']++;

            // Skip files that are not likely to contain deprecated syntax
            if ( strpos( $file_path, 'vendor' ) !== false || 
                 strpos( $file_path, 'examples' ) !== false ||
                 basename( $file_path ) === 'tcpdf_autoconfig.php' ) {
                continue;
            }

            $patch_result = $this->patch_file_php82_syntax( $file_path );
            
            if ( $patch_result['patches_applied'] > 0 ) {
                $results['files_patched']++;
                $results['patches_applied'] += $patch_result['patches_applied'];
                error_log( "TDWP: Patched {$patch_result['patches_applied']} issues in $file_path" );
            }

            if ( ! empty( $patch_result['errors'] ) ) {
                $results['errors'] = array_merge( $results['errors'], $patch_result['errors'] );
            }
        }

        if ( ! empty( $results['errors'] ) ) {
            $results['success'] = false;
        }

        error_log( "TDWP: PHP 8.2+ patching complete - Files scanned: {$results['files_scanned']}, Files patched: {$results['files_patched']}, Patches applied: {$results['patches_applied']}" );

        return $results;
    }

    /**
     * Patch PHP 8.2+ compatibility issues in a specific file
     *
     * @since 3.3.0
     * @param string $file_path Path to PHP file to patch
     * @return array Patching results for this file
     */
    private function patch_file_php82_syntax( $file_path ) {
        $result = array(
            'patches_applied' => 0,
            'errors' => array()
        );

        if ( ! file_exists( $file_path ) || ! is_readable( $file_path ) ) {
            $result['errors'][] = "Cannot read file: $file_path";
            return $result;
        }

        // Read file content
        $content = file_get_contents( $file_path );
        if ( $content === false ) {
            $result['errors'][] = "Failed to read file content: $file_path";
            return $result;
        }

        $original_content = $content;

        // Enhanced patterns to match ALL deprecated curly brace syntax
        $patterns = array(
            // Simple numeric index: $var{0}, $var{1}, $var{123} (most common case)
            '/(\$[a-zA-Z_][a-zA-Z0-9_]*)\{(\d+)\}/',
            
            // String literal index: $var{'key'}, $var{"key"}
            '/(\$[a-zA-Z_][a-zA-Z0-9_]*)\{(\'[^\']*\'|"[^"]*")\}/',
            
            // Variable index: $var{$index}, $var{$obj->property}
            '/(\$[a-zA-Z_][a-zA-Z0-9_]*)\{(\$[a-zA-Z_][a-zA-Z0-9_\->:\$]*)\}/',
            
            // Object property with numeric index: $obj->prop{0}
            '/(\$[a-zA-Z_][a-zA-Z0-9_]*->[a-zA-Z_][a-zA-Z0-9_]*)\{(\d+)\}/',
            
            // Object property with string index: $obj->prop{'key'}
            '/(\$[a-zA-Z_][a-zA-Z0-9_]*->[a-zA-Z_][a-zA-Z0-9_]*)\{(\'[^\']*\'|"[^"]*")\}/',
            
            // Object property with variable index: $obj->prop{$index}
            '/(\$[a-zA-Z_][a-zA-Z0-9_]*->[a-zA-Z_][a-zA-Z0-9_]*)\{(\$[a-zA-Z_][a-zA-Z0-9_\->:\$]*)\}/',
            
            // Complex object chains: $obj->prop->method{0}
            '/(\$[a-zA-Z_][a-zA-Z0-9_]*(?:->[a-zA-Z_][a-zA-Z0-9_]*)+)\{(\d+)\}/',
            
            // Complex object chains with strings: $obj->prop->method{'key'}
            '/(\$[a-zA-Z_][a-zA-Z0-9_]*(?:->[a-zA-Z_][a-zA-Z0-9_]*)+)\{(\'[^\']*\'|"[^"]*")\}/',
            
            // Complex object chains with variables: $obj->prop->method{$index}
            '/(\$[a-zA-Z_][a-zA-Z0-9_]*(?:->[a-zA-Z_][a-zA-Z0-9_]*)+)\{(\$[a-zA-Z_][a-zA-Z0-9_\->:\$]*)\}/',
        );

        $replacements = array(
            '$1[$2]', // Simple numeric index
            '$1[$2]', // String literal index  
            '$1[$2]', // Variable index
            '$1[$2]', // Object property with numeric index
            '$1[$2]', // Object property with string index
            '$1[$2]', // Object property with variable index
            '$1[$2]', // Complex object chains with numeric
            '$1[$2]', // Complex object chains with strings
            '$1[$2]', // Complex object chains with variables
        );

        // Apply each pattern individually to count patches accurately
        $total_patches = 0;
        foreach ( $patterns as $index => $pattern ) {
            $content = preg_replace( $pattern, $replacements[$index], $content, -1, $count );
            $total_patches += $count;
        }
        
        $result['patches_applied'] = $total_patches;

        // Only write file if changes were made
        if ( $content !== $original_content ) {
            // Create backup of original file
            $backup_path = $file_path . '.php82_backup';
            if ( ! copy( $file_path, $backup_path ) ) {
                $result['errors'][] = "Failed to create backup: $backup_path";
                return $result;
            }

            // Write patched content
            if ( file_put_contents( $file_path, $content ) === false ) {
                $result['errors'][] = "Failed to write patched content: $file_path";
                // Restore from backup
                copy( $backup_path, $file_path );
                unlink( $backup_path );
                return $result;
            }

            // Remove backup after successful write
            unlink( $backup_path );
        }

        return $result;
    }

    /**
     * Detect if current PHP version requires compatibility patches
     *
     * @since 3.3.0
     * @return bool True if PHP version requires patches
     */
    public function php_version_requires_patches() {
        $php_version = phpversion();
        return version_compare( $php_version, '8.2.0', '>=' );
    }

    /**
     * Validate TCPDF installation after patching
     *
     * @since 3.3.0
     * @return array Validation results
     */
    public function validate_tcpdf_installation() {
        $results = array(
            'success' => false,
            'tcpdf_class_exists' => false,
            'tcpdf_version' => false,
            'basic_functionality' => false,
            'errors' => array()
        );

        try {
            // Check if TCPDF class exists
            if ( ! class_exists( 'TCPDF' ) ) {
                // Try to include the main TCPDF file
                $tcpdf_file = $this->tcpdf_path . 'tcpdf.php';
                if ( file_exists( $tcpdf_file ) ) {
                    require_once $tcpdf_file;
                }
            }

            if ( class_exists( 'TCPDF' ) ) {
                $results['tcpdf_class_exists'] = true;

                // Check TCPDF version
                if ( defined( 'TCPDF_VERSION' ) ) {
                    $results['tcpdf_version'] = TCPDF_VERSION;
                }

                // Test basic functionality
                try {
                    $pdf = new TCPDF( PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false );
                    $pdf->AddPage();
                    $pdf->SetFont( 'helvetica', '', 12 );
                    $pdf->Cell( 0, 10, 'Test', 0, 1, 'C' );
                    
                    // Test output generation (without actually creating file)
                    $output = $pdf->Output( '', 'S' );
                    if ( strlen( $output ) > 100 ) {
                        $results['basic_functionality'] = true;
                    }
                } catch ( Exception $e ) {
                    $results['errors'][] = 'TCPDF functionality test failed: ' . $e->getMessage();
                }
            } else {
                $results['errors'][] = 'TCPDF class not found after installation';
            }
        } catch ( Exception $e ) {
            $results['errors'][] = 'Validation error: ' . $e->getMessage();
        }

        $results['success'] = $results['tcpdf_class_exists'] && 
                             $results['tcpdf_version'] !== false && 
                             $results['basic_functionality'];

        return $results;
    }

/**
     * Force patch existing TCPDF installation for PHP 8.2+ compatibility
     * 
     * This method is used to patch existing installations that weren't patched
     * during the original download process.
     *
     * @since 3.3.0
     * @return array Patching results
     */
    public function force_patch_existing_tcpdf() {
        $results = array(
            'success' => false,
            'tcpdf_found' => false,
            'patches_applied' => 0,
            'message' => ''
        );

        // Check if we need to patch (PHP 8.2+)
        if ( ! $this->php_version_requires_patches() ) {
            $results['success'] = true;
            $results['message'] = 'PHP version does not require patches';
            return $results;
        }

        // Try to find TCPDF in various possible locations
        $possible_paths = array(
            $this->tcpdf_path,
            dirname( $this->tcpdf_path ) . '/vendor/tcpdf/',
            dirname( dirname( __FILE__ ) ) . '/vendor/tcpdf/',
            plugin_dir_path( dirname( __FILE__ ) ) . 'vendor/tcpdf/'
        );

        $tcpdf_path = false;
        foreach ( $possible_paths as $path ) {
            if ( file_exists( $path . 'tcpdf.php' ) ) {
                $tcpdf_path = $path;
                $results['tcpdf_found'] = true;
                break;
            }
        }

        if ( ! $tcpdf_path ) {
            $results['message'] = 'TCPDF installation not found';
            return $results;
        }

        error_log( "TDWP: Force patching existing TCPDF installation at: $tcpdf_path" );

        // Apply patches to the found TCPDF installation
        $patch_result = $this->apply_php82_compatibility_patches( $tcpdf_path );
        
        if ( $patch_result['success'] ) {
            $results['success'] = true;
            $results['patches_applied'] = $patch_result['patches_applied'];
            $results['message'] = "Successfully patched {$patch_result['patches_applied']} compatibility issues";
            
            // Validate the patched installation
            $validation = $this->validate_tcpdf_installation();
            if ( ! $validation['success'] ) {
                $results['success'] = false;
                $results['message'] .= ' but validation failed: ' . implode( ', ', $validation['errors'] );
            }
        } else {
            $results['message'] = 'Patching failed: ' . implode( ', ', $patch_result['errors'] );
        }

        return $results;
    }

    /**
     * Check and patch TCPDF installation if needed (called on plugin load)
     *
     * This method ensures existing installations are compatible with current PHP version
     *
     * @since 3.3.0
     * @return void
     */
    public function ensure_tcpdf_compatibility() {
        static $compatibility_checked = false;
        
        if ( $compatibility_checked ) {
            return;
        }
        
        $compatibility_checked = true;

        // Only check if we need PHP 8.2+ patches
        if ( ! $this->php_version_requires_patches() ) {
            return;
        }

        // Check if TCPDF is already working
        $validation = $this->validate_tcpdf_installation();
        
        if ( $validation['success'] ) {
            error_log( 'TDWP: TCPDF installation is already compatible' );
            return;
        }

        error_log( 'TDWP: TCPDF compatibility issue detected, attempting to patch existing installation' );

        // Try to patch existing installation
        $patch_result = $this->force_patch_existing_tcpdf();
        
        if ( ! $patch_result['success'] ) {
            error_log( 'TDWP: Failed to patch TCPDF installation: ' . $patch_result['message'] );
            
            // Set flag to download fresh version during admin_init (when download_url() is available)
            $preferred_version = $this->get_preferred_version();
            if ( $preferred_version ) {
                error_log( "TDWP: Scheduling download of fresh compatible version during admin_init: $preferred_version" );
                update_option( 'tdwp_tcpdf_download_needed', array(
                    'version' => $preferred_version,
                    'reason' => 'Patching failed: ' . $patch_result['message'],
                    'timestamp' => time()
                ) );
            }
        }
    }

/**
     * Handle TCPDF download fallback during admin_init (when download_url() is available)
     *
     * @since 3.3.0
     * @return void
     */
    public function handle_tcpdf_download_fallback() {
        static $download_handled = false;
        
        if ( $download_handled ) {
            return;
        }
        
        $download_handled = true;

        // Check if download is needed
        $download_needed = get_option( 'tdwp_tcpdf_download_needed', false );
        
        if ( ! $download_needed ) {
            return;
        }

        // Verify download_url function is available
        if ( ! function_exists( 'download_url' ) ) {
            error_log( 'TDWP: download_url() function not available, cannot perform TCPDF download' );
            $this->add_admin_notice( 
                'TCPDF download could not be completed: WordPress file utilities not available.',
                'error'
            );
            return;
        }

        error_log( 'TDWP: Performing scheduled TCPDF download for version: ' . $download_needed['version'] );

        // Perform the download
        $download_result = $this->download_specific_version( $download_needed['version'] );
        
        if ( $download_result['success'] ) {
            // Success - clear the flag and show success notice
            delete_option( 'tdwp_tcpdf_download_needed' );
            
            $this->add_admin_notice( 
                sprintf( 
                    'TCPDF %s installed successfully! %s',
                    esc_html( $download_result['lineage'] ),
                    esc_html( $download_result['message'] )
                ),
                'success'
            );
            
            error_log( 'TDWP: TCPDF download completed successfully: ' . $download_result['message'] );
        } else {
            // Failure - keep the flag for retry and show error notice
            $this->add_admin_notice( 
                sprintf( 
                    'Failed to install TCPDF %s: %s. The plugin will retry automatically.',
                    esc_html( $download_needed['version'] ),
                    esc_html( $download_result['message'] )
                ),
                'error'
            );
            
            error_log( 'TDWP: TCPDF download failed: ' . $download_result['message'] );
        }
    }

    /**
     * Add admin notice for TCPDF operations
     *
     * @since 3.3.0
     * @param string $message Notice message
     * @param string $type Notice type (success, error, warning, info)
     * @return void
     */
    private function add_admin_notice( $message, $type = 'info' ) {
        // Store notice in transient to display on next admin page load
        $notices = get_transient( 'tdwp_admin_notices', array() );
        
        $notices[] = array(
            'message' => $message,
            'type' => $type,
            'timestamp' => time()
        );
        
        // Store notices for 24 hours
        set_transient( 'tdwp_admin_notices', $notices, DAY_IN_SECONDS );
    }

    /**
     * Create compatibility layer for tc-lib-pdf
     *
     * @since 3.3.0
     * @param string $version Installed version
     */
    private function create_compatibility_layer( $version ) {
        $config_dir = $this->tcpdf_path . 'config/';
        
        // Ensure config directory exists
        if ( ! file_exists( $config_dir ) ) {
            wp_mkdir_p( $config_dir );
        }

        $config_file = $config_dir . 'tcpdf_config.php';
        
        // Create basic config with version constants
        $config_content = "<?php\n";
        $config_content .= "// tc-lib-pdf compatibility configuration\n";
        $config_content .= "// Auto-generated by Poker Tournament Import plugin\n";
        
        // Add version constants if not present
        $version_parts = explode( '.', $version );
        if ( count( $version_parts ) === 3 ) {
            $config_content .= "\nif (!defined('TCPDF_MAJOR_VERSION')) define('TCPDF_MAJOR_VERSION', '{$version_parts[0]}');\n";
            $config_content .= "if (!defined('TCPDF_MINOR_VERSION')) define('TCPDF_MINOR_VERSION', '{$version_parts[1]}');\n";
            $config_content .= "if (!defined('TCPDF_PATCH_VERSION')) define('TCPDF_PATCH_VERSION', '{$version_parts[2]}');\n";
            $config_content .= "if (!defined('TCPDF_VERSION')) define('TCPDF_VERSION', '$version');\n";
        }

        file_put_contents( $config_file, $config_content );
    }

    
/**
     * Get TCPDF version (for backward compatibility)
     *
     * @since 3.3.0
     * @return string Current TCPDF version
     */
    public function get_tcpdf_version() {
        return $this->get_current_version();
    }

/**
     * Get current version (for admin interface compatibility)
     *
     * @since 3.3.0
     * @return string Current version
     */
    public function get_current_version() {
        return $this->current_version;
    }

    /**
     * Get latest version (for admin interface compatibility)
     *
     * @since 3.3.0
     * @return string Latest version or error message
     */
    public function get_latest_version_safe() {
        $latest = $this->get_latest_version();
        return $latest === false ? 'Unable to detect' : $latest;
    }

/**
	 * Get comprehensive dependency status for admin interface
	 *
	 * @since 3.3.0
	 * @return array Complete dependency status information
	 */
	public function get_dependency_status() {
		$updates = $this->check_updates();
		$installed_version = $this->get_installed_version();
		$latest_version = $this->get_latest_version_safe();
		$last_check = get_transient( 'tdwp_tcpdf_last_check', false );

		return array(
			'tcpdf_available' => $this->is_tcpdf_available(),
			'installed_version' => $installed_version,
			'latest_version' => $latest_version,
			'last_check' => $last_check,
			'tcpdf_path' => $this->get_tcpdf_path(),
			'update_available' => $updates['status'] === 'update_available',
			'status' => $updates['status'],
			'message' => $updates['message']
		);
	}

	/**
	 * Check for updates (alias for admin interface compatibility)
	 *
	 * @since 3.3.0
	 * @return array Update status information
	 */
	public function check_for_updates() {
		$updates = $this->check_updates();
		
		return array(
			'update_available' => $updates['status'] === 'update_available',
			'installed_version' => $updates['current'],
			'latest_version' => $updates['latest']
		);
	}

	/**
	 * Extract TCPDF from uploaded archive file
	 *
	 * @since 3.3.0
	 * @param string $archive_path Path to uploaded ZIP file
	 * @return array Operation result
	 */
	public function extract_tcpdf_from_archive( $archive_path ) {
		if ( ! file_exists( $archive_path ) ) {
			return array(
				'success' => false,
				'message' => 'Archive file not found'
			);
		}

		// Validate file size
		if ( filesize( $archive_path ) < 1000000 ) { // Less than 1MB seems wrong
			return array(
				'success' => false,
				'message' => 'Archive file appears corrupted or too small.'
			);
		}

		// Extract the archive
		WP_Filesystem();
		global $wp_filesystem;
		
		$unzip_result = unzip_file( $archive_path, $this->library_install_dir );
		
		if ( is_wp_error( $unzip_result ) ) {
			return array(
				'success' => false,
				'message' => 'Failed to extract archive: ' . $unzip_result->get_error_message()
			);
		}

		// Detect and rename extracted directory
		$extracted_dirs = glob( $this->library_install_dir . 'tc-lib-pdf-*', GLOB_ONLYDIR );
		
		if ( ! empty( $extracted_dirs ) ) {
			// Remove existing installation
			if ( file_exists( $this->tcpdf_path ) ) {
				$this->remove_directory( $this->tcpdf_path );
			}
			
			$new_dir = $extracted_dirs[0];
			if ( ! rename( $new_dir, $this->tcpdf_path ) ) {
				return array(
					'success' => false,
					'message' => 'Failed to rename extracted directory. Check permissions.'
				);
			}
		} else {
			return array(
				'success' => false,
				'message' => 'Could not find tc-lib-pdf directory in archive.'
			);
		}

		// Update current version
		$this->current_version = $this->get_installed_version();
		
		// Clear caches
		delete_transient( 'tdwp_latest_tcpdf_version' );
		delete_transient( 'tdwp_available_tcpdf_versions' );

		return array(
			'success' => true,
			'message' => 'Successfully extracted and installed PDF library',
			'version' => $this->current_version
		);
	}

	/**
	 * Rollback to specific version
	 *
	 * @since 3.3.0
	 * @param string $version Version to rollback to
	 * @return array Operation result
	 */
	public function rollback_to_version( $version ) {
		return $this->download_specific_version( $version );
	}

	/**
	 * Clear version cache
	 *
	 * @since 3.3.0
	 * @return array Operation result
	 */
	public function clear_version_cache() {
		delete_transient( 'tdwp_latest_tcpdf_version' );
		delete_transient( 'tdwp_available_tcpdf_versions' );
		delete_transient( 'tdwp_tcpdf_last_check' );
		
		// Refresh the cache
		$this->get_latest_version();
		
		return array(
			'success' => true,
			'message' => 'Version cache cleared successfully'
		);
	}

	/**
	 * Check if TCPDF is available and functional
	 *
	 * @since 3.3.0
	 * @return bool True if TCPDF is available
	 */
	public function is_tcpdf_available() {
		$tcpdf_path = $this->get_tcpdf_path();

		if ( ! file_exists( $tcpdf_path ) ) {
			return false;
		}

		// Verify file integrity
		if ( ! $this->verify_tcpdf_integrity() ) {
			return false;
		}

		// Try to include the file to check for syntax errors
		try {
			if ( ! function_exists( 'TCPDF' ) ) {
				require_once $tcpdf_path;
			}
			return class_exists( 'TCPDF' );
		} catch ( Exception $e ) {
			error_log( "TDWP: TCPDF integrity check failed: " . $e->getMessage() );
			return false;
		}
	}

	/**
	 * Get path to the main TCPDF file
	 *
	 * @since 3.3.0
	 * @return string Full path to tcpdf.php
	 */
	public function get_tcpdf_path() {
		return $this->tcpdf_path . 'tcpdf.php';
	}

	/**
     * Download and install tc-lib-pdf from GitHub (latest version)
     *
     * @since 3.3.0
     * @return array Operation result
     */
    public function download_tcpdf() {
        // Get latest version
        $latest_version = $this->get_latest_version();
        
        if ( $latest_version === false ) {
            return array(
                'success' => false,
                'message' => 'Unable to determine latest version. Please check internet connection.'
            );
        }

        // Use the specific version download method
        return $this->download_specific_version( $latest_version );
    }

	/**
	 * Verify TCPDF installation integrity
	 *
	 * @since 3.3.0
	 * @return bool True if integrity is verified
	 */
	private function verify_tcpdf_integrity() {
		$tcpdf_path = $this->get_tcpdf_path();

		if ( ! file_exists( $tcpdf_path ) ) {
			return false;
		}

		// Check file size (should be substantial)
		if ( filesize( $tcpdf_path ) < 500000 ) { // Less than 500KB seems wrong
			return false;
		}

		// Check for key TCPDF classes/functions
		$content = file_get_contents( $tcpdf_path );
		if ( strpos( $content, 'class TCPDF' ) === false ) {
			return false;
		}

		return true;
	}

	/**
	 * Validate download integrity for dynamic versions
	 *
	 * @since 3.3.0
	 * @param string $file_path Path to downloaded file
	 * @param string $version Version being downloaded
	 * @return bool True if integrity is validated
	 */
	private function validate_download_integrity( $file_path, $version ) {
		if ( ! file_exists( $file_path ) ) {
			return false;
		}

		// Check file size - should be reasonable for TCPDF/tc-lib-pdf
		$file_size = filesize( $file_path );
		if ( $file_size < 2000000 ) { // Less than 2MB seems wrong
			error_log( "TDWP: Downloaded file too small: {$file_size} bytes for version {$version}" );
			return false;
		}

		// Try to validate it's actually a ZIP file
		$file_handle = fopen( $file_path, 'rb' );
		if ( ! $file_handle ) {
			return false;
		}

		// Check ZIP file signature (first 4 bytes should be PK\x03\x04 or PK\x05\x06)
		$signature = fread( $file_handle, 4 );
		fclose( $file_handle );

		if ( $signature !== "PK\x03\x04" && $signature !== "PK\x05\x06" ) {
			error_log( "TDWP: Downloaded file is not a valid ZIP file for version {$version}" );
			return false;
		}

		return true;
	}

	/**
	 * Store installed version information
	 *
	 * @since 3.3.0
	 * @param string $version Version that was installed
	 */
	private function store_installed_version( $version ) {
		$tcpdf_dir = $this->get_tcpdf_directory();
		$version_file = $tcpdf_dir . '/VERSION';

		WP_Filesystem();
		global $wp_filesystem;

		$wp_filesystem->mkdir( $tcpdf_dir );
		$wp_filesystem->put_contents( $version_file, $version );

		// Also store in WordPress options for easier access
		update_option( 'tdwp_tc_lib_pdf_installed_version', $version );
		update_option( 'tdwp_tc_lib_pdf_install_date', current_time( 'mysql' ) );
	}
}
