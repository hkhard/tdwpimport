<?php
/**
 * Tournament Player Manager
 *
 * Manages player registrations for tournaments
 *
 * @package Poker_Tournament_Import
 * @subpackage Tournament_Manager
 * @since 3.1.0
 */

// Prevent direct file access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tournament Player Manager class
 *
 * @since 3.1.0
 */
class TDWP_Tournament_Player_Manager {

	/**
	 * Add player to tournament
	 *
	 * @since 3.1.0
	 * @param int   $tournament_id Tournament ID.
	 * @param int   $player_id     Player ID.
	 * @param array $args          Additional arguments.
	 * @return int|WP_Error Player registration ID on success, WP_Error on failure.
	 */
	public static function add_player( $tournament_id, $player_id, $args = array() ) {
		global $wpdb;

		// Validate tournament exists.
		if ( ! get_post( $tournament_id ) || 'live_tournament' !== get_post_type( $tournament_id ) ) {
			return new WP_Error( 'invalid_tournament', __( 'Invalid tournament ID', 'poker-tournament-import' ) );
		}

		// Validate player exists.
		if ( ! get_post( $player_id ) || 'player' !== get_post_type( $player_id ) ) {
			return new WP_Error( 'invalid_player', __( 'Invalid player ID', 'poker-tournament-import' ) );
		}

		// Check if player already registered.
		if ( self::is_player_registered( $tournament_id, $player_id ) ) {
			return new WP_Error( 'player_already_registered', __( 'Player is already registered for this tournament', 'poker-tournament-import' ) );
		}

		// Parse args.
		$defaults = array(
			'status'            => 'registered',
			'paid_amount'       => 0,
			'rebuys_count'      => 0,
			'addons_count'      => 0,
			'seat_assignment'   => null,
			'finish_position'   => null,
			'prize_amount'      => 0,
			'notes'             => '',
		);

		$data = wp_parse_args( $args, $defaults );

		// Insert player registration.
		$table = $wpdb->prefix . 'tdwp_tournament_players';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$result = $wpdb->insert(
			$table,
			array(
				'tournament_id'   => $tournament_id,
				'player_id'       => $player_id,
				'status'          => sanitize_text_field( $data['status'] ),
				'paid_amount'     => floatval( $data['paid_amount'] ),
				'rebuys_count'    => intval( $data['rebuys_count'] ),
				'addons_count'    => intval( $data['addons_count'] ),
				'seat_assignment' => $data['seat_assignment'] ? sanitize_text_field( $data['seat_assignment'] ) : null,
				'finish_position' => $data['finish_position'] ? intval( $data['finish_position'] ) : null,
				'prize_amount'    => floatval( $data['prize_amount'] ),
				'notes'           => wp_kses_post( $data['notes'] ),
			),
			array( '%d', '%d', '%s', '%f', '%d', '%d', '%s', '%d', '%f', '%s' )
		);

		if ( false === $result ) {
			return new WP_Error( 'db_insert_failed', __( 'Failed to add player to tournament', 'poker-tournament-import' ) );
		}

		do_action( 'tdwp_player_added_to_tournament', $wpdb->insert_id, $tournament_id, $player_id );

		return $wpdb->insert_id;
	}

	/**
	 * Remove player from tournament
	 *
	 * @since 3.1.0
	 * @param int $tournament_id Tournament ID.
	 * @param int $player_id     Player ID.
	 * @return bool True on success, false on failure.
	 */
	public static function remove_player( $tournament_id, $player_id ) {
		global $wpdb;

		$table = $wpdb->prefix . 'tdwp_tournament_players';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->delete(
			$table,
			array(
				'tournament_id' => $tournament_id,
				'player_id'     => $player_id,
			),
			array( '%d', '%d' )
		);

		if ( false === $result ) {
			return false;
		}

		do_action( 'tdwp_player_removed_from_tournament', $tournament_id, $player_id );

		return true;
	}

	/**
	 * Update player status
	 *
	 * @since 3.1.0
	 * @param int    $tournament_id Tournament ID.
	 * @param int    $player_id     Player ID.
	 * @param string $status        New status.
	 * @return bool True on success, false on failure.
	 */
	public static function update_player_status( $tournament_id, $player_id, $status ) {
		global $wpdb;

		$table = $wpdb->prefix . 'tdwp_tournament_players';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->update(
			$table,
			array( 'status' => sanitize_text_field( $status ) ),
			array(
				'tournament_id' => $tournament_id,
				'player_id'     => $player_id,
			),
			array( '%s' ),
			array( '%d', '%d' )
		);

		if ( false === $result ) {
			return false;
		}

		do_action( 'tdwp_player_status_updated', $tournament_id, $player_id, $status );

		return true;
	}

	/**
	 * Get tournament players
	 *
	 * @since 3.1.0
	 * @param int    $tournament_id Tournament ID.
	 * @param string $status        Optional. Filter by status.
	 * @return array Array of player registration objects.
	 */
	public static function get_tournament_players( $tournament_id, $status = '' ) {
		global $wpdb;

		$table = $wpdb->prefix . 'tdwp_tournament_players';

		if ( $status ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$players = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM {$table} WHERE tournament_id = %d AND status = %s ORDER BY registration_date ASC",
					$tournament_id,
					$status
				)
			);
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$players = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM {$table} WHERE tournament_id = %d ORDER BY registration_date ASC",
					$tournament_id
				)
			);
		}

		return $players;
	}

	/**
	 * Check if player is registered
	 *
	 * @since 3.1.0
	 * @param int $tournament_id Tournament ID.
	 * @param int $player_id     Player ID.
	 * @return bool True if registered, false otherwise.
	 */
	public static function is_player_registered( $tournament_id, $player_id ) {
		global $wpdb;

		$table = $wpdb->prefix . 'tdwp_tournament_players';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE tournament_id = %d AND player_id = %d",
				$tournament_id,
				$player_id
			)
		);

		return $count > 0;
	}

	/**
	 * Get player count for tournament
	 *
	 * @since 3.1.0
	 * @param int    $tournament_id Tournament ID.
	 * @param string $status        Optional. Filter by status.
	 * @return int Player count.
	 */
	public static function get_player_count( $tournament_id, $status = '' ) {
		global $wpdb;

		$table = $wpdb->prefix . 'tdwp_tournament_players';

		if ( $status ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$count = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$table} WHERE tournament_id = %d AND status = %s",
					$tournament_id,
					$status
				)
			);
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$count = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$table} WHERE tournament_id = %d",
					$tournament_id
				)
			);
		}

		return (int) $count;
	}


	/**
	 * Bust player - Mark player as eliminated (Phase 2 Beta22)
	 *
	 * @since 3.1.0
	 * @param int      $tournament_id Tournament ID.
	 * @param int      $player_id Player ID.
	 * @param int      $entry_number Entry number (for re-entries).
	 * @param int|null $eliminated_by_id Player ID of eliminator (for bounties).
	 * @return array|WP_Error Success data or error
	 */
	public static function bust_player( $tournament_id, $player_id, $entry_number = 1, $eliminated_by_id = null ) {
		global $wpdb;
		$table = $wpdb->prefix . 'tdwp_tournament_players';

		// Validate tournament is running (Beta 22.3)
		$state = TDWP_Live_State_Manager::get_state( $tournament_id );
		if ( ! $state || ! in_array( $state->status, array( 'running', 'paused', 'break' ), true ) ) {
			return new WP_Error(
				'tournament_not_running',
				__( 'Can only eliminate players when tournament is running', 'poker-tournament-import' )
			);
		}

		// Get tournament financial policy
		$allow_reentry         = (int) get_post_meta( $tournament_id, '_allow_reentry', true );
		$reentry_until_level   = (int) get_post_meta( $tournament_id, '_reentry_until_level', true );
		$bounty_type           = get_post_meta( $tournament_id, '_bounty_type', true );
		$bounty_amount         = (float) get_post_meta( $tournament_id, '_bounty_amount', true );
		$bounty_percentage     = (float) get_post_meta( $tournament_id, '_bounty_percentage', true );

		// Get current level from state (already fetched above)
		$current_level = $state->current_level;

		// Check if re-entry is available
		$can_reentry = false;
		if ( $allow_reentry && ( 0 === $reentry_until_level || $current_level <= $reentry_until_level ) ) {
			$can_reentry = true;
		}

		// Get player's current entry
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$entry = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE tournament_id = %d AND player_id = %d AND entry_number = %d",
				$tournament_id,
				$player_id,
				$entry_number
			)
		);

		if ( ! $entry ) {
			return new WP_Error( 'invalid_entry', __( 'Player entry not found', 'poker-tournament-import' ) );
		}

		// Count active players to calculate finish position
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$active_count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE tournament_id = %d AND status IN ('registered', 'paid', 'active')",
				$tournament_id
			)
		);

		// Calculate finish position (only if NOT eligible for re-entry)
		$finish_position = null;
		if ( ! $can_reentry ) {
			$finish_position = (int) $active_count;
		}

		// Prepare update data
		$update_data = array(
			'status'                  => 'eliminated',
			'elimination_time'        => current_time( 'mysql' ),
			'eliminations_count'      => (int) $entry->eliminations_count + 1,
		);

		if ( $eliminated_by_id ) {
			$update_data['eliminated_by_player_id'] = $eliminated_by_id;
		}

		// Only set finish position if NOT eligible for re-entry
		if ( null !== $finish_position ) {
			$update_data['finish_position'] = $finish_position;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->update(
			$table,
			$update_data,
			array(
				'tournament_id' => $tournament_id,
				'player_id'     => $player_id,
				'entry_number'  => $entry_number,
			),
			array( '%s', '%s', '%d', '%d', '%d' ),
			array( '%d', '%d', '%d' )
		);

		if ( false === $result ) {
			return new WP_Error( 'update_failed', __( 'Failed to update player status', 'poker-tournament-import' ) );
		}

		// Unseat eliminated player immediately (Beta 22.2)
		TDWP_Seat_Manager::unseat_player( $player_id );

		// Process bounty if applicable
		$bounty_earned = 0;
		if ( $eliminated_by_id && 'none' !== $bounty_type && $bounty_amount > 0 ) {
			$bounty_earned = self::award_bounty(
				$tournament_id,
				$entry->player_id,
				$eliminated_by_id,
				$bounty_type,
				$entry->bounty_amount > 0 ? $entry->bounty_amount : $bounty_amount,
				$bounty_percentage
			);
		}

		// Check tournament completion: 1 player remaining (Beta 22.2)
		$tournament_completed = false;
		$remaining            = $active_count - 1;
		if ( 1 === $remaining && ! $can_reentry ) {
			// Get the last remaining player
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$winner = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT * FROM {$table} WHERE tournament_id = %d AND status IN ('active', 'paid', 'checked_in') LIMIT 1",
					$tournament_id
				)
			);

			if ( $winner ) {
				// Set winner's finish position = 1
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
				$wpdb->update(
					$table,
					array( 'finish_position' => 1 ),
					array(
						'tournament_id' => $tournament_id,
						'player_id'     => $winner->player_id,
						'entry_number'  => $winner->entry_number,
					),
					array( '%d' ),
					array( '%d', '%d', '%d' )
				);

				// Mark tournament as finished
				TDWP_Live_State_Manager::finish( $tournament_id );
				$tournament_completed = true;
			}
		}

		// Get player post for name
		$player_post = get_post( $player_id );
		$player_name = $player_post ? $player_post->post_title : "Player #{$player_id}";

		return array(
			'message'              => sprintf(
				/* translators: %s: player name */
				__( '%s has been eliminated', 'poker-tournament-import' ),
				$player_name
			),
			'can_reentry'          => $can_reentry,
			'finish_position'      => $finish_position,
			'bounty_earned'        => $bounty_earned,
			'remaining_count'      => $remaining,
			'tournament_completed' => $tournament_completed,
		);
	}

	/**
	 * Award bounty to eliminator (Phase 2 Beta24)
	 *
	 * @since 3.1.0
	 * @param int    $tournament_id Tournament ID.
	 * @param int    $eliminated_id Eliminated player ID.
	 * @param int    $eliminator_id Eliminator player ID.
	 * @param string $bounty_type Bounty type (fixed/pko).
	 * @param float  $bounty_value Bounty amount.
	 * @param float  $bounty_percentage PKO split percentage.
	 * @return float Amount earned by eliminator
	 */
	private static function award_bounty( $tournament_id, $eliminated_id, $eliminator_id, $bounty_type, $bounty_value, $bounty_percentage ) {
		global $wpdb;
		$table = $wpdb->prefix . 'tdwp_tournament_players';

		// Get eliminator's latest active entry
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$eliminator_entry = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE tournament_id = %d AND player_id = %d AND status IN ('registered', 'paid', 'active') ORDER BY entry_number DESC LIMIT 1",
				$tournament_id,
				$eliminator_id
			)
		);

		if ( ! $eliminator_entry ) {
			return 0;
		}

		$earned = 0;

		if ( 'fixed' === $bounty_type ) {
			// Fixed bounty: Full amount to eliminator
			$earned = $bounty_value;

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->update(
				$table,
				array(
					'bounties_earned'       => $eliminator_entry->bounties_earned + $earned,
					'bounties_from_players' => (int) $eliminator_entry->bounties_from_players + 1,
				),
				array(
					'id' => $eliminator_entry->id,
				),
				array( '%f', '%d' ),
				array( '%d' )
			);
		} elseif ( 'pko' === $bounty_type ) {
			// PKO: Split by percentage
			$pct     = min( max( 0, $bounty_percentage ), 100 );
			$earned  = $bounty_value * ( $pct / 100 );
			$added   = $bounty_value - $earned;

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->update(
				$table,
				array(
					'bounties_earned'       => $eliminator_entry->bounties_earned + $earned,
					'bounty_amount'         => $eliminator_entry->bounty_amount + $added,
					'bounties_from_players' => (int) $eliminator_entry->bounties_from_players + 1,
				),
				array(
					'id' => $eliminator_entry->id,
				),
				array( '%f', '%f', '%d' ),
				array( '%d' )
			);
		}

		return $earned;
	}

	/**
	 * Re-entry player (Phase 2 Beta23)
	 *
	 * @since 3.1.0
	 * @param int $tournament_id Tournament ID.
	 * @param int $player_id Player ID.
	 * @return array|WP_Error Success data or error
	 */
	public static function reentry_player( $tournament_id, $player_id ) {
		global $wpdb;
		$table = $wpdb->prefix . 'tdwp_tournament_players';

		// Get tournament re-entry policy
		$allow_reentry       = (int) get_post_meta( $tournament_id, '_allow_reentry', true );
		$reentry_cost        = (float) get_post_meta( $tournament_id, '_reentry_cost', true );
		$reentry_chips       = (int) get_post_meta( $tournament_id, '_reentry_chips', true );
		$reentry_limit       = (int) get_post_meta( $tournament_id, '_reentry_limit', true );
		$reentry_until_level = (int) get_post_meta( $tournament_id, '_reentry_until_level', true );
		$starting_chips      = (int) get_post_meta( $tournament_id, '_starting_chips', true );

		// Validate re-entry allowed
		if ( ! $allow_reentry ) {
			return new WP_Error( 'reentry_not_allowed', __( 'Re-entry is not allowed for this tournament', 'poker-tournament-import' ) );
		}

		// Check current level
		$state         = TDWP_Live_State_Manager::get_state( $tournament_id );
		$current_level = $state ? $state->current_level : 1;

		if ( $reentry_until_level > 0 && $current_level > $reentry_until_level ) {
			return new WP_Error( 'reentry_closed', __( 'Re-entry period has ended', 'poker-tournament-import' ) );
		}

		// Get player's entries
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$entries = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE tournament_id = %d AND player_id = %d ORDER BY entry_number ASC",
				$tournament_id,
				$player_id
			)
		);

		if ( empty( $entries ) ) {
			return new WP_Error( 'no_entries', __( 'Player has no entries in this tournament', 'poker-tournament-import' ) );
		}

		// Check re-entry limit
		$entry_count = count( $entries );
		if ( $reentry_limit > 0 && $entry_count >= ( $reentry_limit + 1 ) ) {
			return new WP_Error( 'reentry_limit_reached', __( 'Re-entry limit reached', 'poker-tournament-import' ) );
		}

		// Get original entry
		$original_entry_id = $entries[0]->id;
		$new_entry_number  = $entry_count + 1;

		// Use reentry_chips if set, otherwise starting_chips
		$chips = $reentry_chips > 0 ? $reentry_chips : $starting_chips;

		// Insert new entry
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$result = $wpdb->insert(
			$table,
			array(
				'tournament_id'     => $tournament_id,
				'player_id'         => $player_id,
				'entry_number'      => $new_entry_number,
				'is_reentry'        => 1,
				'original_entry_id' => $original_entry_id,
				'status'            => 'active',
				'paid_amount'       => $reentry_cost,
				'chip_count'        => $chips,
				'registration_date' => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%d', '%d', '%d', '%s', '%f', '%d', '%s' )
		);

		if ( false === $result ) {
			return new WP_Error( 'insert_failed', __( 'Failed to create re-entry', 'poker-tournament-import' ) );
		}

		// Update original entry's reentry_count
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->update(
			$table,
			array( 'reentry_count' => $entry_count ),
			array( 'id' => $original_entry_id ),
			array( '%d' ),
			array( '%d' )
		);

		// Try to auto-seat
		TDWP_Seat_Manager::auto_seat_player( $player_id, $tournament_id );

		// Get player name
		$player_post = get_post( $player_id );
		$player_name = $player_post ? $player_post->post_title : "Player #{$player_id}";

		return array(
			'message'      => sprintf(
				/* translators: %s: player name */
				__( '%s has re-entered', 'poker-tournament-import' ),
				$player_name
			),
			'entry_number' => $new_entry_number,
			'chip_count'   => $chips,
		);
	}

	/**
	 * Get player registration data
	 *
	 * @since 3.1.0
	 * @param int $tournament_id Tournament ID.
	 * @param int $player_id     Player ID.
	 * @return object|null Player registration object or null if not found.
	 */
	public static function get_player_registration( $tournament_id, $player_id ) {
		global $wpdb;

		$table = $wpdb->prefix . 'tdwp_tournament_players';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$registration = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE tournament_id = %d AND player_id = %d",
				$tournament_id,
				$player_id
			)
		);

		return $registration;
	}

	/**
	 * Process rebuy (Phase 2 Beta25)
	 *
	 * @since 3.1.0
	 * @param int $tournament_id Tournament ID.
	 * @param int $player_id Player ID.
	 * @param int $entry_number Entry number.
	 * @return array|WP_Error Success data or error
	 */
	public static function process_rebuy( $tournament_id, $player_id, $entry_number = 1 ) {
		global $wpdb;
		$table = $wpdb->prefix . 'tdwp_tournament_players';

		// Get tournament rebuy policy
		$rebuy_cost           = (float) get_post_meta( $tournament_id, '_rebuy_cost', true );
		$rebuy_chips          = (int) get_post_meta( $tournament_id, '_rebuy_chips', true );
		$rebuy_until_level    = (int) get_post_meta( $tournament_id, '_rebuy_until_level', true );
		$rebuy_limit_per_player = (int) get_post_meta( $tournament_id, '_rebuy_limit_per_player', true );

		// Check if rebuys allowed
		if ( $rebuy_until_level <= 0 ) {
			return new WP_Error( 'rebuy_not_allowed', __( 'Rebuys are not allowed for this tournament', 'poker-tournament-import' ) );
		}

		// Check current level
		$state         = TDWP_Live_State_Manager::get_state( $tournament_id );
		$current_level = $state ? $state->current_level : 1;

		if ( $current_level > $rebuy_until_level ) {
			return new WP_Error( 'rebuy_period_ended', __( 'Rebuy period has ended', 'poker-tournament-import' ) );
		}

		// Get player entry
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$entry = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE tournament_id = %d AND player_id = %d AND entry_number = %d",
				$tournament_id,
				$player_id,
				$entry_number
			)
		);

		if ( ! $entry ) {
			return new WP_Error( 'entry_not_found', __( 'Player entry not found', 'poker-tournament-import' ) );
		}

		// Check rebuy limit
		if ( $rebuy_limit_per_player > 0 && $entry->rebuys_count >= $rebuy_limit_per_player ) {
			return new WP_Error( 'rebuy_limit_reached', __( 'Rebuy limit reached', 'poker-tournament-import' ) );
		}

		// Process rebuy
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->update(
			$table,
			array(
				'rebuys_count' => $entry->rebuys_count + 1,
				'paid_amount'  => $entry->paid_amount + $rebuy_cost,
				'chip_count'   => $entry->chip_count + $rebuy_chips,
			),
			array(
				'tournament_id' => $tournament_id,
				'player_id'     => $player_id,
				'entry_number'  => $entry_number,
			),
			array( '%d', '%f', '%d' ),
			array( '%d', '%d', '%d' )
		);

		if ( false === $result ) {
			return new WP_Error( 'update_failed', __( 'Failed to process rebuy', 'poker-tournament-import' ) );
		}

		return array(
			'message'       => __( 'Rebuy processed successfully', 'poker-tournament-import' ),
			'rebuys_count'  => $entry->rebuys_count + 1,
			'chip_count'    => $entry->chip_count + $rebuy_chips,
			'paid_amount'   => $entry->paid_amount + $rebuy_cost,
		);
	}

	/**
	 * Process addon (Phase 2 Beta25)
	 *
	 * @since 3.1.0
	 * @param int $tournament_id Tournament ID.
	 * @param int $player_id Player ID.
	 * @param int $entry_number Entry number.
	 * @return array|WP_Error Success data or error
	 */
	public static function process_addon( $tournament_id, $player_id, $entry_number = 1 ) {
		global $wpdb;
		$table = $wpdb->prefix . 'tdwp_tournament_players';

		// Get tournament addon policy
		$addon_cost        = (float) get_post_meta( $tournament_id, '_addon_cost', true );
		$addon_chips       = (int) get_post_meta( $tournament_id, '_addon_chips', true );
		$addon_at_level    = (int) get_post_meta( $tournament_id, '_addon_at_level', true );
		$addon_until_level = (int) get_post_meta( $tournament_id, '_addon_until_level', true );

		// Check if addons allowed
		if ( $addon_at_level <= 0 ) {
			return new WP_Error( 'addon_not_allowed', __( 'Add-ons are not allowed for this tournament', 'poker-tournament-import' ) );
		}

		// Check current level
		$state         = TDWP_Live_State_Manager::get_state( $tournament_id );
		$current_level = $state ? $state->current_level : 1;

		if ( $current_level < $addon_at_level ) {
			return new WP_Error( 'addon_not_yet', __( 'Add-on not yet available', 'poker-tournament-import' ) );
		}

		if ( $addon_until_level > 0 && $current_level > $addon_until_level ) {
			return new WP_Error( 'addon_period_ended', __( 'Add-on period has ended', 'poker-tournament-import' ) );
		}

		// Get player entry
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$entry = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE tournament_id = %d AND player_id = %d AND entry_number = %d",
				$tournament_id,
				$player_id,
				$entry_number
			)
		);

		if ( ! $entry ) {
			return new WP_Error( 'entry_not_found', __( 'Player entry not found', 'poker-tournament-import' ) );
		}

		// Check if addon already taken (usually only 1 per player)
		if ( $entry->addons_count > 0 ) {
			return new WP_Error( 'addon_already_taken', __( 'Add-on already taken', 'poker-tournament-import' ) );
		}

		// Process addon
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->update(
			$table,
			array(
				'addons_count' => $entry->addons_count + 1,
				'paid_amount'  => $entry->paid_amount + $addon_cost,
				'chip_count'   => $entry->chip_count + $addon_chips,
			),
			array(
				'tournament_id' => $tournament_id,
				'player_id'     => $player_id,
				'entry_number'  => $entry_number,
			),
			array( '%d', '%f', '%d' ),
			array( '%d', '%d', '%d' )
		);

		if ( false === $result ) {
			return new WP_Error( 'update_failed', __( 'Failed to process add-on', 'poker-tournament-import' ) );
		}

		return array(
			'message'      => __( 'Add-on processed successfully', 'poker-tournament-import' ),
			'addons_count' => $entry->addons_count + 1,
			'chip_count'   => $entry->chip_count + $addon_chips,
			'paid_amount'  => $entry->paid_amount + $addon_cost,
		);
	}

	/**
	 * Update chip count (Phase 2 Beta26)
	 *
	 * @since 3.1.0
	 * @param int $tournament_id Tournament ID.
	 * @param int $player_id Player ID.
	 * @param int $entry_number Entry number.
	 * @param int $chip_count New chip count.
	 * @return bool Success
	 */
	public static function update_chip_count( $tournament_id, $player_id, $entry_number, $chip_count ) {
		global $wpdb;
		$table = $wpdb->prefix . 'tdwp_tournament_players';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->update(
			$table,
			array( 'chip_count' => max( 0, (int) $chip_count ) ),
			array(
				'tournament_id' => $tournament_id,
				'player_id'     => $player_id,
				'entry_number'  => $entry_number,
			),
			array( '%d' ),
			array( '%d', '%d', '%d' )
		);

		return false !== $result;
	}
}
