<?php
/**
 * Poker Statistics Engine
 *
 * Handles calculation and storage of dashboard statistics
 * in the data mart for fast dashboard loading.
 *
 * @package Poker Tournament Import
 */

// Prevent direct file access
if (!defined('ABSPATH')) {
    exit;
}

class Poker_Statistics_Engine {

    /**
     * Singleton instance
     */
    private static $instance = null;

    /**
     * Statistics table name
     */
    private $stats_table;

    /**
     * Players table name
     */
    private $players_table;

    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        global $wpdb;
        $this->stats_table = $wpdb->prefix . 'poker_statistics';
        $this->players_table = $wpdb->prefix . 'poker_tournament_players';
    }

    /**
     * Calculate and store all dashboard statistics
     */
    public function calculate_all_statistics() {
        global $wpdb;

        // Start timer for performance tracking
        $start_time = microtime(true);

        // Clear existing statistics
        $this->clear_all_statistics();

        // Calculate basic counts
        $this->update_statistic('total_tournaments', $this->get_total_tournaments(), 'count');
        $this->update_statistic('total_players', $this->get_unique_players(), 'count');
        $this->update_statistic('active_series', $this->get_active_series(), 'count');
        $this->update_statistic('total_prize_pool', $this->get_total_prize_pool(), 'sum');

        // Calculate derived statistics
        $total_tournaments = $this->get_total_tournaments();
        $total_prize_pool = $this->get_total_prize_pool();
        $this->update_statistic('avg_prize_pool', $total_tournaments > 0 ? $total_prize_pool / $total_tournaments : 0, 'average');

        // Calculate time-based statistics
        $this->update_statistic('recent_tournaments_30d', $this->get_recent_tournaments(30), 'count');
        $this->update_statistic('new_players_30d', $this->get_new_players(30), 'count');

        // **PHASE 1: Player Ranking & Performance Metrics**
        $this->update_statistic('total_entries', $this->get_total_entries(), 'count');
        $this->update_statistic('total_cashouts', $this->get_total_cashouts(), 'count');
        $this->update_statistic('total_payouts', $this->get_total_payouts(), 'sum');
        $this->update_statistic('average_players_per_tournament', $this->get_average_players_per_tournament(), 'average');
        $this->update_statistic('average_entry_fee', $this->get_average_entry_fee(), 'average');
        $this->update_statistic('largest_prize_pool', $this->get_largest_prize_pool(), 'max');
        $this->update_statistic('highest_single_payout', $this->get_highest_single_payout(), 'max');
        $this->update_statistic('average_finish_position', $this->get_average_finish_position(), 'average');
        $this->update_statistic('total_unique_players', $this->get_total_unique_players(), 'count');

        // Log performance
        $calculation_time = round((microtime(true) - $start_time) * 1000, 2);
        error_log("Poker Statistics: All statistics calculated in {$calculation_time}ms");

        return true;
    }

    /**
     * Update a single statistic
     */
    public function update_statistic($name, $value, $type = 'count', $related_id = null) {
        global $wpdb;

        $result = $wpdb->replace(
            $this->stats_table,
            array(
                'stat_name' => $name,
                'stat_value' => $value,
                'stat_type' => $type,
                'calculation_date' => current_time('Y-m-d'),
                'related_id' => $related_id
            ),
            array(
                '%s', '%f', '%s', '%s', '%d'
            )
        );

        if ($result === false) {
            error_log("Poker Statistics: Failed to update statistic '{$name}'");
        }

        return $result !== false;
    }

    /**
     * Get a single statistic value
     */
    public function get_statistic($name) {
        global $wpdb;

        $value = $wpdb->get_var($wpdb->prepare(
            "SELECT stat_value FROM {$this->stats_table} WHERE stat_name = %s LIMIT 1",
            $name
        ));

        return $value !== null ? floatval($value) : 0;
    }

    /**
     * Get multiple statistics at once
     */
    public function get_statistics($names) {
        $stats = array();
        foreach ($names as $name) {
            $stats[$name] = $this->get_statistic($name);
        }
        return $stats;
    }

    /**
     * Clear all statistics
     */
    public function clear_all_statistics() {
        global $wpdb;
        return $wpdb->query("TRUNCATE TABLE {$this->stats_table}");
    }

    /**
     * Get total tournaments count
     */
    private function get_total_tournaments() {
        return intval(wp_count_posts('tournament')->publish);
    }

    /**
     * Get unique players count
     */
    private function get_unique_players() {
        global $wpdb;
        return intval($wpdb->get_var("SELECT COUNT(DISTINCT player_id) FROM {$this->players_table}"));
    }

    /**
     * Get active series count
     */
    private function get_active_series() {
        return intval(wp_count_posts('tournament_series')->publish);
    }

    /**
     * Get total prize pool
     */
    private function get_total_prize_pool() {
        global $wpdb;

        // Try different possible prize pool field names
        $possible_fields = array('_prize_pool', 'prize_pool', '_tournament_prize_pool', 'tournament_prize_pool');

        foreach ($possible_fields as $field) {
            $total = $wpdb->get_var($wpdb->prepare(
                "SELECT SUM(CAST(meta_value AS DECIMAL(10,2))) FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value != ''",
                $field
            ));
            if ($total && $total > 0) {
                error_log("Poker Statistics: Using prize pool field '{$field}' with total {$total}");
                return floatval($total);
            }
        }

        return 0;
    }

    /**
     * Get recent tournaments within days
     */
    private function get_recent_tournaments($days = 30) {
        global $wpdb;

        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts}
             WHERE post_type = 'tournament' AND post_status = 'publish'
             AND post_date >= %s",
            date('Y-m-d', strtotime("-{$days} days"))
        ));

        return intval($count);
    }

    /**
     * Get new players within days
     */
    private function get_new_players($days = 30) {
        global $wpdb;

        // Try different possible UUID field names - prioritize tournament_uuid since that's what we have data for
        $possible_uuid_fields = array('tournament_uuid', '_tournament_uuid', 'uuid', '_uuid');

        foreach ($possible_uuid_fields as $uuid_field) {
            // Check if this UUID field exists in tournaments
            $field_count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = %s",
                $uuid_field
            ));

            if ($field_count && $field_count > 0) {
                $count = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(DISTINCT tp.player_id)
                     FROM {$this->players_table} tp
                     WHERE tp.tournament_id IN (
                         SELECT meta_value FROM {$wpdb->postmeta}
                         WHERE meta_key = %s
                         AND post_id IN (
                             SELECT ID FROM {$wpdb->posts}
                             WHERE post_type = 'tournament'
                             AND post_status = 'publish'
                             AND post_date >= %s
                         )
                     )",
                    $uuid_field,
                    date('Y-m-d', strtotime("-{$days} days"))
                ));

                error_log("Poker Statistics: Using UUID field '{$uuid_field}' for new players calculation");
                return intval($count);
            }
        }

        return 0;
    }

    /**
     * Refresh statistics (public method for manual refresh)
     */
    public function refresh_statistics() {
        return $this->calculate_all_statistics();
    }

    /**
     * Get statistics last updated time
     */
    public function get_last_updated() {
        global $wpdb;

        $last_updated = $wpdb->get_var("SELECT MAX(last_updated) FROM {$this->stats_table}");

        return $last_updated ? $last_updated : false;
    }

    /**
     * Get statistics for dashboard
     */
    public function get_dashboard_statistics() {
        // Auto-calculate if statistics table is empty
        if (!$this->has_statistics()) {
            error_log("Poker Statistics: No statistics found, calculating initial statistics");
            $this->calculate_all_statistics();
        }

        return array(
            'total_tournaments' => $this->get_statistic('total_tournaments'),
            'total_players' => $this->get_statistic('total_players'),
            'total_prize_pool' => $this->get_statistic('total_prize_pool'),
            'avg_prize_pool' => $this->get_statistic('avg_prize_pool'),
            'active_series' => $this->get_statistic('active_series'),
            'recent_tournaments_30d' => $this->get_statistic('recent_tournaments_30d'),
            'new_players_30d' => $this->get_statistic('new_players_30d'),
            'last_updated' => $this->get_last_updated(),

            // **PHASE 1: Enhanced Player Metrics**
            'total_entries' => $this->get_statistic('total_entries'),
            'total_cashouts' => $this->get_statistic('total_cashouts'),
            'total_payouts' => $this->get_statistic('total_payouts'),
            'average_players_per_tournament' => $this->get_statistic('average_players_per_tournament'),
            'average_entry_fee' => $this->get_statistic('average_entry_fee'),
            'largest_prize_pool' => $this->get_statistic('largest_prize_pool'),
            'highest_single_payout' => $this->get_statistic('highest_single_payout'),
            'average_finish_position' => $this->get_statistic('average_finish_position'),
            'total_unique_players' => $this->get_statistic('total_unique_players')
        );
    }

    /**
     * Check if statistics table has data
     */
    private function has_statistics() {
        global $wpdb;
        $count = $wpdb->get_var("SELECT COUNT(*) FROM {$this->stats_table}");
        return intval($count) > 0;
    }

    /**
     * Hook into tournament import completion
     */
    public function on_tournament_import_complete($tournament_id) {
        // Refresh statistics after each tournament import
        $this->calculate_all_statistics();
    }

    /**
     * AJAX handler for manual statistics refresh
     */
    public function ajax_refresh_statistics() {
        check_ajax_referer('poker_refresh_statistics', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'poker-tournament-import'));
        }

        $result = $this->refresh_statistics();

        if ($result) {
            wp_send_json_success(array(
                'message' => __('Statistics refreshed successfully!', 'poker-tournament-import'),
                'timestamp' => current_time('mysql'),
                'stats' => $this->get_dashboard_statistics()
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Failed to refresh statistics.', 'poker-tournament-import')
            ));
        }
    }

    /**
     * Get total entries (buy-ins) across all tournaments
     */
    private function get_total_entries() {
        global $wpdb;
        $total = $wpdb->get_var("SELECT SUM(buyins) FROM {$this->players_table}");
        return intval($total ?: 0);
    }

    /**
     * Get total cashouts (players who won money)
     */
    private function get_total_cashouts() {
        global $wpdb;
        $count = $wpdb->get_var("SELECT COUNT(*) FROM {$this->players_table} WHERE winnings > 0");
        return intval($count ?: 0);
    }

    /**
     * Get total payouts across all tournaments
     */
    private function get_total_payouts() {
        global $wpdb;
        $total = $wpdb->get_var("SELECT SUM(winnings) FROM {$this->players_table}");
        return floatval($total ?: 0);
    }

    /**
     * Get average players per tournament
     */
    private function get_average_players_per_tournament() {
        global $wpdb;

        // Get average from tournament meta data first
        $avg_from_meta = $wpdb->get_var(
            "SELECT AVG(CAST(meta_value AS DECIMAL(10,2)))
             FROM {$wpdb->postmeta}
             WHERE meta_key = '_players_count' AND meta_value != ''"
        );

        if ($avg_from_meta && $avg_from_meta > 0) {
            return floatval($avg_from_meta);
        }

        // Fallback: calculate from players table
        $tournament_count = $this->get_total_tournaments();
        if ($tournament_count > 0) {
            $total_entries = $this->get_total_entries();
            return $total_entries / $tournament_count;
        }

        return 0;
    }

    /**
     * Get average entry fee
     */
    private function get_average_entry_fee() {
        global $wpdb;

        $total_entries = $this->get_total_entries();
        $tournament_count = $this->get_total_tournaments();

        if ($total_entries > 0 && $tournament_count > 0) {
            return $total_entries / $tournament_count;
        }

        return 0;
    }

    /**
     * Get largest prize pool
     */
    private function get_largest_prize_pool() {
        global $wpdb;

        // Try different possible prize pool field names
        $possible_fields = array('_prize_pool', 'prize_pool', '_tournament_prize_pool', 'tournament_prize_pool');

        foreach ($possible_fields as $field) {
            $max = $wpdb->get_var($wpdb->prepare(
                "SELECT MAX(CAST(meta_value AS DECIMAL(10,2))) FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value != ''",
                $field
            ));
            if ($max && $max > 0) {
                return floatval($max);
            }
        }

        // Fallback: calculate from players table
        $max = $wpdb->get_var(
            "SELECT MAX(winnings) FROM {$this->players_table}"
        );
        return floatval($max ?: 0);
    }

    /**
     * Get highest single payout
     */
    private function get_highest_single_payout() {
        global $wpdb;
        $max = $wpdb->get_var("SELECT MAX(winnings) FROM {$this->players_table}");
        return floatval($max ?: 0);
    }

    /**
     * Get average finish position across all players
     */
    private function get_average_finish_position() {
        global $wpdb;
        $avg = $wpdb->get_var("SELECT AVG(finish_position) FROM {$this->players_table} WHERE finish_position > 0");
        return floatval($avg ?: 0);
    }

    /**
     * Get total unique players (alias for get_unique_players for consistency)
     */
    private function get_total_unique_players() {
        return $this->get_unique_players();
    }

    /**
     * Get player leaderboard data for dashboard
     */
    public function get_player_leaderboard($limit = 10) {
        global $wpdb;

        $leaderboard = $wpdb->get_results($wpdb->prepare(
            "SELECT
                tp.player_id,
                COUNT(*) as tournaments_played,
                SUM(tp.winnings) as total_winnings,
                SUM(tp.points) as total_points,
                MIN(tp.finish_position) as best_finish,
                AVG(tp.finish_position) as avg_finish,
                SUM(tp.buyins) as total_buyins,
                MAX(tp.winnings) as highest_payout
             FROM {$this->players_table} tp
             GROUP BY tp.player_id
             ORDER BY total_winnings DESC, total_points DESC
             LIMIT %d",
            $limit
        ));

        // Add player names from WordPress posts
        foreach ($leaderboard as &$player) {
            $player_post = $wpdb->get_row($wpdb->prepare(
                "SELECT p.ID, p.post_title
                 FROM {$wpdb->postmeta} pm
                 LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
                 WHERE pm.meta_key = 'player_uuid' AND pm.meta_value = %s
                 LIMIT 1",
                $player->player_id
            ));

            if ($player_post) {
                $player->player_name = $player_post->post_title;
                $player->player_post_id = $player_post->ID;
            } else {
                $player->player_name = $player->player_id;
                $player->player_post_id = null;
            }
        }

        return $leaderboard;
    }

    /**
     * Get player participation trends
     */
    public function get_player_participation_trends($days = 30) {
        global $wpdb;

        // Get daily participation for last N days
        $trends = $wpdb->get_results($wpdb->prepare(
            "SELECT
                DATE(p.post_date) as date,
                COUNT(DISTINCT tp.player_id) as unique_players,
                COUNT(*) as total_entries,
                SUM(tp.winnings) as total_winnings
             FROM {$this->players_table} tp
             LEFT JOIN {$wpdb->postmeta} pm ON pm.meta_value = tp.tournament_id AND pm.meta_key = 'tournament_uuid'
             LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
             WHERE p.post_date >= %s
             GROUP BY DATE(p.post_date)
             ORDER BY date DESC
             LIMIT %d",
            date('Y-m-d', strtotime("-{$days} days")),
            $days
        ));

        return $trends;
    }

    /**
     * Enhanced Debug function to check complete data pipeline health
     */
    public function debug_statistics() {
        $debug_info = array();

        // Check database tables
        global $wpdb;
        $debug_info['stats_table_exists'] = $wpdb->get_var("SHOW TABLES LIKE '{$this->stats_table}'") ? true : false;
        $debug_info['players_table_exists'] = $wpdb->get_var("SHOW TABLES LIKE '{$this->players_table}'") ? true : false;

        // Check raw data counts
        $debug_info['raw_tournament_count'] = wp_count_posts('tournament')->publish;
        $debug_info['raw_series_count'] = wp_count_posts('tournament_series')->publish;
        $debug_info['raw_player_count'] = wp_count_posts('player')->publish;

        // **CRITICAL**: Check players table data
        $total_players_records = $wpdb->get_var("SELECT COUNT(*) FROM {$this->players_table}");
        $debug_info['players_table_records'] = intval($total_players_records);
        $debug_info['raw_players_in_db'] = $wpdb->get_var("SELECT COUNT(DISTINCT player_id) FROM {$this->players_table}");

        // Check tournament UUIDs and their player data
        $debug_info['tournament_uuid_analysis'] = array();
        $tournaments_with_uuid = 0;
        $tournaments_with_players = 0;

        $tournaments = get_posts(array(
            'post_type' => 'tournament',
            'posts_per_page' => 10,
            'orderby' => 'date',
            'order' => 'DESC'
        ));

        foreach ($tournaments as $tournament) {
            $tournament_uuid = get_post_meta($tournament->ID, 'tournament_uuid', true);
            $tournament_uuid_alt = get_post_meta($tournament->ID, '_tournament_uuid', true);

            if ($tournament_uuid || $tournament_uuid_alt) {
                $tournaments_with_uuid++;
                $uuid_to_check = $tournament_uuid ?: $tournament_uuid_alt;

                // Check if this tournament has players in the data mart
                $player_count = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$this->players_table} WHERE tournament_id = %s",
                    $uuid_to_check
                ));

                if ($player_count > 0) {
                    $tournaments_with_players++;
                }

                $debug_info['tournament_uuid_analysis'][] = array(
                    'tournament_id' => $tournament->ID,
                    'tournament_title' => $tournament->post_title,
                    'uuid_used' => $uuid_to_check,
                    'players_in_data_mart' => intval($player_count),
                    'uuid_field' => $tournament_uuid ? 'tournament_uuid' : '_tournament_uuid'
                );
            }
        }

        $debug_info['tournaments_with_uuid'] = $tournaments_with_uuid;
        $debug_info['tournaments_with_players'] = $tournaments_with_players;

        // Check different possible prize pool field names
        $debug_info['prize_pool_fields'] = array();
        $possible_prize_fields = array('_prize_pool', 'prize_pool', '_tournament_prize_pool', 'tournament_prize_pool');
        foreach ($possible_prize_fields as $field) {
            $count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = %s",
                $field
            ));
            $total = $wpdb->get_var($wpdb->prepare(
                "SELECT SUM(CAST(meta_value AS DECIMAL(10,2))) FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value != ''",
                $field
            ));
            $debug_info['prize_pool_fields'][$field] = array(
                'count' => intval($count),
                'total' => floatval($total ?: 0)
            );
        }

        // Check different possible UUID field names
        $debug_info['uuid_fields'] = array();
        $possible_uuid_fields = array('tournament_uuid', '_tournament_uuid', 'uuid', '_uuid');
        foreach ($possible_uuid_fields as $field) {
            $count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = %s",
                $field
            ));
            $debug_info['uuid_fields'][$field] = intval($count);
        }

        // Check player UUID fields
        $debug_info['player_uuid_fields'] = array();
        $possible_player_uuid_fields = array('player_uuid', '_player_uuid', 'uuid', '_uuid');
        foreach ($possible_player_uuid_fields as $field) {
            $count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = %s",
                $field
            ));
            $debug_info['player_uuid_fields'][$field] = intval($count);
        }

        // Use the best prize pool field
        $best_prize_field = '_prize_pool';
        $best_prize_total = 0;
        foreach ($debug_info['prize_pool_fields'] as $field => $data) {
            if ($data['total'] > $best_prize_total) {
                $best_prize_total = $data['total'];
                $best_prize_field = $field;
            }
        }
        $debug_info['raw_prize_pool'] = $best_prize_total;
        $debug_info['best_prize_field'] = $best_prize_field;

        // Check statistics table
        $debug_info['stats_count'] = $wpdb->get_var("SELECT COUNT(*) FROM {$this->stats_table}");
        $debug_info['last_updated'] = $this->get_last_updated();

        // Get current statistics
        $debug_info['current_stats'] = $this->get_dashboard_statistics();

        // **DIAGNOSTIC SUMMARY**
        $debug_info['diagnostic_summary'] = array(
            'critical_issue' => $debug_info['players_table_records'] == 0,
            'data_pipeline_broken' => $tournaments_with_uuid > 0 && $tournaments_with_players == 0,
            'uuid_field_issue' => !($debug_info['uuid_fields']['tournament_uuid'] > 0 || $debug_info['uuid_fields']['_tournament_uuid'] > 0),
            'player_field_issue' => !($debug_info['player_uuid_fields']['player_uuid'] > 0 || $debug_info['player_uuid_fields']['_player_uuid'] > 0)
        );

        error_log("Poker Statistics Debug: " . print_r($debug_info, true));
        return $debug_info;
    }
}