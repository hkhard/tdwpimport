# Dynamic Version Manager for tc-lib-pdf

## Overview

This system provides automatic detection and downloading of the latest stable version of tc-lib-pdf from the official GitHub repository, eliminating the need for manual version updates.

## Features

### ✅ Dynamic Version Detection
- **GitHub API Integration**: Automatically fetches the latest stable version from GitHub API
- **Fallback Mechanism**: Uses web scraping if API fails, with hardcoded fallback version
- **Version Filtering**: Excludes pre-releases, betas, and alphas automatically
- **Performance Optimized**: Caches version information for 12 hours

### ✅ Smart Caching System
- **WordPress Transients**: Uses built-in WordPress caching for reliability
- **Cache Management**: Automatic cache refresh and manual cache clearing
- **Performance**: Cached requests complete in milliseconds
- **Cache Expiration**: 12-hour cache for latest version, 24-hour for available versions

### ✅ Version Management
- **Version Tracking**: Tracks installed version and latest available version
- **Update Detection**: Automatically notifies when updates are available
- **Version Comparison**: Clear display of current vs latest versions
- **Version History**: Access to recent stable versions for rollback

### ✅ Rollback System
- **Safe Rollbacks**: Switch to any previous stable version
- **Version Validation**: Ensures selected versions are available
- **Compatibility Testing**: Easy switching for compatibility testing
- **One-Click Rollback**: Simple interface for version changes

### ✅ Enhanced Admin Interface
- **Status Dashboard**: Clear overview of library status and versions
- **Update Notifications**: Visual alerts when updates are available
- **Action Forms**: Intuitive forms for all management tasks
- **Help Section**: Comprehensive documentation and troubleshooting

### ✅ Security & Validation
- **Official Repository**: Only downloads from official GitHub repository
- **File Integrity**: Validates download integrity with file size and ZIP signature checks
- **Version Validation**: Ensures version format compliance (x.y.z)
- **Secure Handling**: All file operations use WordPress security best practices

## Implementation Details

### Core Classes

#### `TDWP_Dependency_Manager`
- **Location**: `includes/tournament-manager/class-dependency-manager.php`
- **Purpose**: Core version detection, download, and management functionality
- **Key Methods**:
  - `get_latest_version()` - Fetches latest stable version
  - `get_available_versions()` - Lists recent stable versions
  - `check_for_updates()` - Compares installed vs latest versions
  - `rollback_to_version()` - Switches to specific version
  - `download_tcpdf()` - Downloads and installs library

#### `TDWP_Dependency_Manager_Page`
- **Location**: `admin/class-dependency-manager-page.php`
- **Purpose**: WordPress admin interface for dependency management
- **Features**: Status display, action forms, help documentation

### API Endpoints Used

1. **GitHub Tags API**: `https://api.github.com/repos/tecnickcom/tc-lib-pdf/tags`
   - Primary source for version information
   - Returns tags in reverse chronological order
   - Includes commit metadata for each tag

2. **GitHub Web Scraping**: `https://github.com/tecnickcom/tc-lib-pdf/tags`
   - Fallback method if API fails
   - Parses HTML to extract version information
   - Validates version format before returning

### Caching Strategy

```php
// Latest version cache (12 hours)
$cache_key = 'tdwp_tc_lib_pdf_latest_version';
set_transient( $cache_key, $version, 12 * HOUR_IN_SECONDS );

// Available versions cache (24 hours)
$cache_key = 'tdwp_tc_lib_pdf_available_versions';
set_transient( $cache_key, $versions, DAY_IN_SECONDS );
```

### Version Filtering Logic

```php
// Skip pre-releases
if ( preg_match( '/(beta|alpha|rc|dev|pre)/i', $version ) ) {
    continue;
}

// Validate version format
if ( ! preg_match( '/^\d+\.\d+\.\d+$/', $version ) ) {
    continue;
}
```

## Usage

### Getting Latest Version

```php
$dependency_manager = TDWP_Dependency_Manager::get_instance();
$latest_version = $dependency_manager->get_latest_version();
```

### Checking for Updates

```php
$update_info = $dependency_manager->check_for_updates();
if ( $update_info['update_available'] ) {
    // Update is available
    echo "Update available: " . $update_info['latest_version'];
}
```

### Rolling Back to Specific Version

```php
$result = $dependency_manager->rollback_to_version('8.1.0');
if ( is_wp_error( $result ) ) {
    echo "Error: " . $result->get_error_message();
} else {
    echo "Successfully rolled back to version 8.1.0";
}
```

### Getting Available Versions

```php
$versions = $dependency_manager->get_available_versions();
foreach ( $versions as $version ) {
    echo "Available version: " . $version;
}
```

## File Structure

```
wordpress-plugin/poker-tournament-import/
├── includes/tournament-manager/
│   └── class-dependency-manager.php          # Core functionality
├── admin/
│   ├── class-dependency-manager-page.php     # Admin interface
│   └── assets/css/
│       └── dependency-manager.css            # Admin styling
├── test-version-detection.php                # Test script
└── DYNAMIC_VERSION_MANAGER.md               # This documentation
```

## Security Considerations

1. **Official Repository Only**: All downloads come from the official GitHub repository
2. **File Validation**: Downloads are validated for file size and ZIP format
3. **Version Filtering**: Only stable releases are considered (no pre-releases)
4. **WordPress Security**: All file operations use WordPress Filesystem API
5. **Input Sanitization**: All user inputs are properly sanitized

## Performance

- **Cached Requests**: < 1ms for cached version requests
- **API Requests**: ~200ms for GitHub API calls (with 15s timeout)
- **Download Speed**: Depends on network and file size (~9MB typical)
- **Memory Usage**: Minimal overhead with efficient caching

## Troubleshooting

### Common Issues

1. **API Rate Limiting**: GitHub API may rate limit requests
   - Solution: System includes fallback to web scraping
   - Cache duration prevents excessive requests

2. **Network Connectivity**: Server may block external requests
   - Solution: Manual upload option available
   - Detailed error messages provided

3. **File Permissions**: Upload directory may not be writable
   - Solution: Check directory permissions (755 recommended)
   - Error messages guide administrators

4. **Version Conflicts**: New version may be incompatible
   - Solution: Rollback feature allows easy version switching
   - Version history maintained for safe rollbacks

### Debug Mode

Enable WordPress debug mode to see detailed logs:

```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
```

Error logs will show version detection, download progress, and any issues encountered.

## Future Enhancements

1. **Background Updates**: Automatic background checking and optional updates
2. **Version Notifications**: Email notifications when updates are available
3. **Compatibility Testing**: Automated testing of new versions before deployment
4. **Multiple Libraries**: Support for additional PDF libraries
5. **API Authentication**: GitHub token for higher rate limits

## Testing

Use the included test script to verify functionality:

```bash
php -f test-version-detection.php
```

The script tests:
- Version detection from API and cache
- Update checking
- Available versions listing
- Dependency status
- Cache performance
- Fallback mechanisms

## Conclusion

This dynamic version management system provides a robust, secure, and user-friendly way to keep tc-lib-pdf up to date automatically while maintaining flexibility for manual control and rollback capabilities.