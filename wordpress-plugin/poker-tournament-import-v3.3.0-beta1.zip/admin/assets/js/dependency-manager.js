/**
 * Dependency Manager Minimal JavaScript
 *
 * Minimal JavaScript for form validation and basic UX enhancements
 * No AJAX - uses WordPress native form submissions
 *
 * @package Poker_Tournament_Import
 * @subpackage Admin
 * @since 3.3.0
 */

jQuery(document).ready(function($) {
    'use strict';

    // File upload validation
    $('input[type="file"][name="library_file"]').on('change', function() {
        var file = this.files[0];
        var $submitButton = $(this).closest('form').find('button[type="submit"]');

        if (!file) {
            return;
        }

        // Validate file type
        if (!file.name.toLowerCase().endsWith('.zip')) {
            alert('Please select a ZIP file.');
            this.value = '';
            $submitButton.prop('disabled', false);
            return;
        }

        // Validate file size (20MB max)
        var maxSize = 20 * 1024 * 1024;
        if (file.size > maxSize) {
            alert('File is too large. Maximum size is 20MB.');
            this.value = '';
            $submitButton.prop('disabled', false);
            return;
        }

        // Update button text to show selected file
        $submitButton.find('.dashicons').removeClass('dashicons-upload').addClass('dashicons-yes-alt');
        $submitButton.contents().last().replaceWith('Selected: ' + file.name);
    });

    // Remove confirmation dialogs - let browser's default confirm() handle it
    // This is already handled by the onsubmit attribute in the HTML

    console.log('Dependency Manager: Minimal JavaScript loaded');
});