<?php
/**
 * Dependency Manager Admin Page
 *
 * Simple form-based interface for managing PDF library dependencies
 * No complex JavaScript - uses WordPress native forms and admin notices
 *
 * @package Poker_Tournament_Import
 * @subpackage Admin
 * @since 3.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class TDWP_Dependency_Manager_Page {

	/**
	 * Instance of this class
	 *
	 * @var TDWP_Dependency_Manager_Page
	 */
	private static $instance = null;

	/**
	 * Get singleton instance
	 *
	 * @since 3.3.0
	 * @return TDWP_Dependency_Manager_Page
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 *
	 * @since 3.3.0
	 */
	private function __construct() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_init', array( $this, 'handle_form_actions' ) );
		add_action( 'admin_notices', array( $this, 'show_admin_notices' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
	}

	/**
	 * Add admin menu page
	 *
	 * @since 3.3.0
	 */
	public function add_admin_menu() {
		add_submenu_page(
			'poker-tournament-import',
			__( 'Dependencies', 'poker-tournament-import' ),
			__( 'Dependencies', 'poker-tournament-import' ),
			'manage_options',
			'tdwp-dependency-manager',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Enqueue admin scripts and styles
	 *
	 * @since 3.3.0
	 * @param string $hook Current admin page hook
	 */
	public function enqueue_admin_scripts( $hook ) {
		if ( 'poker-tournament-import_page_tdwp-dependency-manager' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'tdwp-dependency-manager',
			POKER_TOURNAMENT_IMPORT_PLUGIN_URL . 'admin/assets/css/dependency-manager.css',
			array(),
			POKER_TOURNAMENT_IMPORT_VERSION
		);

		// Minimal JavaScript for form validation only
		wp_enqueue_script(
			'tdwp-dependency-manager',
			POKER_TOURNAMENT_IMPORT_PLUGIN_URL . 'admin/assets/js/dependency-manager.js',
			array( 'jquery' ),
			POKER_TOURNAMENT_IMPORT_VERSION,
			true
		);
	}

	/**
	 * Render the admin page
	 *
	 * @since 3.3.0
	 */
	public function render_page() {
		$dependency_manager = TDWP_Dependency_Manager::get_instance();
		$status = $dependency_manager->get_dependency_status();
		?>
		<div class="wrap tdwp-dependency-manager">
			<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

			<?php $this->render_status_card( $status ); ?>
			<?php $this->render_action_forms(); ?>
			<?php $this->render_system_info(); ?>
			<?php $this->render_help_section(); ?>
		</div>
		<?php
	}

	/**
	 * Render status card
	 *
	 * @since 3.3.0
	 * @param array $status Current dependency status
	 */
	private function render_status_card( $status ) {
		$dependency_manager = TDWP_Dependency_Manager::get_instance();
		$update_info = $dependency_manager->check_for_updates();

		$status_class = $status['tcpdf_available'] ? 'status-available' : 'status-missing';
		$status_icon = $status['tcpdf_available'] ? 'dashicons-yes' : 'dashicons-no';
		$status_text = $status['tcpdf_available'] ? 'Available' : 'Not Available';

		$last_check = $status['last_check'] ?
			new DateTime( '@' . $status['last_check'] ) :
			new DateTime( '@0' );
		$last_check_display = $last_check > new DateTime( '@0' ) ?
			$last_check->format( 'Y-m-d H:i:s' ) :
			'Never';
		?>
		<div class="tdwp-dependency-overview">
			<div class="tdwp-dependency-card">
				<h3>
					<span class="dashicons dashicons-media-text"></span>
					<?php _e( 'PDF Export Libraries Status', 'poker-tournament-import' ); ?>
				</h3>
				<div class="dependency-status">
					<div class="<?php echo esc_attr( $status_class ); ?>">
						<span class="dashicons <?php echo esc_attr( $status_icon ); ?>"></span>
						<span><?php echo esc_html( $status_text ); ?></span>
						<?php if ( $status['tcpdf_available'] && $update_info['update_available'] ) : ?>
							<span class="update-available">
								<span class="dashicons dashicons-update"></span>
								<?php _e( 'Update Available', 'poker-tournament-import' ); ?>
							</span>
						<?php endif; ?>
					</div>
				</div>
				<div class="dependency-details">
					<p><strong><?php _e( 'Installed Version:', 'poker-tournament-import' ); ?></strong> <?php echo esc_html( $status['installed_version'] ); ?></p>
					<p><strong><?php _e( 'Latest Version:', 'poker-tournament-import' ); ?></strong> <?php echo esc_html( $status['latest_version'] ); ?></p>
					<p><strong><?php _e( 'Last Check:', 'poker-tournament-import' ); ?></strong> <?php echo esc_html( $last_check_display ); ?></p>
					<p><strong><?php _e( 'Library Path:', 'poker-tournament-import' ); ?></strong> <?php echo esc_html( $status['tcpdf_path'] ); ?></p>
					<?php if ( $update_info['update_available'] ) : ?>
						<p class="update-notice">
							<span class="dashicons dashicons-warning"></span>
							<?php
							printf(
								__( 'A newer version (%s) is available. Consider updating to get the latest features and security fixes.', 'poker-tournament-import' ),
								esc_html( $update_info['latest_version'] )
							);
							?>
						</p>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render action forms
	 *
	 * @since 3.3.0
	 */
	private function render_action_forms() {
		$dependency_manager = TDWP_Dependency_Manager::get_instance();
		$status = $dependency_manager->get_dependency_status();
		$update_info = $dependency_manager->check_for_updates();
		$available_versions = $dependency_manager->get_available_versions();
		?>
		<div class="tdwp-dependency-actions">
			<h2><?php _e( 'Library Management', 'poker-tournament-import' ); ?></h2>

			<?php if ( ! $status['tcpdf_available'] ) : ?>
				<!-- Download Form -->
				<div class="tdwp-action-section">
					<h3><?php _e( 'Download Latest Version', 'poker-tournament-import' ); ?></h3>
					<p><?php _e( 'Automatically download the latest stable PDF library from the official repository.', 'poker-tournament-import' ); ?></p>

					<form method="post" action="">
						<?php wp_nonce_field( 'tdwp_download_library' ); ?>
						<input type="hidden" name="action" value="download_library">
						<button type="submit" class="button button-primary">
							<span class="dashicons dashicons-download"></span>
							<?php printf( __( 'Download tc-lib-pdf %s', 'poker-tournament-import' ), esc_html( $status['latest_version'] ) ); ?>
						</button>
					</form>
				</div>

				<!-- Upload Form -->
				<div class="tdwp-action-section">
					<h3><?php _e( 'Manual Upload', 'poker-tournament-import' ); ?></h3>
					<p><?php _e( 'For servers without internet access. Upload library ZIP file manually.', 'poker-tournament-import' ); ?></p>

					<form method="post" enctype="multipart/form-data" action="">
						<?php wp_nonce_field( 'tdwp_upload_library' ); ?>
						<input type="hidden" name="action" value="upload_library">
						<input type="file" name="library_file" accept=".zip" required>
						<button type="submit" class="button button-secondary">
							<span class="dashicons dashicons-upload"></span>
							<?php _e( 'Upload Library File', 'poker-tournament-import' ); ?>
						</button>
					</form>
				</div>
			<?php else : ?>
				<?php if ( $update_info['update_available'] ) : ?>
					<!-- Update Form -->
					<div class="tdwp-action-section update-section">
						<h3><?php _e( 'Update Available', 'poker-tournament-import' ); ?></h3>
						<p>
							<?php
							printf(
								__( 'Update from %s to %s to get the latest features and security fixes.', 'poker-tournament-import' ),
								'<strong>' . esc_html( $update_info['installed_version'] ) . '</strong>',
								'<strong>' . esc_html( $update_info['latest_version'] ) . '</strong>'
							);
							?>
						</p>

						<form method="post" action="" onsubmit="return confirm('<?php esc_attr_e( 'This will update the PDF library to the latest version. The process may take a few moments. Continue?', 'poker-tournament-import' ); ?>')">
							<?php wp_nonce_field( 'tdwp_update_library' ); ?>
							<input type="hidden" name="action" value="update_library">
							<button type="submit" class="button button-primary">
								<span class="dashicons dashicons-update-alt"></span>
								<?php printf( __( 'Update to %s', 'poker-tournament-import' ), esc_html( $update_info['latest_version'] ) ); ?>
							</button>
						</form>
					</div>
				<?php endif; ?>

				<!-- Reinstall Form -->
				<div class="tdwp-action-section">
					<h3><?php _e( 'Reinstall Current Version', 'poker-tournament-import' ); ?></h3>
					<p><?php _e( 'Reinstall the current version to fix potential corruption issues.', 'poker-tournament-import' ); ?></p>

					<form method="post" action="">
						<?php wp_nonce_field( 'tdwp_reinstall_library' ); ?>
						<input type="hidden" name="action" value="reinstall_library">
						<button type="submit" class="button button-secondary">
							<span class="dashicons dashicons-update"></span>
							<?php _e( 'Reinstall Libraries', 'poker-tournament-import' ); ?>
						</button>
					</form>
				</div>

				<!-- Version Management -->
				<div class="tdwp-action-section">
					<h3><?php _e( 'Version Management', 'poker-tournament-import' ); ?></h3>
					<p><?php _e( 'Switch to a different version of the library for compatibility testing.', 'poker-tournament-import' ); ?></p>

					<form method="post" action="" onsubmit="return confirm('<?php esc_attr_e( 'This will replace your current library with the selected version. Continue?', 'poker-tournament-import' ); ?>')">
						<?php wp_nonce_field( 'tdwp_rollback_library' ); ?>
						<input type="hidden" name="action" value="rollback_library">
						<label for="rollback_version"><?php _e( 'Select Version:', 'poker-tournament-import' ); ?></label>
						<select name="rollback_version" id="rollback_version" required>
							<option value=""><?php _e( 'Choose a version...', 'poker-tournament-import' ); ?></option>
							<?php foreach ( $available_versions as $version ) : ?>
								<option value="<?php echo esc_attr( $version ); ?>" <?php selected( $version, $status['installed_version'] ); ?>>
									<?php echo esc_html( $version ); ?>
									<?php if ( $version === $status['installed_version'] ) : ?>
										<?php _e( '(Current)', 'poker-tournament-import' ); ?>
									<?php endif; ?>
									<?php if ( $version === $status['latest_version'] ) : ?>
										<?php _e( '(Latest)', 'poker-tournament-import' ); ?>
									<?php endif; ?>
								</option>
							<?php endforeach; ?>
						</select>
						<button type="submit" class="button button-secondary">
							<span class="dashicons dashicons-backup"></span>
							<?php _e( 'Switch Version', 'poker-tournament-import' ); ?>
						</button>
					</form>
				</div>

				<!-- Refresh Versions -->
				<div class="tdwp-action-section">
					<h3><?php _e( 'Version Information', 'poker-tournament-import' ); ?></h3>
					<p><?php _e( 'Check for new versions and refresh the version cache.', 'poker-tournament-import' ); ?></p>

					<form method="post" action="">
						<?php wp_nonce_field( 'tdwp_refresh_versions' ); ?>
						<input type="hidden" name="action" value="refresh_versions">
						<button type="submit" class="button button-secondary">
							<span class="dashicons dashicons-refresh"></span>
							<?php _e( 'Check for Updates', 'poker-tournament-import' ); ?>
						</button>
					</form>
				</div>

				<!-- Remove Form -->
				<div class="tdwp-action-section">
					<h3><?php _e( 'Remove Libraries', 'poker-tournament-import' ); ?></h3>
					<p><?php _e( 'Remove installed libraries to re-download or upload a different version.', 'poker-tournament-import' ); ?></p>

					<form method="post" action="" onsubmit="return confirm('<?php esc_attr_e( 'Are you sure you want to remove the PDF libraries? This will disable PDF export functionality until they are re-downloaded.', 'poker-tournament-import' ); ?>')">
						<?php wp_nonce_field( 'tdwp_remove_library' ); ?>
						<input type="hidden" name="action" value="remove_library">
						<button type="submit" class="button button-secondary">
							<span class="dashicons dashicons-trash"></span>
							<?php _e( 'Remove Libraries', 'poker-tournament-import' ); ?>
						</button>
					</form>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render system information
	 *
	 * @since 3.3.0
	 */
	private function render_system_info() {
		$upload_dir = wp_upload_dir();
		$writable = is_writable( $upload_dir['basedir'] );
		?>
		<div class="tdwp-system-info">
			<h2><?php _e( 'System Information', 'poker-tournament-import' ); ?></h2>
			<table class="widefat">
				<thead>
					<tr>
						<th><?php _e( 'Setting', 'poker-tournament-import' ); ?></th>
						<th><?php _e( 'Value', 'poker-tournament-import' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><?php _e( 'PHP Version', 'poker-tournament-import' ); ?></td>
						<td><?php echo esc_html( PHP_VERSION ); ?></td>
					</tr>
					<tr>
						<td><?php _e( 'Memory Limit', 'poker-tournament-import' ); ?></td>
						<td><?php echo esc_html( ini_get( 'memory_limit' ) ); ?></td>
					</tr>
					<tr>
						<td><?php _e( 'Upload Max Filesize', 'poker-tournament-import' ); ?></td>
						<td><?php echo esc_html( ini_get( 'upload_max_filesize' ) ); ?></td>
					</tr>
					<tr>
						<td><?php _e( 'Uploads Directory', 'poker-tournament-import' ); ?></td>
						<td><?php echo esc_html( $upload_dir['basedir'] ); ?></td>
					</tr>
					<tr>
						<td><?php _e( 'Uploads Writable', 'poker-tournament-import' ); ?></td>
						<td>
							<?php
							echo $writable
								? '<span class="status-success">' . __( 'Yes', 'poker-tournament-import' ) . '</span>'
								: '<span class="status-error">' . __( 'No', 'poker-tournament-import' ) . '</span>';
							?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * Render help section
	 *
	 * @since 3.3.0
	 */
	private function render_help_section() {
		?>
		<div class="tdwp-help-section">
			<h2><?php _e( 'Help & Troubleshooting', 'poker-tournament-import' ); ?></h2>
			<div class="tdwp-help-cards">
				<div class="help-card">
					<h3><span class="dashicons dashicons-download"></span> <?php _e( 'Dynamic Version Detection', 'poker-tournament-import' ); ?></h3>
					<p><?php _e( 'The system automatically detects and downloads the latest stable version of tc-lib-pdf from the official GitHub repository. Version information is cached for 12 hours to improve performance.', 'poker-tournament-import' ); ?></p>
				</div>
				<div class="help-card">
					<h3><span class="dashicons dashicons-backup"></span> <?php _e( 'Version Management', 'poker-tournament-import' ); ?></h3>
					<p><?php _e( 'Switch between different versions of tc-lib-pdf for compatibility testing. The rollback feature allows you to safely return to previous versions if needed.', 'poker-tournament-import' ); ?></p>
					<p><a href="https://github.com/tecnickcom/tc-lib-pdf/releases" target="_blank"><?php _e( 'View Available Versions', 'poker-tournament-import' ); ?></a></p>
				</div>
				<div class="help-card">
					<h3><span class="dashicons dashicons-update"></span> <?php _e( 'Automatic Updates', 'poker-tournament-import' ); ?></h3>
					<p><?php _e( 'When a new version is available, you\'ll see an update notice. The system will guide you through the update process with confirmation prompts.', 'poker-tournament-import' ); ?></p>
				</div>
				<div class="help-card">
					<h3><span class="dashicons dashicons-download"></span> <?php _e( 'Download Issues', 'poker-tournament-import' ); ?></h3>
					<p><?php _e( 'If automatic download fails, your server may have network restrictions. Try manual upload or check server connectivity to GitHub.', 'poker-tournament-import' ); ?></p>
				</div>
				<div class="help-card">
					<h3><span class="dashicons dashicons-upload"></span> <?php _e( 'Manual Upload', 'poker-tournament-import' ); ?></h3>
					<p><?php _e( 'For servers without internet access, download tc-lib-pdf from the official repository and upload the ZIP file here.', 'poker-tournament-import' ); ?></p>
					<p><a href="https://github.com/tecnickcom/tc-lib-pdf/releases" target="_blank"><?php _e( 'Download tc-lib-pdf', 'poker-tournament-import' ); ?></a></p>
				</div>
				<div class="help-card">
					<h3><span class="dashicons dashicons-warning"></span> <?php _e( 'Troubleshooting', 'poker-tournament-import' ); ?></h3>
					<p><?php _e( 'Ensure the uploads directory is writable (755 permissions). If issues persist, try removing and reinstalling the library.', 'poker-tournament-import' ); ?></p>
				</div>
				<div class="help-card">
					<h3><span class="dashicons dashicons-info"></span> <?php _e( 'Security', 'poker-tournament-import' ); ?></h3>
					<p><?php _e( 'The system validates file integrity and only downloads from the official GitHub repository. All versions are filtered to exclude pre-releases and betas.', 'poker-tournament-import' ); ?></p>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Handle form submissions
	 *
	 * @since 3.3.0
	 */
	public function handle_form_actions() {
		if ( ! isset( $_POST['action'] ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$dependency_manager = TDWP_Dependency_Manager::get_instance();
		$message = '';
		$type = 'success';

		switch ( $_POST['action'] ) {
			case 'download_library':
				check_admin_referer( 'tdwp_download_library' );
				$result = $dependency_manager->download_tcpdf();
				if ( is_wp_error( $result ) ) {
					$message = $result->get_error_message();
					$type = 'error';
				} else {
					$message = $result['message'];
				}
				break;

			case 'upload_library':
				check_admin_referer( 'tdwp_upload_library' );
				if ( ! isset( $_FILES['library_file'] ) ) {
					$message = __( 'No file uploaded.', 'poker-tournament-import' );
					$type = 'error';
				} else {
					$file = $_FILES['library_file'];

					// Validate file type
					if ( strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) ) !== 'zip' ) {
						$message = __( 'Please upload a ZIP file.', 'poker-tournament-import' );
						$type = 'error';
					} elseif ( $file['size'] > 20 * 1024 * 1024 ) {
						$message = __( 'File size too large. Maximum size is 20MB.', 'poker-tournament-import' );
						$type = 'error';
					} else {
						$upload_dir = wp_upload_dir();
						$lib_dir = $upload_dir['basedir'] . '/tdwp-libs';
						$temp_file = $lib_dir . '/tcpdf-upload.zip';

						wp_mkdir_p( $lib_dir );

						if ( move_uploaded_file( $file['tmp_name'], $temp_file ) ) {
							$result = $dependency_manager->extract_tcpdf_from_archive( $temp_file );
							unlink( $temp_file );

							if ( is_wp_error( $result ) ) {
								$message = $result->get_error_message();
								$type = 'error';
							} else {
								$message = __( 'Library uploaded and installed successfully!', 'poker-tournament-import' );
							}
						} else {
							$message = __( 'Failed to move uploaded file.', 'poker-tournament-import' );
							$type = 'error';
						}
					}
				}
				break;

			case 'reinstall_library':
				check_admin_referer( 'tdwp_reinstall_library' );
				$result = $dependency_manager->download_tcpdf( true );
				if ( is_wp_error( $result ) ) {
					$message = $result->get_error_message();
					$type = 'error';
				} else {
					$message = $result['message'];
				}
				break;

			case 'update_library':
				check_admin_referer( 'tdwp_update_library' );
				$result = $dependency_manager->download_tcpdf( true );
				if ( is_wp_error( $result ) ) {
					$message = $result->get_error_message();
					$type = 'error';
				} else {
					$message = $result['message'];
				}
				break;

			case 'rollback_library':
				check_admin_referer( 'tdwp_rollback_library' );
				if ( ! isset( $_POST['rollback_version'] ) || empty( $_POST['rollback_version'] ) ) {
					$message = __( 'Please select a version to rollback to.', 'poker-tournament-import' );
					$type = 'error';
				} else {
					$version = sanitize_text_field( $_POST['rollback_version'] );
					$result = $dependency_manager->rollback_to_version( $version );
					if ( is_wp_error( $result ) ) {
						$message = $result->get_error_message();
						$type = 'error';
					} else {
						$message = $result['message'];
					}
				}
				break;

			case 'refresh_versions':
				check_admin_referer( 'tdwp_refresh_versions' );
				$dependency_manager->clear_version_cache();
				$latest_version = $dependency_manager->get_latest_version( true );
				$message = sprintf(
					__( 'Version information refreshed. Latest version is %s.', 'poker-tournament-import' ),
					$latest_version
				);
				break;

			case 'remove_library':
				check_admin_referer( 'tdwp_remove_library' );
				$upload_dir = wp_upload_dir();
				$tcpdf_dir = $upload_dir['basedir'] . '/tdwp-libs/tcpdf';

				if ( file_exists( $tcpdf_dir ) ) {
					WP_Filesystem();
					$GLOBALS['wp_filesystem']->delete( $tcpdf_dir, true );
				}

				delete_transient( 'tdwp_tcpdf_installed' );
				delete_option( 'tdwp_tc_lib_pdf_installed_version' );
				delete_option( 'tdwp_tc_lib_pdf_install_date' );
				$message = __( 'Libraries removed successfully.', 'poker-tournament-import' );
				break;
		}

		if ( $message ) {
			set_transient( 'tdwp_dependency_message', $message, 60 );
			set_transient( 'tdwp_dependency_message_type', $type, 60 );
		}

		wp_safe_redirect( remove_query_arg( 'settings-updated', wp_get_referer() ) );
		exit;
	}

	/**
	 * Show admin notices
	 *
	 * @since 3.3.0
	 */
	public function show_admin_notices() {
		if ( $message = get_transient( 'tdwp_dependency_message' ) ) {
			$type = get_transient( 'tdwp_dependency_message_type', 'success' );
			$class = $type === 'success' ? 'notice-success' : 'notice-error';

			printf(
				'<div class="notice %s is-dismissible"><p>%s</p></div>',
				esc_attr( $class ),
				esc_html( $message )
			);

			delete_transient( 'tdwp_dependency_message' );
			delete_transient( 'tdwp_dependency_message_type' );
		}
	}
}