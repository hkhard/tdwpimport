<?php
/**
 * Players Tab Content - Tournament Roster
 *
 * @package Poker_Tournament_Import
 * @since 3.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get registered players.
$players = TDWP_Tournament_Player_Manager::get_tournament_players( $tournament_id );
$player_count = count( $players );

// Get tournament financial config.
$buy_in      = get_post_meta( $tournament_id, '_buy_in', true );
$rebuy_cost  = get_post_meta( $tournament_id, '_rebuy_cost', true );
$addon_cost  = get_post_meta( $tournament_id, '_addon_cost', true );

// Get financial policy for conditional UI.
$allow_reentry       = (int) get_post_meta( $tournament_id, '_allow_reentry', true );
$reentry_until_level = (int) get_post_meta( $tournament_id, '_reentry_until_level', true );
$bounty_type         = get_post_meta( $tournament_id, '_bounty_type', true );
$show_bounty_column  = ( 'none' !== $bounty_type && ! empty( $bounty_type ) );

// Get current tournament state for level-based checks.
$state         = TDWP_Live_State_Manager::get_state( $tournament_id );
$current_level = $state ? $state->current_level : 1;

// Get all available players for autocomplete.
$all_players = get_posts(
	array(
		'post_type'      => 'player',
		'post_status'    => 'publish',
		'posts_per_page' => -1,
		'orderby'        => 'title',
		'order'          => 'ASC',
	)
);
?>

<div class="players-tab-content">
	<div class="players-header">
		<h2><?php esc_html_e( 'Tournament Roster', 'poker-tournament-import' ); ?></h2>
		<div class="players-actions">
			<button type="button" id="btn-add-player" class="button button-primary">
				<?php esc_html_e( 'Add Player', 'poker-tournament-import' ); ?>
			</button>
			<button type="button" id="btn-process-buyins" class="button button-secondary">
				<?php esc_html_e( 'Process Buy-ins', 'poker-tournament-import' ); ?>
			</button>
			<span class="player-count"><?php echo esc_html( sprintf( __( 'Total Players: %d', 'poker-tournament-import' ), $player_count ) ); ?></span>
		</div>
	</div>

	<!-- Add Player Modal -->
	<div id="add-player-modal" class="tdwp-modal" style="display:none;">
		<div class="tdwp-modal-content">
			<div class="tdwp-modal-header">
				<h3><?php esc_html_e( 'Add Player to Tournament', 'poker-tournament-import' ); ?></h3>
				<span class="tdwp-modal-close">&times;</span>
			</div>
			<div class="tdwp-modal-body">
				<div class="form-row">
					<label for="player-select"><?php esc_html_e( 'Select Player', 'poker-tournament-import' ); ?></label>
					<select id="player-select" class="regular-text">
						<option value=""><?php esc_html_e( 'Choose a player...', 'poker-tournament-import' ); ?></option>
						<?php foreach ( $all_players as $player ) : ?>
							<option value="<?php echo esc_attr( $player->ID ); ?>">
								<?php echo esc_html( $player->post_title ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="form-row">
					<label>
						<input type="checkbox" id="paid-in-full">
						<?php
						/* translators: %s: buy-in amount */
						echo esc_html( sprintf( __( 'Paid in full (%s)', 'poker-tournament-import' ), $buy_in ? '$' . number_format( (float) $buy_in, 2 ) : '$0.00' ) );
						?>
					</label>
					<p class="description"><?php esc_html_e( 'Check if player has paid the buy-in amount', 'poker-tournament-import' ); ?></p>
					<input type="hidden" id="tournament-buy-in" value="<?php echo esc_attr( $buy_in ); ?>">
				</div>
			</div>
			<div class="tdwp-modal-footer">
				<button type="button" id="btn-cancel-add" class="button"><?php esc_html_e( 'Cancel', 'poker-tournament-import' ); ?></button>
				<button type="button" id="btn-confirm-add" class="button button-primary"><?php esc_html_e( 'Add Player', 'poker-tournament-import' ); ?></button>
			</div>
		</div>
	</div>

	<!-- Buy-in Wizard Modal -->
	<div id="buyin-wizard-modal" class="tdwp-modal" style="display:none;">
		<div class="tdwp-modal-content" style="max-width: 800px;">
			<div class="tdwp-modal-header">
				<h3><?php esc_html_e( 'Process Buy-ins', 'poker-tournament-import' ); ?></h3>
				<span class="tdwp-modal-close">&times;</span>
			</div>
			<div class="tdwp-modal-body">
				<p class="description"><?php esc_html_e( 'Mark players as bought in and record rebuys/add-ons. Only registered players are shown.', 'poker-tournament-import' ); ?></p>

				<table class="wp-list-table widefat striped buyin-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Player', 'poker-tournament-import' ); ?></th>
							<th><?php esc_html_e( 'Buy-in', 'poker-tournament-import' ); ?></th>
							<th><?php esc_html_e( 'Rebuys', 'poker-tournament-import' ); ?></th>
							<th><?php esc_html_e( 'Add-ons', 'poker-tournament-import' ); ?></th>
							<th><?php esc_html_e( 'Total', 'poker-tournament-import' ); ?></th>
						</tr>
					</thead>
					<tbody id="buyin-players-list">
						<?php
						$registered_players = TDWP_Tournament_Player_Manager::get_tournament_players( $tournament_id, 'registered' );
						if ( empty( $registered_players ) ) :
							?>
							<tr>
								<td colspan="5"><?php esc_html_e( 'No registered players to process', 'poker-tournament-import' ); ?></td>
							</tr>
						<?php else : ?>
							<?php foreach ( $registered_players as $player_reg ) : ?>
								<?php
								$player_post = get_post( $player_reg->player_id );
								if ( ! $player_post ) {
									continue;
								}
								?>
								<tr class="buyin-player-row" data-player-id="<?php echo esc_attr( $player_reg->player_id ); ?>">
									<td><strong><?php echo esc_html( $player_post->post_title ); ?></strong></td>
									<td>
										<label>
											<input type="checkbox" class="buyin-checkbox" checked>
											$<?php echo esc_html( number_format( (float) $buy_in, 2 ) ); ?>
										</label>
									</td>
									<td>
										<input type="number" class="rebuys-input small-text" min="0" value="0" step="1">
										× $<?php echo esc_html( number_format( (float) $rebuy_cost, 2 ) ); ?>
									</td>
									<td>
										<input type="number" class="addons-input small-text" min="0" value="0" step="1">
										× $<?php echo esc_html( number_format( (float) $addon_cost, 2 ) ); ?>
									</td>
									<td class="total-amount">$0.00</td>
								</tr>
							<?php endforeach; ?>
						<?php endif; ?>
					</tbody>
				</table>

				<input type="hidden" id="buyin-buy-in" value="<?php echo esc_attr( $buy_in ); ?>">
				<input type="hidden" id="buyin-rebuy-cost" value="<?php echo esc_attr( $rebuy_cost ); ?>">
				<input type="hidden" id="buyin-addon-cost" value="<?php echo esc_attr( $addon_cost ); ?>">
			</div>
			<div class="tdwp-modal-footer">
				<button type="button" id="btn-cancel-buyin" class="button"><?php esc_html_e( 'Cancel', 'poker-tournament-import' ); ?></button>
				<button type="button" id="btn-confirm-buyin" class="button button-primary"><?php esc_html_e( 'Process Buy-ins', 'poker-tournament-import' ); ?></button>
			</div>
		</div>
	</div>

	<!-- Bust-out Modal -->
	<div id="bustout-modal" class="tdwp-modal" style="display:none;">
		<div class="tdwp-modal-content">
			<div class="tdwp-modal-header">
				<h3><?php esc_html_e( 'Bust Out Player', 'poker-tournament-import' ); ?></h3>
				<span class="tdwp-modal-close">&times;</span>
			</div>
			<div class="tdwp-modal-body">
				<p class="bustout-player-name" style="font-size: 16px; margin-bottom: 15px;">
					<strong><?php esc_html_e( 'Eliminating:', 'poker-tournament-import' ); ?></strong> <span id="bustout-player-name"></span>
				</p>
				<div class="form-row">
					<label for="eliminator-select"><?php esc_html_e( 'Eliminated by (optional)', 'poker-tournament-import' ); ?></label>
					<select id="eliminator-select" class="regular-text">
						<option value=""><?php esc_html_e( 'Select eliminator...', 'poker-tournament-import' ); ?></option>
					</select>
					<p class="description"><?php esc_html_e( 'Select the player who eliminated this player. Leave blank if unknown.', 'poker-tournament-import' ); ?></p>
				</div>
				<?php if ( $show_bounty_column ) : ?>
					<div class="form-row bounty-preview" style="display:none; margin-top: 15px; padding: 10px; background: #f0f0f1; border-left: 4px solid #2271b1;">
						<p style="margin: 0;">
							<strong><?php esc_html_e( 'Bounty:', 'poker-tournament-import' ); ?></strong>
							<span id="bounty-earned-preview">$0.00</span>
						</p>
					</div>
				<?php endif; ?>
				<input type="hidden" id="bustout-registration-id">
				<input type="hidden" id="bustout-player-id">
				<input type="hidden" id="bustout-entry-number">
			</div>
			<div class="tdwp-modal-footer">
				<button type="button" id="btn-cancel-bustout" class="button"><?php esc_html_e( 'Cancel', 'poker-tournament-import' ); ?></button>
				<button type="button" id="btn-confirm-bustout" class="button button-primary"><?php esc_html_e( 'Confirm Bust Out', 'poker-tournament-import' ); ?></button>
			</div>
		</div>
	</div>

	<!-- Update Chips Modal -->
	<div id="update-chips-modal" class="tdwp-modal" style="display:none;">
		<div class="tdwp-modal-content">
			<div class="tdwp-modal-header">
				<h3><?php esc_html_e( 'Update Chip Count', 'poker-tournament-import' ); ?></h3>
				<span class="tdwp-modal-close">&times;</span>
			</div>
			<div class="tdwp-modal-body">
				<p class="chip-player-name" style="font-size: 16px; margin-bottom: 15px;">
					<strong><?php esc_html_e( 'Player:', 'poker-tournament-import' ); ?></strong> <span id="chip-player-name"></span>
				</p>
				<div class="form-row">
					<label for="new-chip-count"><?php esc_html_e( 'New Chip Count', 'poker-tournament-import' ); ?></label>
					<input type="number" id="new-chip-count" class="regular-text" min="0" step="100" value="0">
					<p class="description"><?php esc_html_e( 'Enter the updated chip count for this player.', 'poker-tournament-import' ); ?></p>
				</div>
				<input type="hidden" id="chip-registration-id">
				<input type="hidden" id="chip-player-id">
				<input type="hidden" id="chip-entry-number">
			</div>
			<div class="tdwp-modal-footer">
				<button type="button" id="btn-cancel-chips" class="button"><?php esc_html_e( 'Cancel', 'poker-tournament-import' ); ?></button>
				<button type="button" id="btn-confirm-chips" class="button button-primary"><?php esc_html_e( 'Update Chips', 'poker-tournament-import' ); ?></button>
			</div>
		</div>
	</div>

	<!-- Players Table -->
	<?php if ( $player_count > 0 ) : ?>
		<table class="wp-list-table widefat fixed striped players-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Player', 'poker-tournament-import' ); ?></th>
					<th><?php esc_html_e( 'Entry #', 'poker-tournament-import' ); ?></th>
					<th><?php esc_html_e( 'Status', 'poker-tournament-import' ); ?></th>
					<th><?php esc_html_e( 'Chip Count', 'poker-tournament-import' ); ?></th>
					<?php if ( $show_bounty_column ) : ?>
						<th><?php esc_html_e( 'Bounty', 'poker-tournament-import' ); ?></th>
					<?php endif; ?>
					<th><?php esc_html_e( 'Eliminations', 'poker-tournament-import' ); ?></th>
					<th><?php esc_html_e( 'Registered', 'poker-tournament-import' ); ?></th>
					<th><?php esc_html_e( 'Paid', 'poker-tournament-import' ); ?></th>
					<th><?php esc_html_e( 'Rebuys', 'poker-tournament-import' ); ?></th>
					<th><?php esc_html_e( 'Add-ons', 'poker-tournament-import' ); ?></th>
					<th><?php esc_html_e( 'Seat', 'poker-tournament-import' ); ?></th>
					<th><?php esc_html_e( 'Actions', 'poker-tournament-import' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php
				// Group players by player_id to consolidate multi-entries (Beta 22.3)
				$grouped_players = array();
				foreach ( $players as $entry ) {
					$pid = $entry->player_id;

					if ( ! isset( $grouped_players[ $pid ] ) ) {
						$grouped_players[ $pid ] = array(
							'player_post'        => get_post( $pid ),
							'entries'            => array(),
							'total_eliminations' => 0,
							'total_paid'         => 0,
							'total_rebuys'       => 0,
							'total_addons'       => 0,
						);
					}

					$grouped_players[ $pid ]['entries'][]             = $entry;
					$grouped_players[ $pid ]['total_eliminations']   += (int) $entry->eliminations_count;
					$grouped_players[ $pid ]['total_paid']           += (float) $entry->paid_amount;
					$grouped_players[ $pid ]['total_rebuys']         += (int) $entry->rebuys_count;
					$grouped_players[ $pid ]['total_addons']         += (int) $entry->addons_count;
				}

				// Display consolidated rows
				foreach ( $grouped_players as $player_id => $group ) :
					$player_post = $group['player_post'];
					if ( ! $player_post ) {
						continue;
					}

					// Find active entry (or latest if all eliminated)
					$active_entry = null;
					foreach ( $group['entries'] as $e ) {
						if ( in_array( $e->status, array( 'active', 'paid', 'checked_in' ), true ) ) {
							$active_entry = $e;
							break;
						}
					}
					if ( ! $active_entry ) {
						// All eliminated, use latest entry
						$active_entry = end( $group['entries'] );
						reset( $group['entries'] ); // Reset array pointer
					}

					$entry_count = count( $group['entries'] );
					$player_reg  = $active_entry; // Alias for backward compatibility

					// Determine re-entry eligibility
					$can_reentry = false;
					if ( 'eliminated' === $active_entry->status && $allow_reentry && null === $active_entry->finish_position ) {
						if ( 0 === $reentry_until_level || $current_level <= $reentry_until_level ) {
							$can_reentry = true;
						}
					}

					// Determine if player is "active" (can be busted out)
					$is_active = in_array( $active_entry->status, array( 'active', 'paid', 'checked_in' ), true );
					?>
					<tr data-player-id="<?php echo esc_attr( $player_reg->player_id ); ?>"
						data-entry-number="<?php echo esc_attr( $player_reg->entry_number ); ?>"
						data-chips="<?php echo esc_attr( $player_reg->chip_count ); ?>"
						data-bounty="<?php echo esc_attr( $player_reg->bounty_amount ); ?>"
						data-status="<?php echo esc_attr( $player_reg->status ); ?>">
						<td>
							<strong><?php echo esc_html( $player_post->post_title ); ?></strong>
							<?php if ( $entry_count > 1 ) : ?>
								<span class="entry-badge" style="color: #999; font-size: 0.9em;">(<?php echo esc_html( $entry_count ); ?>×)</span>
							<?php endif; ?>
						</td>
						<td><?php echo esc_html( $player_reg->entry_number ); ?></td>
						<td>
							<select class="player-status-select" data-player-id="<?php echo esc_attr( $player_reg->player_id ); ?>" data-entry-number="<?php echo esc_attr( $player_reg->entry_number ); ?>">
								<option value="registered" <?php selected( $player_reg->status, 'registered' ); ?>><?php esc_html_e( 'Registered', 'poker-tournament-import' ); ?></option>
								<option value="paid" <?php selected( $player_reg->status, 'paid' ); ?>><?php esc_html_e( 'Paid', 'poker-tournament-import' ); ?></option>
								<option value="checked_in" <?php selected( $player_reg->status, 'checked_in' ); ?>><?php esc_html_e( 'Checked In', 'poker-tournament-import' ); ?></option>
								<option value="active" <?php selected( $player_reg->status, 'active' ); ?>><?php esc_html_e( 'Active', 'poker-tournament-import' ); ?></option>
								<option value="eliminated" <?php selected( $player_reg->status, 'eliminated' ); ?>><?php esc_html_e( 'Eliminated', 'poker-tournament-import' ); ?></option>
							</select>
						</td>
						<td>
							<?php echo esc_html( number_format( (int) $player_reg->chip_count ) ); ?>
						</td>
						<?php if ( $show_bounty_column ) : ?>
							<td>$<?php echo esc_html( number_format( (float) $player_reg->bounty_amount, 2 ) ); ?></td>
						<?php endif; ?>
						<td><?php echo esc_html( $group['total_eliminations'] ); ?></td>
						<td><?php echo esc_html( gmdate( 'Y-m-d H:i', strtotime( $group['entries'][0]->registration_date ) ) ); ?></td>
						<td>$<?php echo esc_html( number_format( (float) $group['total_paid'], 2 ) ); ?></td>
						<td><?php echo esc_html( $group['total_rebuys'] ); ?></td>
						<td><?php echo esc_html( $group['total_addons'] ); ?></td>
						<td><?php echo $player_reg->seat_assignment ? esc_html( $player_reg->seat_assignment ) : '—'; ?></td>
						<td class="actions-cell">
							<?php if ( $is_active ) : ?>
								<button type="button" class="button button-small btn-bust-player"
									data-registration-id="<?php echo esc_attr( $player_reg->id ); ?>"
									data-player-id="<?php echo esc_attr( $player_reg->player_id ); ?>"
									data-entry-number="<?php echo esc_attr( $player_reg->entry_number ); ?>">
									<?php esc_html_e( 'Bust Out', 'poker-tournament-import' ); ?>
								</button>
								<button type="button" class="button button-small btn-update-chips"
									data-registration-id="<?php echo esc_attr( $player_reg->id ); ?>"
									data-player-id="<?php echo esc_attr( $player_reg->player_id ); ?>"
									data-entry-number="<?php echo esc_attr( $player_reg->entry_number ); ?>"
									data-current-chips="<?php echo esc_attr( $player_reg->chip_count ); ?>">
									<?php esc_html_e( 'Chips', 'poker-tournament-import' ); ?>
								</button>
							<?php elseif ( $can_reentry ) : ?>
								<button type="button" class="button button-small button-primary btn-reentry-player"
									data-registration-id="<?php echo esc_attr( $player_reg->id ); ?>"
									data-player-id="<?php echo esc_attr( $player_reg->player_id ); ?>">
									<?php esc_html_e( 'Re-enter', 'poker-tournament-import' ); ?>
								</button>
							<?php endif; ?>
							<?php if ( in_array( $player_reg->status, array( 'registered', 'paid' ), true ) ) : ?>
								<button type="button" class="button button-small btn-remove-player"
									data-registration-id="<?php echo esc_attr( $player_reg->id ); ?>"
									data-player-id="<?php echo esc_attr( $player_reg->player_id ); ?>"
									data-entry-number="<?php echo esc_attr( $player_reg->entry_number ); ?>">
									<?php esc_html_e( 'Remove', 'poker-tournament-import' ); ?>
								</button>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php else : ?>
		<div class="no-players-message">
			<p><?php esc_html_e( 'No players registered yet. Click "Add Player" to start.', 'poker-tournament-import' ); ?></p>
		</div>
	<?php endif; ?>
</div>
