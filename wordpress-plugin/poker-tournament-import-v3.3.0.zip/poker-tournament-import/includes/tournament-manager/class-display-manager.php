<?php
/**
 * TD3 Integration: Display Manager
 *
 * Coordinates display system functionality for Tournament Director 3 integration.
 * Manages templates, layouts, screens, and token rendering for tournament displays.
 *
 * @package Poker_Tournament_Import
 * @subpackage Tournament_Manager
 * @since 3.4.0
 */

// Prevent direct file access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Display Manager Class
 *
 * Handles coordination of all display system components including:
 * - Template management and rendering
 * - Layout configuration and assignment
 * - Screen endpoint management
 * - Token processing and caching
 * - Multi-screen synchronization
 *
 * @since 3.4.0
 */
class TDWP_Display_Manager {

	/**
	 * Singleton instance
	 *
	 * @var TDWP_Display_Manager|null
	 */
	private static $instance = null;

	/**
	 * Template engine instance
	 *
	 * @var TDWP_Template_Engine|null
	 */
	private $template_engine = null;

	/**
	 * Layout builder instance
	 *
	 * @var TDWP_Layout_Builder|null
	 */
	private $layout_builder = null;

	/**
	 * Get singleton instance
	 *
	 * @since 3.4.0
	 * @return TDWP_Display_Manager
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 *
	 * @since 3.4.0
	 */
	private function __construct() {
		// Initialize dependencies when available
		add_action( 'init', array( $this, 'init_dependencies' ) );

		// Register AJAX handlers
		add_action( 'wp_ajax_tdwp_save_display_template', array( $this, 'ajax_save_display_template' ) );
		add_action( 'wp_ajax_tdwp_get_display_templates', array( $this, 'ajax_get_display_templates' ) );
		add_action( 'wp_ajax_tdwp_save_display_layout', array( $this, 'ajax_save_display_layout' ) );
		add_action( 'wp_ajax_tdwp_get_display_screens', array( $this, 'ajax_get_display_screens' ) );

		// Register display endpoint rewrite rules
		add_action( 'init', array( $this, 'register_display_endpoints' ) );
		add_filter( 'query_vars', array( $this, 'add_display_query_vars' ) );
		add_action( 'template_redirect', array( $this, 'handle_display_request' ) );
	}

	/**
	 * Initialize dependencies
	 *
	 * @since 3.4.0
	 */
	public function init_dependencies() {
		// Load template engine if available
		if ( class_exists( 'TDWP_Template_Engine' ) ) {
			$this->template_engine = TDWP_Template_Engine::get_instance();
		}

		// Load layout builder if available
		if ( class_exists( 'TDWP_Layout_Builder' ) ) {
			$this->layout_builder = TDWP_Layout_Builder::get_instance();
		}
	}

	/**
	 * Register display endpoint rewrite rules
	 *
	 * @since 3.4.0
	 */
	public function register_display_endpoints() {
		add_rewrite_rule(
			'^tdwp-display/([^/]+)/?$',
			'index.php?tdwp_display=$matches[1]',
			'top'
		);
	}

	/**
	 * Add display query variables
	 *
	 * @since 3.4.0
	 * @param array $query_vars Existing query variables.
	 * @return array Modified query variables.
	 */
	public function add_display_query_vars( $query_vars ) {
		$query_vars[] = 'tdwp_display';
		return $query_vars;
	}

	/**
	 * Handle display requests
	 *
	 * @since 3.4.0
	 */
	public function handle_display_request() {
		$display_id = get_query_var( 'tdwp_display' );

		if ( ! empty( $display_id ) ) {
			$this->render_display( $display_id );
			exit;
		}
	}

	/**
	 * Render display output
	 *
	 * @since 3.4.0
	 * @param string $display_id Display identifier.
	 */
	public function render_display( $display_id ) {
		global $wpdb;

		// Get screen configuration
		$screen = $wpdb->get_row( $wpdb->prepare(
			"SELECT s.*, t.html_template, t.css_styles, l.grid_config, l.component_positions
			 FROM {$wpdb->prefix}poker_display_screens s
			 LEFT JOIN {$wpdb->prefix}poker_display_templates t ON s.template_id = t.template_id
			 LEFT JOIN {$wpdb->prefix}poker_display_layouts l ON s.layout_id = l.layout_id
			 WHERE s.endpoint_url = %s OR s.screen_name = %s",
			$display_id, $display_id
		) );

		if ( ! $screen ) {
			wp_die( 'Display not found', 'Display Error', 404 );
		}

		// Update last ping
		$wpdb->update(
			$wpdb->prefix . 'poker_display_screens',
			array( 'last_ping' => current_time( 'mysql' ), 'is_online' => 1 ),
			array( 'screen_id' => $screen->screen_id ),
			array( '%s', '%d' ),
			array( '%d' )
		);

		// Render template if template engine is available
		if ( $this->template_engine && $screen->html_template ) {
			$rendered_content = $this->template_engine->render_template(
				$screen->html_template,
				$screen->tournament_id
			);

			// Apply layout if available
			if ( $this->layout_builder && $screen->grid_config ) {
				$rendered_content = $this->layout_builder->apply_layout(
					$rendered_content,
					$screen->grid_config,
					$screen->component_positions
				);
			}

			// Include styles if available
			if ( $screen->css_styles ) {
				echo '<style>' . $screen->css_styles . '</style>';
			}

			echo $rendered_content;
		} else {
			// Fallback display
			echo '<div class="tdwp-display-fallback">';
			echo '<h1>' . esc_html( $screen->screen_name ) . '</h1>';
			echo '<p>Display system is initializing...</p>';
			echo '</div>';
		}
	}

	/**
	 * Save display template via AJAX
	 *
	 * @since 3.4.0
	 */
	public function ajax_save_display_template() {
		// Verify nonce and capabilities
		if ( ! check_ajax_referer( 'tdwp_display_nonce', 'nonce' ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Security check failed' );
		}

		$template_data = json_decode( stripslashes( $_POST['template_data'] ), true );

		if ( ! $template_data ) {
			wp_send_json_error( 'Invalid template data' );
		}

		global $wpdb;

		$result = $wpdb->insert(
			$wpdb->prefix . 'poker_display_templates',
			array(
				'tournament_id' => isset( $template_data['tournament_id'] ) ? intval( $template_data['tournament_id'] ) : null,
				'template_name' => sanitize_text_field( $template_data['template_name'] ),
				'template_type' => in_array( $template_data['template_type'], array( 'clock', 'rankings', 'prizes', 'seating', 'rules', 'custom' ) ) ? $template_data['template_type'] : 'custom',
				'html_template' => wp_kses_post( $template_data['html_template'] ),
				'css_styles' => wp_kses_post( $template_data['css_styles'] ),
				'tokens_used' => json_encode( $template_data['tokens_used'] ?? array() ),
				'is_default' => isset( $template_data['is_default'] ) ? (bool) $template_data['is_default'] : false,
			),
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%d' )
		);

		if ( $result ) {
			wp_send_json_success( array( 'template_id' => $wpdb->insert_id ) );
		} else {
			wp_send_json_error( 'Failed to save template' );
		}
	}

	/**
	 * Get display templates via AJAX
	 *
	 * @since 3.4.0
	 */
	public function ajax_get_display_templates() {
		// Verify nonce and capabilities
		if ( ! check_ajax_referer( 'tdwp_display_nonce', 'nonce' ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Security check failed' );
		}

		$tournament_id = isset( $_GET['tournament_id'] ) ? intval( $_GET['tournament_id'] ) : 0;
		$template_type = isset( $_GET['template_type'] ) ? sanitize_text_field( $_GET['template_type'] ) : '';

		global $wpdb;

		$where = array();
		$where_sql = '';

		if ( $tournament_id > 0 ) {
			$where[] = $wpdb->prepare( 'tournament_id = %d', $tournament_id );
		}

		if ( ! empty( $template_type ) ) {
			$where[] = $wpdb->prepare( 'template_type = %s', $template_type );
		}

		if ( ! empty( $where ) ) {
			$where_sql = 'WHERE ' . implode( ' AND ', $where );
		}

		$templates = $wpdb->get_results(
			"SELECT * FROM {$wpdb->prefix}poker_display_templates {$where_sql} ORDER BY template_name"
		);

		wp_send_json_success( $templates );
	}

	/**
	 * Save display layout via AJAX
	 *
	 * @since 3.4.0
	 */
	public function ajax_save_display_layout() {
		// Verify nonce and capabilities
		if ( ! check_ajax_referer( 'tdwp_display_nonce', 'nonce' ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Security check failed' );
		}

		$layout_data = json_decode( stripslashes( $_POST['layout_data'] ), true );

		if ( ! $layout_data ) {
			wp_send_json_error( 'Invalid layout data' );
		}

		global $wpdb;

		$result = $wpdb->insert(
			$wpdb->prefix . 'poker_display_layouts',
			array(
				'tournament_id' => intval( $layout_data['tournament_id'] ),
				'layout_name' => sanitize_text_field( $layout_data['layout_name'] ),
				'screen_size' => sanitize_text_field( $layout_data['screen_size'] ?? '' ),
				'grid_config' => json_encode( $layout_data['grid_config'] ?? array() ),
				'component_positions' => json_encode( $layout_data['component_positions'] ?? array() ),
				'breakpoints' => json_encode( $layout_data['breakpoints'] ?? array() ),
				'is_active' => isset( $layout_data['is_active'] ) ? (bool) $layout_data['is_active'] : true,
			),
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%d' )
		);

		if ( $result ) {
			wp_send_json_success( array( 'layout_id' => $wpdb->insert_id ) );
		} else {
			wp_send_json_error( 'Failed to save layout' );
		}
	}

	/**
	 * Get display screens via AJAX
	 *
	 * @since 3.4.0
	 */
	public function ajax_get_display_screens() {
		// Verify nonce and capabilities
		if ( ! check_ajax_referer( 'tdwp_display_nonce', 'nonce' ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Security check failed' );
		}

		global $wpdb;

		$screens = $wpdb->get_results(
			"SELECT s.*, t.template_name, l.layout_name
			 FROM {$wpdb->prefix}poker_display_screens s
			 LEFT JOIN {$wpdb->prefix}poker_display_templates t ON s.template_id = t.template_id
			 LEFT JOIN {$wpdb->prefix}poker_display_layouts l ON s.layout_id = l.layout_id
			 ORDER BY s.screen_name"
		);

		wp_send_json_success( $screens );
	}

	/**
	 * Get screen status
	 *
	 * @since 3.4.0
	 * @param int $screen_id Screen ID.
	 * @return object|null Screen status data.
	 */
	public function get_screen_status( $screen_id ) {
		global $wpdb;

		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}poker_display_screens WHERE screen_id = %d",
			$screen_id
		) );
	}

	/**
	 * Update screen status
	 *
	 * @since 3.4.0
	 * @param int    $screen_id Screen ID.
	 * @param array  $status_data Status data to update.
	 * @return bool Success status.
	 */
	public function update_screen_status( $screen_id, $status_data ) {
		global $wpdb;

		$allowed_fields = array( 'last_ping', 'is_online', 'location' );
		$update_data = array();
		$format = array();

		foreach ( $status_data as $field => $value ) {
			if ( in_array( $field, $allowed_fields ) ) {
				$update_data[ $field ] = $value;
				$format[] = is_bool( $value ) ? '%d' : '%s';
			}
		}

		if ( empty( $update_data ) ) {
			return false;
		}

		return (bool) $wpdb->update(
			$wpdb->prefix . 'poker_display_screens',
			$update_data,
			array( 'screen_id' => $screen_id ),
			$format,
			array( '%d' )
		);
	}
}