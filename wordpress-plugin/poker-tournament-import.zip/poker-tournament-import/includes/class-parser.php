<?php
/**
 * TDT File Parser Class
 *
 * Parses Tournament Director (.tdt) files and extracts tournament data
 */

// Prevent direct file access
if (!defined('ABSPATH')) {
    exit;
}

class Poker_Tournament_Parser {

    /**
     * File path
     */
    private $file_path;

    /**
     * Raw file content
     */
    private $raw_content;

    /**
     * Parsed tournament data
     */
    private $tournament_data;

    /**
     * Constructor
     */
    public function __construct($file_path = null) {
        if ($file_path) {
            $this->file_path = $file_path;
        }
    }

    /**
     * Parse TDT file
     */
    public function parse_file($file_path = null) {
        if ($file_path) {
            $this->file_path = $file_path;
        }

        if (!file_exists($this->file_path)) {
            throw new Exception("File not found: {$this->file_path}");
        }

        // Read file content
        $this->raw_content = file_get_contents($this->file_path);
        if ($this->raw_content === false) {
            throw new Exception("Failed to read file: {$this->file_path}");
        }

        // Parse the content
        $this->tournament_data = $this->extract_tournament_data($this->raw_content);

        return $this->tournament_data;
    }

    /**
     * Extract tournament data from raw content
     */
    private function extract_tournament_data($content) {
        $data = array();

        // Extract tournament metadata
        $data['metadata'] = $this->extract_metadata($content);

        // Extract players data
        $data['players'] = $this->extract_players($content);

        // Extract financial data
        $data['financial'] = $this->extract_financial_data($content);

        // Extract tournament structure
        $data['structure'] = $this->extract_structure($content);

        return $data;
    }

    /**
     * Extract tournament metadata
     */
    private function extract_metadata($content) {
        $metadata = array();

        // Extract UUID
        if (preg_match('/UUID:\s*"([^"]+)"/', $content, $matches)) {
            $metadata['uuid'] = $matches[1];
        }

        // Extract League info
        if (preg_match('/LeagueUUID:\s*"([^"]+)"/', $content, $matches)) {
            $metadata['league_uuid'] = $matches[1];
        }

        if (preg_match('/LeagueName:\s*"([^"]+)"/', $content, $matches)) {
            $metadata['league_name'] = $matches[1];
        }

        // Extract Season info
        if (preg_match('/SeasonUUID:\s*"([^"]+)"/', $content, $matches)) {
            $metadata['season_uuid'] = $matches[1];
        }

        if (preg_match('/SeasonName:\s*"([^"]+)"/', $content, $matches)) {
            $metadata['season_name'] = $matches[1];
        }

        // Extract Title
        if (preg_match('/Title:\s*"([^"]+)"/', $content, $matches)) {
            $metadata['title'] = $matches[1];
        }

        // Extract Description
        if (preg_match('/Description:\s*"([^"]+)"/', $content, $matches)) {
            $metadata['description'] = $matches[1];
        }

        // Extract Start Time (convert from milliseconds)
        if (preg_match('/StartTime:\s*(\d+)/', $content, $matches)) {
            $metadata['start_time'] = date('Y-m-d H:i:s', $matches[1] / 1000);
        }

        return $metadata;
    }

    /**
     * Extract players data
     */
    private function extract_players($content) {
        $players = array();

        // Find all player blocks
        preg_match_all('/new GamePlayer\(\{([^}]+(?:\{[^}]*\}[^}]*)*)\}\)/', $content, $player_matches);

        foreach ($player_matches[1] as $player_data) {
            $player = array();

            // Extract UUID
            if (preg_match('/UUID:\s*"([^"]+)"/', $player_data, $matches)) {
                $player['uuid'] = $matches[1];
            }

            // Extract Nickname
            if (preg_match('/Nickname:\s*"([^"]+)"/', $player_data, $matches)) {
                $player['nickname'] = $matches[1];
            }

            // Extract Buyins
            $player['buyins'] = $this->extract_buyins($player_data);

            // Calculate finish position and winnings from bust-out data
            $player['finish_position'] = $this->calculate_finish_position($player_data);
            $player['winnings'] = $this->calculate_winnings($player_data);

            // Extract hit count
            if (preg_match('/HitsAdjustment:\s*(\d+)/', $player_data, $matches)) {
                $player['hits'] = intval($matches[1]);
            } else {
                $player['hits'] = 0;
            }

            if (!empty($player['uuid']) && !empty($player['nickname'])) {
                $players[$player['uuid']] = $player;
            }
        }

        return $players;
    }

    /**
     * Extract player buyins
     */
    private function extract_buyins($player_data) {
        $buyins = array();

        // Find all GameBuyin objects
        preg_match_all('/new GameBuyin\(\{([^}]+(?:\{[^}]*\}[^}]*)*)\}\)/', $player_data, $buyin_matches);

        foreach ($buyin_matches[1] as $buyin_info) {
            $buyin = array();

            // Extract amount
            if (preg_match('/Amount:\s*(\d+)/', $buyin_info, $matches)) {
                $buyin['amount'] = intval($matches[1]);
            }

            // Extract chips
            if (preg_match('/Chips:\s*(\d+)/', $buyin_info, $matches)) {
                $buyin['chips'] = intval($matches[1]);
            }

            // Extract profile name
            if (preg_match('/ProfileName:\s*"([^"]+)"/', $buyin_info, $matches)) {
                $buyin['profile'] = $matches[1];
            }

            $buyins[] = $buyin;
        }

        return $buyins;
    }

    /**
     * Calculate player finish position from bust-out data
     */
    private function calculate_finish_position($player_data) {
        // This is a simplified calculation - in a real implementation,
        // we'd need to analyze all players' bust-out times and rank them
        return 1; // Placeholder
    }

    /**
     * Calculate player winnings
     */
    private function calculate_winnings($player_data) {
        // This would be extracted from the prize distribution
        // For now, return 0 as placeholder
        return 0;
    }

    /**
     * Extract financial configuration
     */
    private function extract_financial_data($content) {
        $financial = array();

        // Extract buy-in amounts
        preg_match_all('/new FeeProfile\(\{[^}]*Name:\s*"([^"]+)"[^}]*Fee:\s*(\d+)/', $content, $matches);

        if (!empty($matches[1]) && !empty($matches[2])) {
            foreach ($matches[1] as $i => $name) {
                $financial['fee_profiles'][$name] = array(
                    'name' => $name,
                    'fee' => intval($matches[2][$i])
                );
            }
        }

        return $financial;
    }

    /**
     * Extract tournament structure (blinds, levels, etc.)
     */
    private function extract_structure($content) {
        $structure = array();

        // Extract blind levels
        preg_match_all('/new GameRound\(\{[^}]*SmallBlind:\s*(\d+)[^}]*BigBlind:\s*(\d+)[^}]*Minutes:\s*(\d+)/', $content, $matches);

        if (!empty($matches[1])) {
            foreach ($matches[1] as $i => $small_blind) {
                $structure['levels'][] = array(
                    'small_blind' => intval($small_blind),
                    'big_blind' => intval($matches[2][$i]),
                    'minutes' => intval($matches[3][$i])
                );
            }
        }

        return $structure;
    }

    /**
     * Get tournament data
     */
    public function get_tournament_data() {
        return $this->tournament_data;
    }

    /**
     * Validate parsed data
     */
    public function validate_data() {
        $errors = array();

        if (empty($this->tournament_data['metadata']['uuid'])) {
            $errors[] = 'Tournament UUID is missing';
        }

        if (empty($this->tournament_data['metadata']['title'])) {
            $errors[] = 'Tournament title is missing';
        }

        if (empty($this->tournament_data['players'])) {
            $errors[] = 'No player data found';
        }

        return $errors;
    }
}