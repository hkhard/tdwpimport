/**
 * Dependency Manager Admin JavaScript
 *
 * Handles AJAX requests and UI interactions for the dependency management interface
 *
 * @package Poker_Tournament_Import
 * @subpackage Admin
 * @since 3.3.0
 */

jQuery(document).ready(function($) {
    'use strict';

    // Initialize the dependency manager
    TDWP_Dependency_Manager.init();

    /**
     * Main dependency manager object
     */
    window.TDWP_Dependency_Manager = {

        /**
         * Initialize the dependency manager
         */
        init: function() {
            this.loadStatus();
            this.bindEvents();
            this.startStatusPolling();
        },

        /**
         * Bind all event handlers
         */
        bindEvents: function() {
            // Download button
            $('#download-btn').on('click', this.handleDownload.bind(this));

            // Upload functionality
            $('#upload-btn').on('click', this.handleUploadClick.bind(this));
            $('#dependency-upload').on('change', this.handleFileSelect.bind(this));

            // Clear button
            $('#clear-btn').on('click', this.handleClear.bind(this));
        },

        /**
         * Load current dependency status
         */
        loadStatus: function() {
            this.showLoading();

            $.ajax({
                url: tdwpDependencyManager.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'tdwp_get_dependency_status',
                    nonce: tdwpDependencyManager.nonce
                },
                success: function(response) {
                    if (response.success) {
                        TDWP_Dependency_Manager.updateStatusDisplay(response.data);
                    } else {
                        TDWP_Dependency_Manager.showError(response.data.message || 'Failed to load status');
                    }
                },
                error: function() {
                    TDWP_Dependency_Manager.showError('Network error occurred while loading status');
                },
                complete: function() {
                    TDWP_Dependency_Manager.hideLoading();
                }
            });
        },

        /**
         * Update the status display
         */
        updateStatusDisplay: function(data) {
            var $status = $('#tcpdf-status');
            var $details = $('#tcpdf-details');
            var $actions = $('#tcpdf-actions');

            // Update status indicator
            var statusClass = data.tcpdf_available ? 'status-available' : 'status-missing';
            var statusIcon = data.tcpdf_available ? 'dashicons-yes' : 'dashicons-no';
            var statusText = data.tcpdf_available ?
                tdwpDependencyManager.messages.available || 'Available' :
                tdwpDependencyManager.messages.missing || 'Not Available';

            $status.html(
                '<div class="' + statusClass + '">' +
                    '<span class="dashicons ' + statusIcon + '"></span>' +
                    '<span>' + statusText + '</span>' +
                '</div>'
            );

            // Update details
            var lastCheck = data.last_check ?
                new Date(data.last_check * 1000).toLocaleString() :
                'Never';

            $details.html(
                '<p><strong>Version:</strong> ' + data.tcpdf_version + '</p>' +
                '<p><strong>Path:</strong> ' + data.tcpdf_path + '</p>' +
                '<p><strong>Last Check:</strong> ' + lastCheck + '</p>'
            ).show();

            // Update actions based on status
            if (data.tcpdf_available) {
                $actions.html(
                    '<button type="button" class="button button-secondary" id="reinstall-btn">' +
                        '<span class="dashicons dashicons-update"></span>' +
                        'Reinstall Libraries' +
                    '</button>' +
                    '<button type="button" class="button button-secondary" id="remove-btn">' +
                        '<span class="dashicons dashicons-trash"></span>' +
                        'Remove Libraries' +
                    '</button>'
                );

                // Bind new action buttons
                $('#reinstall-btn').on('click', this.handleReinstall.bind(this));
                $('#remove-btn').on('click', this.handleClear.bind(this));
            } else {
                $actions.html(
                    '<button type="button" class="button button-primary" id="download-btn">' +
                        '<span class="dashicons dashicons-download"></span>' +
                        'Download PDF Libraries' +
                    '</button>'
                );

                // Re-bind download button
                $('#download-btn').on('click', this.handleDownload.bind(this));
            }

            $actions.show();
        },

        /**
         * Handle download button click
         */
        handleDownload: function() {
            var $button = $('#download-btn');

            if ($button.hasClass('loading')) {
                return;
            }

            this.setButtonLoading($button, true);
            this.showDownloadingStatus();

            $.ajax({
                url: tdwpDependencyManager.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'tdwp_download_dependency',
                    nonce: tdwpDependencyManager.nonce
                },
                success: function(response) {
                    if (response.success) {
                        TDWP_Dependency_Manager.showSuccess(response.data.message);
                        // Reload status after a short delay
                        setTimeout(function() {
                            TDWP_Dependency_Manager.loadStatus();
                        }, 2000);
                    } else {
                        TDWP_Dependency_Manager.showError(response.data.message);
                    }
                },
                error: function() {
                    TDWP_Dependency_Manager.showError('Network error occurred during download');
                },
                complete: function() {
                    TDWP_Dependency_Manager.setButtonLoading($button, false);
                    TDWP_Dependency_Manager.hideDownloadingStatus();
                }
            });
        },

        /**
         * Handle reinstall button click
         */
        handleReinstall: function() {
            if (confirm(tdwpDependencyManager.messages.confirmReinstall || 'Reinstall the PDF libraries?')) {
                this.handleDownload();
            }
        },

        /**
         * Handle upload button click
         */
        handleUploadClick: function() {
            $('#dependency-upload').click();
        },

        /**
         * Handle file selection
         */
        handleFileSelect: function(event) {
            var file = event.target.files[0];
            if (!file) {
                return;
            }

            // Validate file type
            if (!file.name.toLowerCase().endsWith('.zip')) {
                this.showError('Please select a ZIP file');
                return;
            }

            // Validate file size (20MB max)
            if (file.size > 20 * 1024 * 1024) {
                this.showError('File size too large. Maximum size is 20MB');
                return;
            }

            // Show filename
            $('#upload-filename').text(file.name);

            // Create form data for upload
            var formData = new FormData();
            formData.append('action', 'tdwp_upload_dependency');
            formData.append('nonce', tdwpDependencyManager.nonce);
            formData.append('dependency_file', file);

            // Show uploading status
            this.setButtonLoading($('#upload-btn'), true);

            $.ajax({
                url: tdwpDependencyManager.ajaxUrl,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        TDWP_Dependency_Manager.showSuccess(response.data.message);
                        $('#upload-filename').text('');
                        document.getElementById('dependency-upload').value = '';
                        // Reload status after a short delay
                        setTimeout(function() {
                            TDWP_Dependency_Manager.loadStatus();
                        }, 2000);
                    } else {
                        TDWP_Dependency_Manager.showError(response.data.message);
                    }
                },
                error: function() {
                    TDWP_Dependency_Manager.showError('Network error occurred during upload');
                },
                complete: function() {
                    TDWP_Dependency_Manager.setButtonLoading($('#upload-btn'), false);
                }
            });
        },

        /**
         * Handle clear button click
         */
        handleClear: function() {
            if (!confirm(tdwpDependencyManager.messages.confirmClear)) {
                return;
            }

            var $button = $('#clear-btn, #remove-btn');
            this.setButtonLoading($button, true);

            $.ajax({
                url: tdwpDependencyManager.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'tdwp_clear_dependency',
                    nonce: tdwpDependencyManager.nonce
                },
                success: function(response) {
                    if (response.success) {
                        TDWP_Dependency_Manager.showSuccess(response.data.message);
                        // Reload status after a short delay
                        setTimeout(function() {
                            TDWP_Dependency_Manager.loadStatus();
                        }, 1000);
                    } else {
                        TDWP_Dependency_Manager.showError(response.data.message);
                    }
                },
                error: function() {
                    TDWP_Dependency_Manager.showError('Network error occurred while clearing libraries');
                },
                complete: function() {
                    TDWP_Dependency_Manager.setButtonLoading($button, false);
                }
            });
        },

        /**
         * Set button loading state
         */
        setButtonLoading: function($button, loading) {
            if (loading) {
                $button.addClass('loading').prop('disabled', true);
                var $icon = $button.find('.dashicons');
                if ($icon.length) {
                    $icon.addClass('spin');
                }
            } else {
                $button.removeClass('loading').prop('disabled', false);
                $button.find('.dashicons').removeClass('spin');
            }
        },

        /**
         * Show loading state
         */
        showLoading: function() {
            $('#tcpdf-status').html(
                '<div class="status-loading">' +
                    '<span class="spinner is-active"></span>' +
                    '<span>Loading...</span>' +
                '</div>'
            );
            $('#tcpdf-details, #tcpdf-actions').hide();
        },

        /**
         * Show downloading status
         */
        showDownloadingStatus: function() {
            $('#tcpdf-status').html(
                '<div class="status-downloading">' +
                    '<span class="dashicons dashicons-download spin"></span>' +
                    '<span>Downloading libraries...</span>' +
                '</div>'
            );
        },

        /**
         * Hide downloading status
         */
        hideDownloadingStatus: function() {
            // Status will be updated by loadStatus()
        },

        /**
         * Show success message
         */
        showSuccess: function(message) {
            this.showNotice(message, 'success');
        },

        /**
         * Show error message
         */
        showError: function(message) {
            this.showNotice(message, 'error');
        },

        /**
         * Show notice message
         */
        showNotice: function(message, type) {
            var noticeClass = 'tdwp-notice tdwp-notice-' + type;
            var $notice = $('<div class="' + noticeClass + '">' +
                '<p>' + $('<div>').text(message).html() + '</p>' +
                '</div>');

            // Insert at the top of the wrap div
            $('.tdwp-dependency-manager').prepend($notice);

            // Auto-hide after 5 seconds
            setTimeout(function() {
                $notice.fadeOut(500, function() {
                    $(this).remove();
                });
            }, 5000);

            // Allow manual dismissal
            $notice.on('click', function() {
                $(this).fadeOut(500, function() {
                    $(this).remove();
                });
            });
        },

        /**
         * Start status polling (every 30 seconds)
         */
        startStatusPolling: function() {
            setInterval(function() {
                TDWP_Dependency_Manager.loadStatus();
            }, 30000);
        }
    };

    // Add CSS for spinning animation
    $('<style>').text(
        '.dashicons.spin {' +
            'animation: spin 1s linear infinite;' +
        '}' +
        '@keyframes spin {' +
            'from { transform: rotate(0deg); }' +
            'to { transform: rotate(360deg); }' +
        '}'
    ).appendTo('head');
});