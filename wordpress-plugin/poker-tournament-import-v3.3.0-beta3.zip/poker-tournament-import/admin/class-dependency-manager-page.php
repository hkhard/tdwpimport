<?php
/**
 * Dependency Manager Admin Page
 *
 * Provides admin interface for managing PDF library dependencies
 *
 * @package Poker_Tournament_Import
 * @subpackage Admin
 * @since 3.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class TDWP_Dependency_Manager_Page {

	/**
	 * Instance of this class
	 *
	 * @var TDWP_Dependency_Manager_Page
	 */
	private static $instance = null;

	/**
	 * Get singleton instance
	 *
	 * @since 3.3.0
	 * @return TDWP_Dependency_Manager_Page
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 *
	 * @since 3.3.0
	 */
	private function __construct() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
		add_action( 'wp_ajax_tdwp_get_dependency_status', array( $this, 'ajax_get_dependency_status' ) );
		add_action( 'wp_ajax_tdwp_download_dependency', array( $this, 'ajax_download_dependency' ) );
		add_action( 'wp_ajax_tdwp_upload_dependency', array( $this, 'ajax_upload_dependency' ) );
		add_action( 'wp_ajax_tdwp_clear_dependency', array( $this, 'ajax_clear_dependency' ) );
	}

	/**
	 * Add admin menu page
	 *
	 * @since 3.3.0
	 */
	public function add_admin_menu() {
		add_submenu_page(
			'poker-tournament-import',
			__( 'Dependencies', 'poker-tournament-import' ),
			__( 'Dependencies', 'poker-tournament-import' ),
			'manage_options',
			'tdwp-dependency-manager',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Enqueue admin scripts and styles
	 *
	 * @since 3.3.0
	 * @param string $hook Current admin page hook
	 */
	public function enqueue_admin_scripts( $hook ) {
		if ( 'poker-tournament-import_page_tdwp-dependency-manager' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'tdwp-dependency-manager',
			POKER_TOURNAMENT_IMPORT_PLUGIN_URL . 'admin/assets/css/dependency-manager.css',
			array(),
			POKER_TOURNAMENT_IMPORT_VERSION
		);

		wp_enqueue_script(
			'tdwp-dependency-manager',
			POKER_TOURNAMENT_IMPORT_PLUGIN_URL . 'admin/assets/js/dependency-manager.js',
			array( 'jquery' ),
			POKER_TOURNAMENT_IMPORT_VERSION,
			true
		);

		wp_localize_script(
			'tdwp-dependency-manager',
			'tdwpDependencyManager',
			array(
				'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( 'tdwp_dependency_manager' ),
				'messages'   => array(
					'confirmClear'    => __( 'Are you sure you want to remove the PDF libraries? This will disable PDF export functionality until they are re-downloaded.', 'poker-tournament-import' ),
					'downloadStart'   => __( 'Starting download...', 'poker-tournament-import' ),
					'uploadSuccess'   => __( 'Library uploaded successfully!', 'poker-tournament-import' ),
					'uploadError'     => __( 'Upload failed. Please check the file and try again.', 'poker-tournament-import' ),
					'clearSuccess'    => __( 'Libraries removed successfully.', 'poker-tournament-import' ),
					'clearError'      => __( 'Failed to remove libraries.', 'poker-tournament-import' ),
				),
			)
		);
	}

	/**
	 * Render the admin page
	 *
	 * @since 3.3.0
	 */
	public function render_page() {
		?>
		<div class="wrap tdwp-dependency-manager">
			<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

			<div class="tdwp-dependency-overview">
				<div class="tdwp-dependency-card">
					<h3><?php _e( 'PDF Export Libraries', 'poker-tournament-import' ); ?></h3>
					<div class="dependency-status" id="tcpdf-status">
						<div class="status-loading">
							<span class="spinner is-active"></span>
							<span><?php _e( 'Checking status...', 'poker-tournament-import' ); ?></span>
						</div>
					</div>
					<div class="dependency-details" id="tcpdf-details" style="display: none;">
						<!-- Details will be populated via JavaScript -->
					</div>
					<div class="dependency-actions" id="tcpdf-actions" style="display: none;">
						<!-- Actions will be populated via JavaScript -->
					</div>
				</div>
			</div>

			<div class="tdwp-dependency-actions">
				<h2><?php _e( 'Manual Actions', 'poker-tournament-import' ); ?></h2>

				<div class="tdwp-action-section">
					<h3><?php _e( 'Download Libraries', 'poker-tournament-import' ); ?></h3>
					<p><?php _e( 'Manually download the TCPDF library from the official repository.', 'poker-tournament-import' ); ?></p>
					<button type="button" class="button button-primary" id="download-btn">
						<span class="dashicons dashicons-download"></span>
						<?php _e( 'Download PDF Libraries', 'poker-tournament-import' ); ?>
					</button>
				</div>

				<div class="tdwp-action-section">
					<h3><?php _e( 'Manual Upload', 'poker-tournament-import' ); ?></h3>
					<p><?php _e( 'For servers without internet access. Upload TCPDF library ZIP file manually.', 'poker-tournament-import' ); ?></p>
					<div class="upload-area">
						<input type="file" id="dependency-upload" accept=".zip" style="display: none;">
						<button type="button" class="button button-secondary" id="upload-btn">
							<span class="dashicons dashicons-upload"></span>
							<?php _e( 'Upload Library File', 'poker-tournament-import' ); ?>
						</button>
						<span class="upload-filename" id="upload-filename"></span>
					</div>
				</div>

				<div class="tdwp-action-section">
					<h3><?php _e( 'Remove Libraries', 'poker-tournament-import' ); ?></h3>
					<p><?php _e( 'Remove installed libraries to re-download or upload a different version.', 'poker-tournament-import' ); ?></p>
					<button type="button" class="button button-secondary" id="clear-btn">
						<span class="dashicons dashicons-trash"></span>
						<?php _e( 'Remove Libraries', 'poker-tournament-import' ); ?>
					</button>
				</div>
			</div>

			<div class="tdwp-system-info">
				<h2><?php _e( 'System Information', 'poker-tournament-import' ); ?></h2>
				<table class="widefat">
					<thead>
						<tr>
							<th><?php _e( 'Setting', 'poker-tournament-import' ); ?></th>
							<th><?php _e( 'Value', 'poker-tournament-import' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><?php _e( 'PHP Version', 'poker-tournament-import' ); ?></td>
							<td><?php echo esc_html( PHP_VERSION ); ?></td>
						</tr>
						<tr>
							<td><?php _e( 'Memory Limit', 'poker-tournament-import' ); ?></td>
							<td><?php echo esc_html( ini_get( 'memory_limit' ) ); ?></td>
						</tr>
						<tr>
							<td><?php _e( 'Upload Max Filesize', 'poker-tournament-import' ); ?></td>
							<td><?php echo esc_html( ini_get( 'upload_max_filesize' ) ); ?></td>
						</tr>
						<tr>
							<td><?php _e( 'Uploads Directory', 'poker-tournament-import' ); ?></td>
							<td><?php
								$upload_dir = wp_upload_dir();
								echo esc_html( $upload_dir['basedir'] );
							?></td>
						</tr>
						<tr>
							<td><?php _e( 'Uploads Writable', 'poker-tournament-import' ); ?></td>
							<td>
								<?php
								$upload_dir = wp_upload_dir();
								$writable = is_writable( $upload_dir['basedir'] );
								echo $writable
									? '<span class="status-success">' . __( 'Yes', 'poker-tournament-import' ) . '</span>'
									: '<span class="status-error">' . __( 'No', 'poker-tournament-import' ) . '</span>';
								?>
							</td>
						</tr>
					</tbody>
				</table>
			</div>

			<div class="tdwp-help-section">
				<h2><?php _e( 'Help & Troubleshooting', 'poker-tournament-import' ); ?></h2>
				<div class="tdwp-help-cards">
					<div class="help-card">
						<h3><span class="dashicons dashicons-download"></span> <?php _e( 'Download Issues', 'poker-tournament-import' ); ?></h3>
						<p><?php _e( 'If automatic download fails, your server may have network restrictions. Try the manual upload option or contact your hosting provider.', 'poker-tournament-import' ); ?></p>
					</div>
					<div class="help-card">
						<h3><span class="dashicons dashicons-upload"></span> <?php _e( 'Manual Upload', 'poker-tournament-import' ); ?></h3>
						<p><?php _e( 'Download TCPDF from <a href="https://github.com/tecnickcom/TCPDF/releases" target="_blank">GitHub Releases</a> and upload the ZIP file here.', 'poker-tournament-import' ); ?></p>
					</div>
					<div class="help-card">
						<h3><span class="dashicons dashicons-warning"></span> <?php _e( 'Permissions', 'poker-tournament-import' ); ?></h3>
						<p><?php _e( 'Ensure the uploads directory is writable (755 permissions). Contact your hosting provider if you need assistance.', 'poker-tournament-import' ); ?></p>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * AJAX handler for getting dependency status
	 *
	 * @since 3.3.0
	 */
	public function ajax_get_dependency_status() {
		check_ajax_referer( 'tdwp_dependency_manager', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( __( 'You do not have sufficient permissions to perform this action.', 'poker-tournament-import' ) );
		}

		$dependency_manager = TDWP_Dependency_Manager::get_instance();
		$status = $dependency_manager->get_dependency_status();

		wp_send_json_success( $status );
	}

	/**
	 * AJAX handler for downloading dependencies
	 *
	 * @since 3.3.0
	 */
	public function ajax_download_dependency() {
		check_ajax_referer( 'tdwp_dependency_manager', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( __( 'You do not have sufficient permissions to perform this action.', 'poker-tournament-import' ) );
		}

		$dependency_manager = TDWP_Dependency_Manager::get_instance();
		$result = $dependency_manager->download_tcpdf();

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array(
				'message' => $result->get_error_message(),
			) );
		} else {
			wp_send_json_success( array(
				'message' => $result['message'],
			) );
		}
	}

	/**
	 * AJAX handler for uploading dependencies
	 *
	 * @since 3.3.0
	 */
	public function ajax_upload_dependency() {
		check_ajax_referer( 'tdwp_dependency_manager', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( __( 'You do not have sufficient permissions to perform this action.', 'poker-tournament-import' ) );
		}

		if ( ! isset( $_FILES['dependency_file'] ) ) {
			wp_send_json_error( array(
				'message' => __( 'No file uploaded.', 'poker-tournament-import' ),
			) );
		}

		$file = $_FILES['dependency_file'];

		// Validate file type
		$file_info = pathinfo( $file['name'] );
		if ( strtolower( $file_info['extension'] ) !== 'zip' ) {
			wp_send_json_error( array(
				'message' => __( 'Please upload a ZIP file.', 'poker-tournament-import' ),
			) );
		}

		// Validate file size (max 20MB)
		if ( $file['size'] > 20 * 1024 * 1024 ) {
			wp_send_json_error( array(
				'message' => __( 'File size too large. Maximum size is 20MB.', 'poker-tournament-import' ),
			) );
		}

		// Handle the upload
		$upload_dir = wp_upload_dir();
		$lib_dir = $upload_dir['basedir'] . '/tdwp-libs';
		$temp_file = $lib_dir . '/tcpdf-upload.zip';

		wp_mkdir_p( $lib_dir );

		if ( ! move_uploaded_file( $file['tmp_name'], $temp_file ) ) {
			wp_send_json_error( array(
				'message' => __( 'Failed to move uploaded file.', 'poker-tournament-import' ),
			) );
		}

		// Extract TCPDF using the dependency manager's extraction method
		$dependency_manager = TDWP_Dependency_Manager::get_instance();
		$extraction_result = $dependency_manager->extract_tcpdf_from_archive( $temp_file );

		unlink( $temp_file ); // Remove temp file

		if ( is_wp_error( $extraction_result ) ) {
			wp_send_json_error( array(
				'message' => $extraction_result->get_error_message(),
			) );
		}

		wp_send_json_success( array(
			'message' => __( 'Library uploaded and installed successfully!', 'poker-tournament-import' ),
		) );
	}

	/**
	 * AJAX handler for clearing dependencies
	 *
	 * @since 3.3.0
	 */
	public function ajax_clear_dependency() {
		check_ajax_referer( 'tdwp_dependency_manager', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( __( 'You do not have sufficient permissions to perform this action.', 'poker-tournament-import' ) );
		}

		$upload_dir = wp_upload_dir();
		$tcpdf_dir = $upload_dir['basedir'] . '/tdwp-libs/tcpdf';

		if ( file_exists( $tcpdf_dir ) ) {
			WP_Filesystem();
			$GLOBALS['wp_filesystem']->delete( $tcpdf_dir, true );
		}

		// Clear the installed transient
		delete_transient( 'tdwp_tcpdf_installed' );

		wp_send_json_success( array(
			'message' => __( 'Libraries removed successfully.', 'poker-tournament-import' ),
		) );
	}
}