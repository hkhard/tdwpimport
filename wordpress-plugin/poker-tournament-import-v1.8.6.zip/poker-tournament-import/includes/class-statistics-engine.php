<?php
/**
 * Poker Statistics Engine
 *
 * Handles calculation and storage of dashboard statistics
 * in the data mart for fast dashboard loading.
 *
 * @package Poker Tournament Import
 */

// Prevent direct file access
if (!defined('ABSPATH')) {
    exit;
}

class Poker_Statistics_Engine {

    /**
     * Singleton instance
     */
    private static $instance = null;

    /**
     * Statistics table name
     */
    private $stats_table;

    /**
     * Players table name
     */
    private $players_table;

    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        global $wpdb;
        $this->stats_table = $wpdb->prefix . 'poker_statistics';
        $this->players_table = $wpdb->prefix . 'poker_tournament_players';
    }

    /**
     * Calculate and store all dashboard statistics
     */
    public function calculate_all_statistics() {
        global $wpdb;

        // Start timer for performance tracking
        $start_time = microtime(true);

        // Clear existing statistics
        $this->clear_all_statistics();

        // Calculate basic counts
        $this->update_statistic('total_tournaments', $this->get_total_tournaments(), 'count');
        $this->update_statistic('total_players', $this->get_unique_players(), 'count');
        $this->update_statistic('active_series', $this->get_active_series(), 'count');
        $this->update_statistic('total_prize_pool', $this->get_total_prize_pool(), 'sum');

        // Calculate derived statistics
        $total_tournaments = $this->get_total_tournaments();
        $total_prize_pool = $this->get_total_prize_pool();
        $this->update_statistic('avg_prize_pool', $total_tournaments > 0 ? $total_prize_pool / $total_tournaments : 0, 'average');

        // Calculate time-based statistics
        $this->update_statistic('recent_tournaments_30d', $this->get_recent_tournaments(30), 'count');
        $this->update_statistic('new_players_30d', $this->get_new_players(30), 'count');

        // Log performance
        $calculation_time = round((microtime(true) - $start_time) * 1000, 2);
        error_log("Poker Statistics: All statistics calculated in {$calculation_time}ms");

        return true;
    }

    /**
     * Update a single statistic
     */
    public function update_statistic($name, $value, $type = 'count', $related_id = null) {
        global $wpdb;

        $result = $wpdb->replace(
            $this->stats_table,
            array(
                'stat_name' => $name,
                'stat_value' => $value,
                'stat_type' => $type,
                'calculation_date' => current_time('Y-m-d'),
                'related_id' => $related_id
            ),
            array(
                '%s', '%f', '%s', '%s', '%d'
            )
        );

        if ($result === false) {
            error_log("Poker Statistics: Failed to update statistic '{$name}'");
        }

        return $result !== false;
    }

    /**
     * Get a single statistic value
     */
    public function get_statistic($name) {
        global $wpdb;

        $value = $wpdb->get_var($wpdb->prepare(
            "SELECT stat_value FROM {$this->stats_table} WHERE stat_name = %s LIMIT 1",
            $name
        ));

        return $value !== null ? floatval($value) : 0;
    }

    /**
     * Get multiple statistics at once
     */
    public function get_statistics($names) {
        $stats = array();
        foreach ($names as $name) {
            $stats[$name] = $this->get_statistic($name);
        }
        return $stats;
    }

    /**
     * Clear all statistics
     */
    public function clear_all_statistics() {
        global $wpdb;
        return $wpdb->query("TRUNCATE TABLE {$this->stats_table}");
    }

    /**
     * Get total tournaments count
     */
    private function get_total_tournaments() {
        return intval(wp_count_posts('tournament')->publish);
    }

    /**
     * Get unique players count
     */
    private function get_unique_players() {
        global $wpdb;
        return intval($wpdb->get_var("SELECT COUNT(DISTINCT player_id) FROM {$this->players_table}"));
    }

    /**
     * Get active series count
     */
    private function get_active_series() {
        return intval(wp_count_posts('tournament_series')->publish);
    }

    /**
     * Get total prize pool
     */
    private function get_total_prize_pool() {
        global $wpdb;
        $total = $wpdb->get_var("SELECT SUM(CAST(meta_value AS DECIMAL(10,2))) FROM {$wpdb->postmeta} WHERE meta_key = 'prize_pool'");
        return floatval($total ?: 0);
    }

    /**
     * Get recent tournaments within days
     */
    private function get_recent_tournaments($days = 30) {
        global $wpdb;

        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts}
             WHERE post_type = 'tournament' AND post_status = 'publish'
             AND post_date >= %s",
            date('Y-m-d', strtotime("-{$days} days"))
        ));

        return intval($count);
    }

    /**
     * Get new players within days
     */
    private function get_new_players($days = 30) {
        global $wpdb;

        // This is a simplified version - could be made more sophisticated
        // by tracking player creation dates in the future
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT tp.player_id)
             FROM {$this->players_table} tp
             INNER JOIN {$wpdb->posts} p ON p.post_type = 'tournament' AND p.post_status = 'publish'
             WHERE tp.tournament_id IN (
                 SELECT meta_value FROM {$wpdb->postmeta}
                 WHERE meta_key = 'tournament_uuid'
                 AND post_id IN (
                     SELECT ID FROM {$wpdb->posts}
                     WHERE post_type = 'tournament'
                     AND post_status = 'publish'
                     AND post_date >= %s
                 )
             )",
            date('Y-m-d', strtotime("-{$days} days"))
        ));

        return intval($count);
    }

    /**
     * Refresh statistics (public method for manual refresh)
     */
    public function refresh_statistics() {
        return $this->calculate_all_statistics();
    }

    /**
     * Get statistics last updated time
     */
    public function get_last_updated() {
        global $wpdb;

        $last_updated = $wpdb->get_var("SELECT MAX(last_updated) FROM {$this->stats_table}");

        return $last_updated ? $last_updated : false;
    }

    /**
     * Get statistics for dashboard
     */
    public function get_dashboard_statistics() {
        return array(
            'total_tournaments' => $this->get_statistic('total_tournaments'),
            'total_players' => $this->get_statistic('total_players'),
            'total_prize_pool' => $this->get_statistic('total_prize_pool'),
            'avg_prize_pool' => $this->get_statistic('avg_prize_pool'),
            'active_series' => $this->get_statistic('active_series'),
            'recent_tournaments_30d' => $this->get_statistic('recent_tournaments_30d'),
            'new_players_30d' => $this->get_statistic('new_players_30d'),
            'last_updated' => $this->get_last_updated()
        );
    }

    /**
     * Hook into tournament import completion
     */
    public function on_tournament_import_complete($tournament_id) {
        // Refresh statistics after each tournament import
        $this->calculate_all_statistics();
    }

    /**
     * AJAX handler for manual statistics refresh
     */
    public function ajax_refresh_statistics() {
        check_ajax_referer('poker_refresh_statistics', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'poker-tournament-import'));
        }

        $result = $this->refresh_statistics();

        if ($result) {
            wp_send_json_success(array(
                'message' => __('Statistics refreshed successfully!', 'poker-tournament-import'),
                'timestamp' => current_time('mysql'),
                'stats' => $this->get_dashboard_statistics()
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Failed to refresh statistics.', 'poker-tournament-import')
            ));
        }
    }
}