<?php
/**
 * Migration Tools Class
 *
 * Handles migration of existing tournament data to fix series/season relationships
 * and apply taxonomy categorization to existing tournaments
 */

// Prevent direct file access
if (!defined('ABSPATH')) {
    exit;
}

class Poker_Tournament_Migration_Tools {

    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_init', array($this, 'handle_migration_actions'));
    }

    /**
     * Get tournaments needing relationship migration
     */
    public function get_tournaments_needing_migration() {
        $args = array(
            'post_type' => 'tournament',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'meta_query' => array(
                'relation' => 'OR',
                array(
                    'key' => '_series_id',
                    'compare' => 'NOT EXISTS'
                ),
                array(
                    'key' => '_season_id',
                    'compare' => 'NOT EXISTS'
                )
            )
        );

        $tournaments = get_posts($args);
        return $tournaments;
    }

    /**
     * Get count of tournaments needing migration
     */
    public function get_migration_count() {
        $tournaments = $this->get_tournaments_needing_migration();
        return count($tournaments);
    }

    /**
     * Migrate tournament relationships
     */
    public function migrate_tournament_relationships($tournament_id = null) {
        $results = array(
            'success' => 0,
            'failed' => 0,
            'errors' => array()
        );

        if ($tournament_id) {
            // Migrate single tournament
            $tournament_ids = array($tournament_id);
        } else {
            // Migrate all tournaments
            $tournament_ids = $this->get_tournaments_needing_migration();
        }

        if (empty($tournament_ids)) {
            return $results;
        }

        foreach ($tournament_ids as $tournament_id) {
            try {
                $success = $this->migrate_single_tournament($tournament_id);
                if ($success) {
                    $results['success']++;
                } else {
                    $results['failed']++;
                    $results['errors'][] = "Failed to migrate tournament ID: {$tournament_id}";
                }
            } catch (Exception $e) {
                $results['failed']++;
                $results['errors'][] = "Exception for tournament ID {$tournament_id}: " . $e->getMessage();
            }
        }

        return $results;
    }

    /**
     * Migrate a single tournament
     */
    private function migrate_single_tournament($tournament_id) {
        // Get tournament data
        $tournament_data = get_post_meta($tournament_id, 'tournament_data', true);
        if (empty($tournament_data)) {
            return false;
        }

        $migrated = false;
        $metadata = $tournament_data['metadata'] ?? array();

        // Migrate series relationship
        if (!empty($metadata['league_name'])) {
            $series_id = $this->find_or_create_series(
                $metadata['league_name'],
                $metadata['league_uuid'] ?? ''
            );

            if ($series_id) {
                update_post_meta($tournament_id, '_series_id', $series_id);
                $migrated = true;
            }
        }

        // Migrate season relationship
        if (!empty($metadata['season_name'])) {
            $season_id = $this->find_or_create_season(
                $metadata['season_name'],
                $metadata['season_uuid'] ?? ''
            );

            if ($season_id) {
                update_post_meta($tournament_id, '_season_id', $season_id);
                $migrated = true;
            }
        }

        // Apply taxonomy categorization if migrated
        if ($migrated && class_exists('Poker_Tournament_Import_Taxonomies')) {
            $taxonomies = new Poker_Tournament_Import_Taxonomies();
            $taxonomies->auto_categorize_tournament($tournament_id, $tournament_data);
        }

        return $migrated;
    }

    /**
     * Find or create series post
     */
    private function find_or_create_series($series_name, $series_uuid = '') {
        // Try UUID first
        if (!empty($series_uuid)) {
            $args = array(
                'post_type' => 'tournament_series',
                'meta_query' => array(
                    array(
                        'key' => 'series_uuid',
                        'value' => $series_uuid,
                        'compare' => '='
                    )
                ),
                'posts_per_page' => 1
            );

            $existing = get_posts($args);
            if (!empty($existing)) {
                return $existing[0]->ID;
            }
        }

        // Try name next
        $args = array(
            'post_type' => 'tournament_series',
            'title' => $series_name,
            'posts_per_page' => 1
        );

        $existing = get_posts($args);
        if (!empty($existing)) {
            return $existing[0]->ID;
        }

        // Create new series
        $post_data = array(
            'post_title' => $series_name,
            'post_content' => '',
            'post_status' => 'publish',
            'post_type' => 'tournament_series'
        );

        $post_id = wp_insert_post($post_data);

        if ($post_id && !is_wp_error($post_id) && !empty($series_uuid)) {
            update_post_meta($post_id, 'series_uuid', $series_uuid);
        }

        return $post_id && !is_wp_error($post_id) ? $post_id : 0;
    }

    /**
     * Find or create season post
     */
    private function find_or_create_season($season_name, $season_uuid = '') {
        // Try UUID first
        if (!empty($season_uuid)) {
            $args = array(
                'post_type' => 'tournament_season',
                'meta_query' => array(
                    array(
                        'key' => 'season_uuid',
                        'value' => $season_uuid,
                        'compare' => '='
                    )
                ),
                'posts_per_page' => 1
            );

            $existing = get_posts($args);
            if (!empty($existing)) {
                return $existing[0]->ID;
            }
        }

        // Try name next
        $args = array(
            'post_type' => 'tournament_season',
            'title' => $season_name,
            'posts_per_page' => 1
        );

        $existing = get_posts($args);
        if (!empty($existing)) {
            return $existing[0]->ID;
        }

        // Create new season
        $post_data = array(
            'post_title' => $season_name,
            'post_content' => '',
            'post_status' => 'publish',
            'post_type' => 'tournament_season'
        );

        $post_id = wp_insert_post($post_data);

        if ($post_id && !is_wp_error($post_id) && !empty($season_uuid)) {
            update_post_meta($post_id, 'season_uuid', $season_uuid);
        }

        return $post_id && !is_wp_error($post_id) ? $post_id : 0;
    }

    /**
     * Verify tournament relationships
     */
    public function verify_relationships() {
        $args = array(
            'post_type' => 'tournament',
            'posts_per_page' => -1,
            'fields' => 'ids'
        );

        $all_tournaments = get_posts($args);
        $verification = array(
            'total' => count($all_tournaments),
            'has_series' => 0,
            'has_season' => 0,
            'has_both' => 0,
            'has_neither' => 0,
            'orphaned_series' => array(),
            'orphaned_seasons' => array()
        );

        foreach ($all_tournaments as $tournament_id) {
            $series_id = get_post_meta($tournament_id, '_series_id', true);
            $season_id = get_post_meta($tournament_id, '_season_id', true);

            if (!empty($series_id)) {
                $verification['has_series']++;
                if (!get_post($series_id)) {
                    $verification['orphaned_series'][] = $tournament_id;
                }
            }

            if (!empty($season_id)) {
                $verification['has_season']++;
                if (!get_post($season_id)) {
                    $verification['orphaned_seasons'][] = $tournament_id;
                }
            }

            if (!empty($series_id) && !empty($season_id)) {
                $verification['has_both']++;
            }

            if (empty($series_id) && empty($season_id)) {
                $verification['has_neither']++;
            }
        }

        return $verification;
    }

    /**
     * Handle migration actions from admin interface
     */
    public function handle_migration_actions() {
        if (!isset($_POST['poker_migration_action']) || !check_admin_referer('poker_migration_action', 'nonce')) {
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to perform this action.', 'poker-tournament-import'));
        }

        $action = sanitize_text_field($_POST['poker_migration_action']);

        switch ($action) {
            case 'migrate_all':
                $results = $this->migrate_tournament_relationships();
                $this->set_admin_notice('migration_results', $results);
                break;

            case 'migrate_single':
                $tournament_id = intval($_POST['tournament_id']);
                $results = $this->migrate_tournament_relationships($tournament_id);
                $this->set_admin_notice('single_migration_results', $results);
                break;

            case 'verify':
                $verification = $this->verify_relationships();
                $this->set_admin_notice('verification_results', $verification);
                break;
        }

        // Redirect to prevent form resubmission
        wp_safe_redirect(wp_get_referer());
        exit;
    }

    /**
     * Set admin notice for results display
     */
    private function set_admin_notice($key, $data) {
        set_transient('poker_migration_' . $key, $data, 60);
    }

    /**
     * Get admin notice data
     */
    public function get_admin_notice($key) {
        return get_transient('poker_migration_' . $key);
    }

    /**
     * Clear admin notice data
     */
    public function clear_admin_notice($key) {
        delete_transient('poker_migration_' . $key);
    }
}