<?php
/**
 * PDF Exporter for Tournament Manager
 *
 * Generates PDF tournament results using TCPDF
 *
 * @package Poker_Tournament_Import
 * @subpackage Tournament_Manager
 * @since 3.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class TDWP_PDF_Exporter {

	/**
	 * Generate PDF export
	 *
	 * @since 3.2.0
	 * @param int   $tournament_id Tournament ID.
	 * @param array $options Export options.
	 * @return array|WP_Error Export result
	 */
	public static function generate( $tournament_id, $options = array() ) {
		// Check memory limit
		$memory_limit = ini_get( 'memory_limit' );
		$memory_bytes = self::parse_memory_limit( $memory_limit );
		if ( $memory_bytes > 0 && $memory_bytes < 100 * 1024 * 1024 ) { // < 100MB
			return new WP_Error( 'insufficient_memory', __( 'Insufficient memory for PDF generation', 'poker-tournament-import' ) );
		}

		// Load TCPDF
		$tcpdf_path = POKER_TOURNAMENT_IMPORT_PLUGIN_DIR . 'vendor/tecnickcom/tcpdf/tcpdf.php';
		if ( ! file_exists( $tcpdf_path ) ) {
			return new WP_Error( 'tcpdf_missing', __( 'TCPDF library not found', 'poker-tournament-import' ) );
		}

		require_once $tcpdf_path;

		// Get tournament data
		global $wpdb;
		$players_table = $wpdb->prefix . 'tdwp_tournament_players';
		$players       = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT p.*, pm.display_name
				FROM {$players_table} p
				LEFT JOIN {$wpdb->prefix}tdwp_players pm ON p.player_id = pm.id
				WHERE p.tournament_id = %d
				ORDER BY p.finish_position ASC, p.chip_count DESC",
				$tournament_id
			)
		);

		// Create PDF
		$pdf = new TCPDF( PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false );
		$pdf->SetCreator( 'Tournament Manager' );
		$pdf->SetTitle( 'Tournament Results' );
		$pdf->SetMargins( 15, 15, 15 );
		$pdf->SetAutoPageBreak( true, 15 );
		$pdf->AddPage();

		// Build HTML
		$html = '<h1>Tournament Results</h1>';
		$html .= '<table border="1" cellpadding="4">';
		$html .= '<tr><th>Position</th><th>Player</th><th>Prize</th></tr>';

		foreach ( $players as $player ) {
			if ( $player->finish_position ) {
				$html .= sprintf(
					'<tr><td>%d</td><td>%s</td><td>$%.2f</td></tr>',
					$player->finish_position,
					esc_html( $player->display_name ),
					$player->prize_amount
				);
			}
		}

		$html .= '</table>';

		$pdf->writeHTML( $html, true, false, true, false, '' );

		// Save to temp file
		$upload_dir = wp_upload_dir();
		$filename   = sprintf( 'tournament-%d-%s.pdf', $tournament_id, time() );
		$file_path  = $upload_dir['basedir'] . '/tdwp-exports/' . $filename;

		// Create exports directory
		wp_mkdir_p( dirname( $file_path ) );

		$pdf->Output( $file_path, 'F' );

		TDWP_Export_Manager::schedule_cleanup( $file_path );

		return array(
			'success'      => true,
			'file_path'    => $file_path,
			'download_url' => $upload_dir['baseurl'] . '/tdwp-exports/' . $filename,
			'filename'     => $filename,
		);
	}

	/**
	 * Parse memory limit string to bytes
	 *
	 * @param string $limit Memory limit string.
	 * @return int Bytes
	 */
	private static function parse_memory_limit( $limit ) {
		$limit = trim( $limit );
		$last  = strtolower( $limit[ strlen( $limit ) - 1 ] );
		$limit = intval( $limit );

		switch ( $last ) {
			case 'g':
				$limit *= 1024;
			case 'm':
				$limit *= 1024;
			case 'k':
				$limit *= 1024;
		}

		return $limit;
	}
}
