<?php
/**
 * TD3 Integration: Display Manager
 *
 * Coordinates display system functionality for Tournament Director 3 integration.
 * Manages templates, layouts, screens, and token rendering for tournament displays.
 *
 * @package Poker_Tournament_Import
 * @subpackage Tournament_Manager
 * @since 3.4.0
 */

// Prevent direct file access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Display Manager Class
 *
 * Handles coordination of all display system components including:
 * - Template management and rendering
 * - Layout configuration and assignment
 * - Screen endpoint management
 * - Token processing and caching
 * - Multi-screen synchronization
 *
 * @since 3.4.0
 */
class TDWP_Display_Manager {

	/**
	 * Singleton instance
	 *
	 * @var TDWP_Display_Manager|null
	 */
	private static $instance = null;

	/**
	 * Template engine instance
	 *
	 * @var TDWP_Template_Engine|null
	 */
	private $template_engine = null;

	/**
	 * Layout builder instance
	 *
	 * @var TDWP_Layout_Builder|null
	 */
	private $layout_builder = null;

	/**
	 * Get singleton instance
	 *
	 * @since 3.4.0
	 * @return TDWP_Display_Manager
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 *
	 * @since 3.4.0
	 */
	private function __construct() {
		// Initialize dependencies when available
		add_action( 'init', array( $this, 'init_dependencies' ) );

		// Register AJAX handlers
		add_action( 'wp_ajax_tdwp_save_display_template', array( $this, 'ajax_save_display_template' ) );
		add_action( 'wp_ajax_tdwp_get_display_templates', array( $this, 'ajax_get_display_templates' ) );
		add_action( 'wp_ajax_tdwp_save_display_layout', array( $this, 'ajax_save_display_layout' ) );
		add_action( 'wp_ajax_tdwp_get_display_screens', array( $this, 'ajax_get_display_screens' ) );

		// Screen management AJAX handlers
		add_action( 'wp_ajax_tdwp_register_screen', array( $this, 'ajax_register_screen' ) );
		add_action( 'wp_ajax_tdwp_update_screen', array( $this, 'ajax_update_screen' ) );
		add_action( 'wp_ajax_tdwp_delete_screen', array( $this, 'ajax_delete_screen' ) );
		add_action( 'wp_ajax_tdwp_get_screen_health', array( $this, 'ajax_get_screen_health' ) );
		add_action( 'wp_ajax_tdwp_get_all_screens_health', array( $this, 'ajax_get_all_screens_health' ) );

		// Register display endpoint rewrite rules
		add_action( 'init', array( $this, 'register_display_endpoints' ) );
		add_filter( 'query_vars', array( $this, 'add_display_query_vars' ) );
		add_action( 'template_redirect', array( $this, 'handle_display_request' ) );

		// Initialize heartbeat synchronization
		add_action( 'init', array( $this, 'init_heartbeat_sync' ) );
	}

	/**
	 * Initialize dependencies
	 *
	 * @since 3.4.0
	 */
	public function init_dependencies() {
		// Load template engine if available
		if ( class_exists( 'TDWP_Template_Engine' ) ) {
			$this->template_engine = TDWP_Template_Engine::get_instance();
		}

		// Load layout builder if available
		if ( class_exists( 'TDWP_Layout_Builder' ) ) {
			$this->layout_builder = TDWP_Layout_Builder::get_instance();
		}
	}

	/**
	 * Register display endpoint rewrite rules
	 *
	 * @since 3.4.0
	 */
	public function register_display_endpoints() {
		// Main display endpoint
		add_rewrite_rule(
			'^tdwp-display/([^/]+)/?$',
			'index.php?tdwp_display=$matches[1]',
			'top'
		);

		// Tournament-specific display endpoints
		add_rewrite_rule(
			'^tdwp-display/tournament/([0-9]+)/([^/]+)/?$',
			'index.php?tdwp_tournament=$matches[1]&tdwp_display=$matches[2]',
			'top'
		);

		// Screen preview endpoints
		add_rewrite_rule(
			'^tdwp-preview/([^/]+)/?$',
			'index.php?tdwp_preview=$matches[1]',
			'top'
		);

		// Flush rewrite rules once
		if ( ! get_option( 'tdwp_display_endpoints_flushed' ) ) {
			flush_rewrite_rules();
			update_option( 'tdwp_display_endpoints_flushed', true );
		}
	}

	/**
	 * Add display query variables
	 *
	 * @since 3.4.0
	 * @param array $query_vars Existing query variables.
	 * @return array Modified query variables.
	 */
	public function add_display_query_vars( $query_vars ) {
		$query_vars[] = 'tdwp_display';
		$query_vars[] = 'tdwp_tournament';
		$query_vars[] = 'tdwp_preview';
		return $query_vars;
	}

	/**
	 * Handle display requests
	 *
	 * @since 3.4.0
	 */
	public function handle_display_request() {
		$display_id = get_query_var( 'tdwp_display' );
		$tournament_id = get_query_var( 'tdwp_tournament' );
		$preview_id = get_query_var( 'tdwp_preview' );

		// Handle preview requests
		if ( ! empty( $preview_id ) ) {
			$this->render_preview( $preview_id );
			exit;
		}

		// Handle tournament-specific display requests
		if ( ! empty( $display_id ) && ! empty( $tournament_id ) ) {
			$this->render_tournament_display( $display_id, $tournament_id );
			exit;
		}

		// Handle regular display requests
		if ( ! empty( $display_id ) ) {
			$this->render_display( $display_id );
			exit;
		}
	}

	/**
	 * Initialize heartbeat synchronization
	 *
	 * @since 3.4.0
	 */
	public function init_heartbeat_sync() {
		// Filter heartbeat data for display synchronization
		add_filter( 'heartbeat_received', array( $this, 'handle_heartbeat_sync' ), 10, 3 );
		add_filter( 'heartbeat_send', array( $this, 'prepare_heartbeat_data' ), 10, 2 );

		// Enqueue heartbeat scripts on display pages
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_display_scripts' ) );

		// Schedule periodic screen health checks
		add_action( 'tdwp_screen_health_check', array( $this, 'perform_screen_health_check' ) );

		if ( ! wp_next_scheduled( 'tdwp_screen_health_check' ) ) {
			wp_schedule_event( time(), 'tdwp_5min', 'tdwp_screen_health_check' );
		}

		// Add custom cron schedule for 5-minute intervals
		add_filter( 'cron_schedules', array( $this, 'add_custom_cron_schedules' ) );
	}

	/**
	 * Add custom cron schedules
	 *
	 * @since 3.4.0
	 * @param array $schedules Existing schedules.
	 * @return array Modified schedules.
	 */
	public function add_custom_cron_schedules( $schedules ) {
		$schedules['tdwp_5min'] = array(
			'interval' => 300, // 5 minutes
			'display'  => 'Every 5 minutes',
		);

		$schedules['tdwp_30sec'] = array(
			'interval' => 30, // 30 seconds
			'display'  => 'Every 30 seconds',
		);

		return $schedules;
	}

	/**
	 * Enqueue display scripts
	 *
	 * @since 3.4.0
	 */
	public function enqueue_display_scripts() {
		// Only enqueue on display pages
		if ( get_query_var( 'tdwp_display' ) || get_query_var( 'tdwp_preview' ) ) {
			wp_enqueue_script( 'heartbeat' );

			// Enqueue display synchronization script
			wp_enqueue_script(
				'tdwp-display-sync',
				plugin_dir_url( dirname( dirname( __FILE__ ) ) ) . '/assets/js/display-sync.js',
				array( 'jquery', 'heartbeat' ),
				'3.4.0',
				true
			);

			wp_localize_script( 'tdwp-display-sync', 'tdwp_display_sync', array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'tdwp_display_nonce' ),
				'screen_id' => get_query_var( 'tdwp_display' ),
				'heartbeat_interval' => 'fast',
			) );
		}
	}

	/**
	 * Prepare heartbeat data to send to client
	 *
	 * @since 3.4.0
	 * @param array $response Heartbeat response.
	 * @param array $screen_id Screen ID.
	 * @return array Modified response.
	 */
	public function prepare_heartbeat_data( $response, $screen_id ) {
		if ( ! $screen_id ) {
			return $response;
		}

		$display_id = get_query_var( 'tdwp_display' );
		$tournament_id = get_query_var( 'tdwp_tournament' );

		if ( $display_id ) {
			// Add current tournament state to heartbeat response
			if ( $tournament_id && $this->template_engine ) {
				$tournament_data = $this->template_engine->get_tournament_data( $tournament_id );
				$response['tdwp_tournament_state'] = $tournament_data;
			}

			// Add screen health status
			$response['tdwp_screen_health'] = $this->get_screen_health_by_endpoint( $display_id );

			// Add last updated timestamp
			$response['tdwp_last_updated'] = current_time( 'mysql' );
		}

		return $response;
	}

	/**
	 * Handle heartbeat synchronization
	 *
	 * @since 3.4.0
	 * @param array $response Heartbeat response.
	 * @param array $data Heartbeat data from client.
	 * @param int    $screen_id Screen ID.
	 * @return array Modified response.
	 */
	public function handle_heartbeat_sync( $response, $data, $screen_id ) {
		if ( empty( $data['tdwp_screen_id'] ) ) {
			return $response;
		}

		$screen_id = $data['tdwp_screen_id'];
		$display_id = $data['tdwp_display_id'] ?? '';

		// Update screen ping time
		$this->update_screen_status( $screen_id, array(
			'last_ping' => current_time( 'mysql' ),
			'is_online' => true,
		) );

		// Get updated tournament data if requested
		if ( ! empty( $data['tdwp_tournament_id'] ) ) {
			$tournament_id = intval( $data['tdwp_tournament_id'] );
			if ( $this->template_engine ) {
				$tournament_data = $this->template_engine->get_tournament_data( $tournament_id );
				$response['tdwp_tournament_data'] = $tournament_data;
			}
		}

		// Check if layout/template updates are needed
		if ( ! empty( $data['tdwp_check_updates'] ) ) {
			$updates = $this->check_for_screen_updates( $screen_id, $display_id );
			$response['tdwp_updates'] = $updates;
		}

		// Add synchronization status
		$response['tdwp_sync_status'] = array(
			'status' => 'connected',
			'last_sync' => current_time( 'mysql' ),
			'next_sync' => date( 'Y-m-d H:i:s', time() + 30 ),
		);

		return $response;
	}

	/**
	 * Get screen health by endpoint
	 *
	 * @since 3.4.0
	 * @param string $endpoint_url Endpoint URL.
	 * @return array Health status.
	 */
	public function get_screen_health_by_endpoint( $endpoint_url ) {
		$screen = $this->get_screen_by_endpoint( $endpoint_url );

		if ( ! $screen ) {
			return array(
				'status' => 'error',
				'message' => 'Screen not found',
				'online' => false,
			);
		}

		return $this->get_screen_health( $screen->screen_id );
	}

	/**
	 * Check for screen updates
	 *
	 * @since 3.4.0
	 * @param int    $screen_id Screen ID.
	 * @param string $display_id Display identifier.
	 * @return array Update information.
	 */
	public function check_for_screen_updates( $screen_id, $display_id ) {
		$updates = array(
			'layout_changed' => false,
			'template_changed' => false,
			'tournament_data_changed' => false,
		);

		$screen = $this->get_screen_status( $screen_id );
		if ( ! $screen ) {
			return $updates;
		}

		// Check if layout was updated since last client check
		if ( $screen->layout_id ) {
			$last_layout_update = get_post_modified_time( 'U', true, $screen->layout_id );
			$client_last_check = $screen->last_ping ? strtotime( $screen->last_ping ) : 0;

			$updates['layout_changed'] = $last_layout_update > $client_last_check;
		}

		// Check if template was updated
		if ( $screen->template_id ) {
			$last_template_update = get_post_modified_time( 'U', true, $screen->template_id );
			$client_last_check = $screen->last_ping ? strtotime( $screen->last_ping ) : 0;

			$updates['template_changed'] = $last_template_update > $client_last_check;
		}

		// Check tournament data changes
		$tournament_id = get_query_var( 'tdwp_tournament' );
		if ( $tournament_id ) {
			$last_tournament_update = get_post_modified_time( 'U', true, $tournament_id );
			$client_last_check = $screen->last_ping ? strtotime( $screen->last_ping ) : 0;

			$updates['tournament_data_changed'] = $last_tournament_update > $client_last_check;
		}

		return $updates;
	}

	/**
	 * Perform scheduled screen health check
	 *
	 * @since 3.4.0
	 */
	public function perform_screen_health_check() {
		global $wpdb;

		// Get all screens that haven't pinged in the last 5 minutes
		$stale_time = date( 'Y-m-d H:i:s', time() - 300 );

		$stale_screens = $wpdb->get_results( $wpdb->prepare(
			"SELECT screen_id, screen_name, endpoint_url, last_ping
			 FROM {$wpdb->prefix}poker_display_screens
			 WHERE last_ping < %s AND is_online = 1",
			$stale_time
		) );

		foreach ( $stale_screens as $screen ) {
			// Mark screen as offline
			$this->update_screen_status( $screen->screen_id, array(
				'is_online' => false,
			) );

			// Trigger action for offline screen
			do_action( 'tdwp_screen_went_offline', $screen->screen_id, $screen );
		}

		// Log health check results
		if ( ! empty( $stale_screens ) ) {
			error_log( "TDWP Display: Marked " . count( $stale_screens ) . " screens as offline due to stale ping" );
		}
	}

	/**
	 * Render display output
	 *
	 * @since 3.4.0
	 * @param string $display_id Display identifier.
	 */
	public function render_display( $display_id ) {
		global $wpdb;

		// Get screen configuration
		$screen = $wpdb->get_row( $wpdb->prepare(
			"SELECT s.*, t.html_template, t.css_styles, l.grid_config, l.component_positions
			 FROM {$wpdb->prefix}poker_display_screens s
			 LEFT JOIN {$wpdb->prefix}poker_display_templates t ON s.template_id = t.template_id
			 LEFT JOIN {$wpdb->prefix}poker_display_layouts l ON s.layout_id = l.layout_id
			 WHERE s.endpoint_url = %s OR s.screen_name = %s",
			$display_id, $display_id
		) );

		if ( ! $screen ) {
			wp_die( 'Display not found', 'Display Error', 404 );
		}

		// Update last ping
		$wpdb->update(
			$wpdb->prefix . 'poker_display_screens',
			array( 'last_ping' => current_time( 'mysql' ), 'is_online' => 1 ),
			array( 'screen_id' => $screen->screen_id ),
			array( '%s', '%d' ),
			array( '%d' )
		);

		// Render template if template engine is available
		if ( $this->template_engine && $screen->html_template ) {
			$rendered_content = $this->template_engine->render_template(
				$screen->html_template,
				$screen->tournament_id
			);

			// Apply layout if available
			if ( $this->layout_builder && $screen->grid_config ) {
				$rendered_content = $this->layout_builder->apply_layout(
					$rendered_content,
					$screen->grid_config,
					$screen->component_positions
				);
			}

			// Include styles if available
			if ( $screen->css_styles ) {
				echo '<style>' . $screen->css_styles . '</style>';
			}

			echo $rendered_content;
		} else {
			// Fallback display
			echo '<div class="tdwp-display-fallback">';
			echo '<h1>' . esc_html( $screen->screen_name ) . '</h1>';
			echo '<p>Display system is initializing...</p>';
			echo '</div>';
		}
	}

	/**
	 * Render tournament-specific display output
	 *
	 * @since 3.4.0
	 * @param string $display_id Display identifier.
	 * @param int    $tournament_id Tournament ID.
	 */
	public function render_tournament_display( $display_id, $tournament_id ) {
		global $wpdb;

		// Get screen configuration for tournament
		$screen = $wpdb->get_row( $wpdb->prepare(
			"SELECT s.*, t.html_template, t.css_styles, l.grid_config, l.component_positions
			 FROM {$wpdb->prefix}poker_display_screens s
			 LEFT JOIN {$wpdb->prefix}poker_display_templates t ON s.template_id = t.template_id AND t.tournament_id = %d
			 LEFT JOIN {$wpdb->prefix}poker_display_layouts l ON s.layout_id = l.layout_id AND l.tournament_id = %d
			 WHERE (s.endpoint_url = %s OR s.screen_name = %s)",
			$tournament_id, $tournament_id, $display_id, $display_id
		) );

		if ( ! $screen ) {
			wp_die( 'Display not found for tournament', 'Display Error', 404 );
		}

		// Update last ping
		$wpdb->update(
			$wpdb->prefix . 'poker_display_screens',
			array( 'last_ping' => current_time( 'mysql' ), 'is_online' => 1 ),
			array( 'screen_id' => $screen->screen_id ),
			array( '%s', '%d' ),
			array( '%d' )
		);

		// Set headers for proper display
		header( 'Content-Type: text/html; charset=UTF-8' );
		header( 'Cache-Control: no-cache, no-store, must-revalidate' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );

		// Render template with tournament context
		if ( $this->template_engine && $screen->html_template ) {
			$rendered_content = $this->template_engine->render_template(
				$screen->html_template,
				$tournament_id
			);

			// Apply layout if available
			if ( $this->layout_builder && $screen->grid_config ) {
				$layout_config = json_decode( $screen->grid_config, true );
				$component_positions = json_decode( $screen->component_positions, true );
				$rendered_content = $this->layout_builder->apply_layout(
					$rendered_content,
					$layout_config,
					$component_positions
				);
			}

			// Include styles if available
			if ( $screen->css_styles ) {
				echo '<style>' . $screen->css_styles . '</style>';
			}

			echo $rendered_content;
		} else {
			// Fallback tournament display
			$tournament = get_post( $tournament_id );
			echo '<div class="tdwp-display tdwp-tournament-display" style="font-family: Arial, sans-serif; text-align: center; padding: 20px;">';
			echo '<h1>' . esc_html( $tournament ? $tournament->post_title : 'Tournament Display' ) . '</h1>';
			echo '<p>Tournament display is initializing...</p>';
			echo '</div>';
		}
	}

	/**
	 * Render preview display output
	 *
	 * @since 3.4.0
	 * @param string $preview_id Preview identifier.
	 */
	public function render_preview( $preview_id ) {
		// Parse preview ID to extract screen_id and tournament_id
		$preview_parts = explode( '-', $preview_id );
		$screen_id = isset( $preview_parts[0] ) ? intval( $preview_parts[0] ) : 0;
		$tournament_id = isset( $preview_parts[1] ) ? intval( $preview_parts[1] ) : 0;

		if ( ! $screen_id || ! $tournament_id ) {
			wp_die( 'Invalid preview parameters', 'Preview Error', 400 );
		}

		global $wpdb;

		// Get screen configuration
		$screen = $wpdb->get_row( $wpdb->prepare(
			"SELECT s.*, t.html_template, t.css_styles, l.grid_config, l.component_positions
			 FROM {$wpdb->prefix}poker_display_screens s
			 LEFT JOIN {$wpdb->prefix}poker_display_templates t ON s.template_id = t.template_id AND t.tournament_id = %d
			 LEFT JOIN {$wpdb->prefix}poker_display_layouts l ON s.layout_id = l.layout_id AND l.tournament_id = %d
			 WHERE s.screen_id = %d",
			$tournament_id, $tournament_id, $screen_id
		) );

		if ( ! $screen ) {
			wp_die( 'Preview not found', 'Preview Error', 404 );
		}

		// Set headers for preview
		header( 'Content-Type: text/html; charset=UTF-8' );
		header( 'Cache-Control: no-cache, no-store, must-revalidate' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );
		header( 'X-Preview-Mode: active' );

		// Render preview with layout builder if available
		if ( $this->layout_builder && $screen->layout_id ) {
			$preview = $this->layout_builder->create_preview( $screen->layout_id, $tournament_id, array(
				'show_grid' => true,
				'live_data' => true,
				'auto_refresh' => false, // Disable auto-refresh for preview
			) );

			if ( $preview ) {
				echo '<div class="tdwp-preview-wrapper">';
				echo '<style>' . $preview['css'] . '</style>';
				echo $preview['html'];
				echo '<script>';
				echo 'window.addEventListener("load", function() {';
				echo '  console.log("TDWP Preview loaded for ' . esc_js( $screen->screen_name ) . '");';
				echo '});';
				echo '</script>';
				echo '</div>';
				return;
			}
		}

		// Fallback preview
		echo '<div class="tdwp-preview-fallback" style="font-family: Arial, sans-serif; text-align: center; padding: 20px; border: 2px dashed #ccc;">';
		echo '<h2>Preview: ' . esc_html( $screen->screen_name ) . '</h2>';
		echo '<p>Preview mode is not available for this configuration.</p>';
		echo '</div>';
	}

	/**
	 * Save display template via AJAX
	 *
	 * @since 3.4.0
	 */
	public function ajax_save_display_template() {
		// Verify nonce and capabilities
		if ( ! check_ajax_referer( 'tdwp_display_nonce', 'nonce' ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Security check failed' );
		}

		$template_data = json_decode( stripslashes( $_POST['template_data'] ), true );

		if ( ! $template_data ) {
			wp_send_json_error( 'Invalid template data' );
		}

		global $wpdb;

		$result = $wpdb->insert(
			$wpdb->prefix . 'poker_display_templates',
			array(
				'tournament_id' => isset( $template_data['tournament_id'] ) ? intval( $template_data['tournament_id'] ) : null,
				'template_name' => sanitize_text_field( $template_data['template_name'] ),
				'template_type' => in_array( $template_data['template_type'], array( 'clock', 'rankings', 'prizes', 'seating', 'rules', 'custom' ) ) ? $template_data['template_type'] : 'custom',
				'html_template' => wp_kses_post( $template_data['html_template'] ),
				'css_styles' => wp_kses_post( $template_data['css_styles'] ),
				'tokens_used' => json_encode( $template_data['tokens_used'] ?? array() ),
				'is_default' => isset( $template_data['is_default'] ) ? (bool) $template_data['is_default'] : false,
			),
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%d' )
		);

		if ( $result ) {
			wp_send_json_success( array( 'template_id' => $wpdb->insert_id ) );
		} else {
			wp_send_json_error( 'Failed to save template' );
		}
	}

	/**
	 * Get display templates via AJAX
	 *
	 * @since 3.4.0
	 */
	public function ajax_get_display_templates() {
		// Verify nonce and capabilities
		if ( ! check_ajax_referer( 'tdwp_display_nonce', 'nonce' ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Security check failed' );
		}

		$tournament_id = isset( $_GET['tournament_id'] ) ? intval( $_GET['tournament_id'] ) : 0;
		$template_type = isset( $_GET['template_type'] ) ? sanitize_text_field( $_GET['template_type'] ) : '';

		global $wpdb;

		$where = array();
		$where_sql = '';

		if ( $tournament_id > 0 ) {
			$where[] = $wpdb->prepare( 'tournament_id = %d', $tournament_id );
		}

		if ( ! empty( $template_type ) ) {
			$where[] = $wpdb->prepare( 'template_type = %s', $template_type );
		}

		if ( ! empty( $where ) ) {
			$where_sql = 'WHERE ' . implode( ' AND ', $where );
		}

		$templates = $wpdb->get_results(
			"SELECT * FROM {$wpdb->prefix}poker_display_templates {$where_sql} ORDER BY template_name"
		);

		wp_send_json_success( $templates );
	}

	/**
	 * Save display layout via AJAX
	 *
	 * @since 3.4.0
	 */
	public function ajax_save_display_layout() {
		// Verify nonce and capabilities
		if ( ! check_ajax_referer( 'tdwp_display_nonce', 'nonce' ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Security check failed' );
		}

		$layout_data = json_decode( stripslashes( $_POST['layout_data'] ), true );

		if ( ! $layout_data ) {
			wp_send_json_error( 'Invalid layout data' );
		}

		global $wpdb;

		$result = $wpdb->insert(
			$wpdb->prefix . 'poker_display_layouts',
			array(
				'tournament_id' => intval( $layout_data['tournament_id'] ),
				'layout_name' => sanitize_text_field( $layout_data['layout_name'] ),
				'screen_size' => sanitize_text_field( $layout_data['screen_size'] ?? '' ),
				'grid_config' => json_encode( $layout_data['grid_config'] ?? array() ),
				'component_positions' => json_encode( $layout_data['component_positions'] ?? array() ),
				'breakpoints' => json_encode( $layout_data['breakpoints'] ?? array() ),
				'is_active' => isset( $layout_data['is_active'] ) ? (bool) $layout_data['is_active'] : true,
			),
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%d' )
		);

		if ( $result ) {
			wp_send_json_success( array( 'layout_id' => $wpdb->insert_id ) );
		} else {
			wp_send_json_error( 'Failed to save layout' );
		}
	}

	/**
	 * Get display screens via AJAX
	 *
	 * @since 3.4.0
	 */
	public function ajax_get_display_screens() {
		// Verify nonce and capabilities
		if ( ! check_ajax_referer( 'tdwp_display_nonce', 'nonce' ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Security check failed' );
		}

		global $wpdb;

		$screens = $wpdb->get_results(
			"SELECT s.*, t.template_name, l.layout_name
			 FROM {$wpdb->prefix}poker_display_screens s
			 LEFT JOIN {$wpdb->prefix}poker_display_templates t ON s.template_id = t.template_id
			 LEFT JOIN {$wpdb->prefix}poker_display_layouts l ON s.layout_id = l.layout_id
			 ORDER BY s.screen_name"
		);

		wp_send_json_success( $screens );
	}

	/**
	 * Get screen status
	 *
	 * @since 3.4.0
	 * @param int $screen_id Screen ID.
	 * @return object|null Screen status data.
	 */
	public function get_screen_status( $screen_id ) {
		global $wpdb;

		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}poker_display_screens WHERE screen_id = %d",
			$screen_id
		) );
	}

	/**
	 * Update screen status
	 *
	 * @since 3.4.0
	 * @param int    $screen_id Screen ID.
	 * @param array  $status_data Status data to update.
	 * @return bool Success status.
	 */
	public function update_screen_status( $screen_id, $status_data ) {
		global $wpdb;

		$allowed_fields = array( 'last_ping', 'is_online', 'location' );
		$update_data = array();
		$format = array();

		foreach ( $status_data as $field => $value ) {
			if ( in_array( $field, $allowed_fields ) ) {
				$update_data[ $field ] = $value;
				$format[] = is_bool( $value ) ? '%d' : '%s';
			}
		}

		if ( empty( $update_data ) ) {
			return false;
		}

		return (bool) $wpdb->update(
			$wpdb->prefix . 'poker_display_screens',
			$update_data,
			array( 'screen_id' => $screen_id ),
			$format,
			array( '%d' )
		);
	}

	/**
	 * Register new display screen
	 *
	 * @since 3.4.0
	 * @param array $screen_data Screen configuration data.
	 * @return int|false Screen ID or false on failure.
	 */
	public function register_screen( $screen_data ) {
		global $wpdb;

		$screen_data = wp_parse_args( $screen_data, array(
			'screen_name' => '',
			'endpoint_url' => '',
			'screen_type' => 'custom',
			'location' => '',
			'tournament_id' => 0,
			'layout_id' => null,
			'template_id' => null,
		) );

		// Validate required fields
		if ( empty( $screen_data['screen_name'] ) || empty( $screen_data['endpoint_url'] ) ) {
			return false;
		}

		// Generate unique endpoint URL if not provided
		if ( empty( $screen_data['endpoint_url'] ) ) {
			$screen_data['endpoint_url'] = $this->generate_unique_endpoint( $screen_data['screen_name'] );
		}

		// Validate endpoint uniqueness
		$existing = $wpdb->get_var( $wpdb->prepare(
			"SELECT screen_id FROM {$wpdb->prefix}poker_display_screens WHERE endpoint_url = %s",
			$screen_data['endpoint_url']
		) );

		if ( $existing ) {
			return false;
		}

		// Insert new screen
		$result = $wpdb->insert(
			$wpdb->prefix . 'poker_display_screens',
			array(
				'screen_name' => sanitize_text_field( $screen_data['screen_name'] ),
				'endpoint_url' => sanitize_text_field( $screen_data['endpoint_url'] ),
				'screen_type' => in_array( $screen_data['screen_type'], array( 'clock', 'rankings', 'prizes', 'seating', 'custom' ) ) ? $screen_data['screen_type'] : 'custom',
				'location' => sanitize_text_field( $screen_data['location'] ),
				'layout_id' => ! empty( $screen_data['layout_id'] ) ? intval( $screen_data['layout_id'] ) : null,
				'template_id' => ! empty( $screen_data['template_id'] ) ? intval( $screen_data['template_id'] ) : null,
				'is_online' => 0,
				'created_at' => current_time( 'mysql' ),
				'updated_at' => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%s', '%s' )
		);

		if ( ! $result ) {
			return false;
		}

		$screen_id = $wpdb->insert_id;

		// Trigger registration action
		do_action( 'tdwp_screen_registered', $screen_id, $screen_data );

		return $screen_id;
	}

	/**
	 * Update screen configuration
	 *
	 * @since 3.4.0
	 * @param int   $screen_id Screen ID.
	 * @param array $screen_data Updated screen data.
	 * @return bool Success status.
	 */
	public function update_screen( $screen_id, $screen_data ) {
		global $wpdb;

		$allowed_fields = array(
			'screen_name', 'endpoint_url', 'screen_type', 'location',
			'layout_id', 'template_id', 'is_online'
		);

		$update_data = array();
		$format = array();

		foreach ( $screen_data as $field => $value ) {
			if ( in_array( $field, $allowed_fields ) ) {
				switch ( $field ) {
					case 'screen_name':
					case 'endpoint_url':
					case 'location':
						$update_data[ $field ] = sanitize_text_field( $value );
						$format[] = '%s';
						break;
					case 'screen_type':
						$update_data[ $field ] = in_array( $value, array( 'clock', 'rankings', 'prizes', 'seating', 'custom' ) ) ? $value : 'custom';
						$format[] = '%s';
						break;
					case 'layout_id':
					case 'template_id':
						$update_data[ $field ] = ! empty( $value ) ? intval( $value ) : null;
						$format[] = '%d';
						break;
					case 'is_online':
						$update_data[ $field ] = (bool) $value;
						$format[] = '%d';
						break;
				}
			}
		}

		if ( empty( $update_data ) ) {
			return false;
		}

		$update_data['updated_at'] = current_time( 'mysql' );
		$format[] = '%s';

		$result = $wpdb->update(
			$wpdb->prefix . 'poker_display_screens',
			$update_data,
			array( 'screen_id' => $screen_id ),
			$format,
			array( '%d' )
		);

		if ( $result !== false ) {
			// Trigger update action
			do_action( 'tdwp_screen_updated', $screen_id, $update_data );
		}

		return $result !== false;
	}

	/**
	 * Delete screen
	 *
	 * @since 3.4.0
	 * @param int $screen_id Screen ID.
	 * @return bool Success status.
	 */
	public function delete_screen( $screen_id ) {
		global $wpdb;

		$screen = $this->get_screen_status( $screen_id );
		if ( ! $screen ) {
			return false;
		}

		$result = $wpdb->delete(
			$wpdb->prefix . 'poker_display_screens',
			array( 'screen_id' => $screen_id ),
			array( '%d' )
		);

		if ( $result !== false ) {
			// Trigger deletion action
			do_action( 'tdwp_screen_deleted', $screen_id, $screen );
		}

		return $result !== false;
	}

	/**
	 * Get all screens for a tournament
	 *
	 * @since 3.4.0
	 * @param int $tournament_id Tournament ID.
	 * @return array List of screens.
	 */
	public function get_tournament_screens( $tournament_id ) {
		global $wpdb;

		return $wpdb->get_results( $wpdb->prepare(
			"SELECT s.*, t.template_name, l.layout_name
			 FROM {$wpdb->prefix}poker_display_screens s
			 LEFT JOIN {$wpdb->prefix}poker_display_templates t ON s.template_id = t.template_id AND t.tournament_id = %d
			 LEFT JOIN {$wpdb->prefix}poker_display_layouts l ON s.layout_id = l.layout_id AND l.tournament_id = %d
			 WHERE 1=1
			 ORDER BY s.screen_name",
			$tournament_id, $tournament_id
		) );
	}

	/**
	 * Get all registered screens
	 *
	 * @since 3.4.0
	 * @param array $args Query arguments.
	 * @return array List of screens.
	 */
	public function get_all_screens( $args = array() ) {
		global $wpdb;

		$defaults = array(
			'online_only' => false,
			'screen_type' => '',
			'orderby' => 'screen_name',
			'order' => 'ASC',
		);

		$args = wp_parse_args( $args, $defaults );

		$where_clauses = array( '1=1' );
		$joins = array(
			"LEFT JOIN {$wpdb->prefix}poker_display_templates t ON s.template_id = t.template_id",
			"LEFT JOIN {$wpdb->prefix}poker_display_layouts l ON s.layout_id = l.layout_id"
		);

		if ( $args['online_only'] ) {
			$where_clauses[] = 's.is_online = 1';
		}

		if ( ! empty( $args['screen_type'] ) ) {
			$where_clauses[] = $wpdb->prepare( 's.screen_type = %s', $args['screen_type'] );
		}

		$where_sql = implode( ' AND ', $where_clauses );
		$join_sql = implode( ' ', $joins );
		$order_sql = sanitize_sql_orderby( $args['orderby'] . ' ' . $args['order'] );

		$sql = "SELECT s.*, t.template_name, l.layout_name
				FROM {$wpdb->prefix}poker_display_screens s
				{$join_sql}
				WHERE {$where_sql}
				ORDER BY {$order_sql}";

		return $wpdb->get_results( $sql );
	}

	/**
	 * Generate unique endpoint URL
	 *
	 * @since 3.4.0
	 * @param string $screen_name Screen name.
	 * @return string Unique endpoint URL.
	 */
	private function generate_unique_endpoint( $screen_name ) {
		global $wpdb;

		$base = sanitize_title( $screen_name );
		$endpoint = $base;
		$counter = 1;

		while ( $wpdb->get_var( $wpdb->prepare(
			"SELECT screen_id FROM {$wpdb->prefix}poker_display_screens WHERE endpoint_url = %s",
			$endpoint
		) ) ) {
			$endpoint = $base . '-' . $counter;
			$counter++;
		}

		return $endpoint;
	}

	/**
	 * Get screen by endpoint URL
	 *
	 * @since 3.4.0
	 * @param string $endpoint_url Endpoint URL.
	 * @return object|null Screen data.
	 */
	public function get_screen_by_endpoint( $endpoint_url ) {
		global $wpdb;

		return $wpdb->get_row( $wpdb->prepare(
			"SELECT s.*, t.template_name, l.layout_name, t.html_template, t.css_styles, l.layout_data
			 FROM {$wpdb->prefix}poker_display_screens s
			 LEFT JOIN {$wpdb->prefix}poker_display_templates t ON s.template_id = t.template_id
			 LEFT JOIN {$wpdb->prefix}poker_display_layouts l ON s.layout_id = l.layout_id
			 WHERE s.endpoint_url = %s",
			$endpoint_url
		) );
	}

	/**
	 * Assign layout to screen
	 *
	 * @since 3.4.0
	 * @param int $screen_id Screen ID.
	 * @param int $layout_id Layout ID.
	 * @return bool Success status.
	 */
	public function assign_layout_to_screen( $screen_id, $layout_id ) {
		return $this->update_screen( $screen_id, array( 'layout_id' => $layout_id ) );
	}

	/**
	 * Assign template to screen
	 *
	 * @since 3.4.0
	 * @param int $screen_id Screen ID.
	 * @param int $template_id Template ID.
	 * @return bool Success status.
	 */
	public function assign_template_to_screen( $screen_id, $template_id ) {
		return $this->update_screen( $screen_id, array( 'template_id' => $template_id ) );
	}

	/**
	 * Get screen health status
	 *
	 * @since 3.4.0
	 * @param int $screen_id Screen ID.
	 * @return array Health status information.
	 */
	public function get_screen_health( $screen_id ) {
		$screen = $this->get_screen_status( $screen_id );

		if ( ! $screen ) {
			return array(
				'status' => 'error',
				'message' => 'Screen not found',
				'online' => false,
				'last_ping' => null,
				'connection_quality' => 'unknown',
			);
		}

		$health = array(
			'status' => 'healthy',
			'message' => 'Screen is online and responding',
			'online' => (bool) $screen->is_online,
			'last_ping' => $screen->last_ping,
			'connection_quality' => 'unknown',
		);

		// Check if screen is offline
		if ( ! $screen->is_online ) {
			$health['status'] = 'offline';
			$health['message'] = 'Screen is offline';
			$health['connection_quality'] = 'poor';
		}

		// Check last ping time
		if ( $screen->last_ping ) {
			$time_diff = time() - strtotime( $screen->last_ping );

			if ( $time_diff > 300 ) { // 5 minutes
				$health['status'] = 'stale';
				$health['message'] = 'Screen has not responded recently';
				$health['connection_quality'] = 'poor';
			} elseif ( $time_diff > 60 ) { // 1 minute
				$health['status'] = 'warning';
				$health['message'] = 'Screen response delayed';
				$health['connection_quality'] = 'fair';
			} else {
				$health['connection_quality'] = 'good';
			}
		} else {
			$health['status'] = 'warning';
			$health['message'] = 'Screen has never responded';
			$health['connection_quality'] = 'unknown';
		}

		return apply_filters( 'tdwp_screen_health_status', $health, $screen_id );
	}

	/**
	 * Get all screens health status
	 *
	 * @since 3.4.0
	 * @return array All screens health information.
	 */
	public function get_all_screens_health() {
		$screens = $this->get_all_screens();
		$health_data = array();

		foreach ( $screens as $screen ) {
			$health_data[ $screen->screen_id ] = $this->get_screen_health( $screen->screen_id );
		}

		return $health_data;
	}

	/**
	 * Get aggregated system health status
	 *
	 * @since 3.4.1
	 * @return array Aggregated health status information for admin interface.
	 */
	public function get_system_health_status() {
		$screens = $this->get_all_screens();
		$individual_health = $this->get_all_screens_health();

		$total_screens = count( $screens );
		$online_screens = 0;
		$total_quality = 0;
		$quality_counts = array(
			'excellent' => 0,
			'good' => 0,
			'fair' => 0,
			'poor' => 0
		);

		foreach ( $individual_health as $health ) {
			// Check online status (fix key name inconsistency)
			if ( isset( $health['online'] ) && $health['online'] ) {
				$online_screens++;
			} elseif ( isset( $health['is_online'] ) && $health['is_online'] ) {
				$online_screens++;
			}

			if ( isset( $health['connection_quality'] ) ) {
				// Convert string quality to numeric value
				$quality_numeric = $this->convert_quality_to_numeric( $health['connection_quality'] );
				$total_quality += $quality_numeric;

				// Categorize quality by string value
				if ( $health['connection_quality'] === 'good' ) {
					$quality_counts['excellent']++; // Good counts as excellent in this context
				} elseif ( $health['connection_quality'] === 'fair' ) {
					$quality_counts['good']++;
				} elseif ( $health['connection_quality'] === 'poor' ) {
					$quality_counts['fair']++;
				} else {
					$quality_counts['poor']++; // unknown and other poor qualities
				}
			}
		}

		$avg_quality = $total_screens > 0 ? round( $total_quality / $total_screens ) : 0;

		// Calculate quality breakdown percentages
		$quality_breakdown = array();
		foreach ( $quality_counts as $quality => $count ) {
			$quality_breakdown[ $quality ] = $total_screens > 0 ? round( ( $count / $total_screens ) * 100 ) : 0;
		}

		// Determine overall system health
		$system_health = 'healthy';
		if ( $total_screens === 0 ) {
			$system_health = 'warning'; // No screens configured
		} elseif ( $online_screens === 0 ) {
			$system_health = 'error'; // All screens offline
		} elseif ( $online_screens < $total_screens * 0.5 ) {
			$system_health = 'warning'; // Less than 50% online
		}

		return array(
			'system_health' => $system_health,
			'total_screens' => $total_screens,
			'online_screens' => $online_screens,
			'avg_connection_quality' => $avg_quality,
			'quality_breakdown' => $quality_breakdown,
			'heartbeat_active' => class_exists( 'TDWP_Heartbeat_Manager' ),
			'rewrite_rules_active' => get_option( 'tdwp_rewrite_rules_flushed', false ),
			'shortcodes_registered' => shortcode_exists( 'tdwp_tournament_display' )
		);
	}

	/**
	 * Convert string quality rating to numeric value
	 *
	 * @since 3.4.1
	 * @param string $quality String quality rating.
	 * @return int Numeric quality value (0-100).
	 */
	private function convert_quality_to_numeric( $quality ) {
		$quality_map = array(
			'good' => 95,
			'fair' => 65,
			'poor' => 25,
			'unknown' => 0,
			'excellent' => 100,
		);

		return isset( $quality_map[ $quality ] ) ? $quality_map[ $quality ] : 0;
	}

	/**
	 * AJAX handler for screen registration
	 *
	 * @since 3.4.0
	 */
	public function ajax_register_screen() {
		// Verify nonce and capabilities
		if ( ! check_ajax_referer( 'tdwp_display_nonce', 'nonce' ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Security check failed' );
		}

		$screen_data = json_decode( stripslashes( $_POST['screen_data'] ), true );

		if ( ! $screen_data ) {
			wp_send_json_error( 'Invalid screen data' );
		}

		$screen_id = $this->register_screen( $screen_data );

		if ( ! $screen_id ) {
			wp_send_json_error( 'Failed to register screen' );
		}

		wp_send_json_success( array(
			'screen_id' => $screen_id,
			'message' => 'Screen registered successfully',
		) );
	}

	/**
	 * AJAX handler for screen update
	 *
	 * @since 3.4.0
	 */
	public function ajax_update_screen() {
		// Verify nonce and capabilities
		if ( ! check_ajax_referer( 'tdwp_display_nonce', 'nonce' ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Security check failed' );
		}

		$screen_id = intval( $_POST['screen_id'] );
		$screen_data = json_decode( stripslashes( $_POST['screen_data'] ), true );

		if ( ! $screen_data ) {
			wp_send_json_error( 'Invalid screen data' );
		}

		$success = $this->update_screen( $screen_id, $screen_data );

		if ( ! $success ) {
			wp_send_json_error( 'Failed to update screen' );
		}

		wp_send_json_success( array(
			'message' => 'Screen updated successfully',
		) );
	}

	/**
	 * AJAX handler for screen deletion
	 *
	 * @since 3.4.0
	 */
	public function ajax_delete_screen() {
		// Verify nonce and capabilities
		if ( ! check_ajax_referer( 'tdwp_display_nonce', 'nonce' ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Security check failed' );
		}

		$screen_id = intval( $_POST['screen_id'] );

		$success = $this->delete_screen( $screen_id );

		if ( ! $success ) {
			wp_send_json_error( 'Failed to delete screen' );
		}

		wp_send_json_success( array(
			'message' => 'Screen deleted successfully',
		) );
	}

	/**
	 * AJAX handler for getting screen health status
	 *
	 * @since 3.4.0
	 */
	public function ajax_get_screen_health() {
		// Verify nonce and capabilities
		if ( ! check_ajax_referer( 'tdwp_display_nonce', 'nonce' ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Security check failed' );
		}

		$screen_id = intval( $_POST['screen_id'] );
		$health = $this->get_screen_health( $screen_id );

		wp_send_json_success( $health );
	}

	/**
	 * AJAX handler for getting all screens health status
	 *
	 * @since 3.4.0
	 */
	public function ajax_get_all_screens_health() {
		// Verify nonce and capabilities
		if ( ! check_ajax_referer( 'tdwp_display_nonce', 'nonce' ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Security check failed' );
		}

		$health_data = $this->get_all_screens_health();

		wp_send_json_success( $health_data );
	}

	/**
	 * Get currently running tournaments for display assignment
	 *
	 * @since 3.4.1
	 * @return array Array of running tournaments with basic info
	 */
	public function get_running_tournaments_for_display() {
		if ( ! class_exists( 'TDWP_Active_Tournament_Manager' ) ) {
			return array();
		}

		$running_tournaments = TDWP_Active_Tournament_Manager::get_running_tournaments();
		$tournaments = array();

		foreach ( $running_tournaments as $tournament ) {
			// Get tournament status from live state
			$status = $this->get_tournament_live_status( $tournament->ID );

			$tournaments[] = array(
				'id' => $tournament->ID,
				'title' => $tournament->post_title,
				'status' => $status,
				'is_running' => in_array( $status, array( 'running', 'paused', 'break' ) ),
				'live_tournament_id' => get_post_meta( $tournament->ID, '_live_tournament_id', true ),
			);
		}

		return $tournaments;
	}

	/**
	 * Get tournament live status
	 *
	 * @since 3.4.1
	 * @param int $tournament_id Tournament ID.
	 * @return string Tournament status
	 */
	private function get_tournament_live_status( $tournament_id ) {
		if ( ! class_exists( 'TDWP_Tournament_Live' ) ) {
			return 'unknown';
		}

		$live_manager = TDWP_Tournament_Live::get_instance();
		$live_state = $live_manager->get_by_tournament_id( $tournament_id );

		if ( $live_state ) {
			return $live_state->status;
		}

		// Check tournament meta as fallback
		$status = get_post_meta( $tournament_id, '_status', true );
		return $status ?: 'pending';
	}

	/**
	 * Auto-assign screens to running tournaments
	 *
	 * @since 3.4.1
	 * @param int $screen_id Screen ID to auto-assign.
	 * @return bool True on success
	 */
	public function auto_assign_to_running_tournament( $screen_id ) {
		$running_tournaments = $this->get_running_tournaments_for_display();

		if ( empty( $running_tournaments ) ) {
			return false;
		}

		// Prefer currently running tournaments over paused/break
		foreach ( $running_tournaments as $tournament ) {
			if ( $tournament['is_running'] && $tournament['status'] === 'running' ) {
				return $this->update_screen( $screen_id, array(
					'tournament_id' => $tournament['id']
				) );
			}
		}

		// If no running tournament, use the first available one
		$first_tournament = reset( $running_tournaments );
		return $this->update_screen( $screen_id, array(
			'tournament_id' => $first_tournament['id']
		) );
	}

	/**
	 * Get active tournament for current user
	 *
	 * @since 3.4.1
	 * @return int|false Tournament ID or false if none
	 */
	public function get_user_active_tournament() {
		if ( ! class_exists( 'TDWP_Active_Tournament_Manager' ) ) {
			return false;
		}

		$user_id = get_current_user_id();
		if ( ! $user_id || ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		return TDWP_Active_Tournament_Manager::get_active_tournament( $user_id );
	}

	/**
	 * Update screen when tournament status changes
	 *
	 * @since 3.4.1
	 * @param int $tournament_id Tournament ID.
	 * @param string $old_status Previous tournament status.
	 * @param string $new_status New tournament status.
	 * @return bool True on success
	 */
	public function handle_tournament_status_change( $tournament_id, $old_status, $new_status ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'poker_display_screens';

		// Get all screens assigned to this tournament
		$screens = $wpdb->get_results( $wpdb->prepare(
			"SELECT screen_id FROM {$table_name} WHERE tournament_id = %d",
			$tournament_id
		) );

		foreach ( $screens as $screen ) {
			// Update screen's last activity and health status
			$this->update_screen_health( $screen->screen_id, array(
				'tournament_status' => $new_status,
				'timestamp' => current_time( 'mysql' )
			) );

			// Trigger display refresh for connected screens
			do_action( 'tdwp_tournament_status_changed', $tournament_id, $old_status, $new_status, $screen->screen_id );
		}

		return true;
	}

	/**
	 * Get tournament options for screen assignment dropdown
	 *
	 * @since 3.4.1
	 * @return array Formatted options for select dropdown
	 */
	public function get_tournament_options_for_screens() {
		$tournaments = $this->get_running_tournaments_for_display();
		$options = array();

		// Add "Auto-detect running tournament" option
		$options[] = array(
			'id' => 'auto',
			'title' => __( 'Auto-detect running tournament', 'poker-tournament-import' ),
			'description' => __( 'Automatically connect to the currently running tournament', 'poker-tournament-import' ),
			'status' => 'auto'
		);

		// Add manual tournament options
		foreach ( $tournaments as $tournament ) {
			$status_label = ucfirst( $tournament['status'] );
			$description = sprintf(
				__( '%s - %s', 'poker-tournament-import' ),
				$tournament['title'],
				$status_label
			);

			$options[] = array(
				'id' => $tournament['id'],
				'title' => $tournament['title'],
				'description' => $description,
				'status' => $tournament['status'],
				'is_running' => $tournament['is_running']
			);
		}

		return $options;
	}

	/**
	 * AJAX handler for getting tournament options
	 *
	 * @since 3.4.1
	 */
	public function ajax_get_tournament_options() {
		check_ajax_referer( 'tdwp_display_nonce', 'nonce' );
		current_user_can( 'manage_options' ) || wp_die( 'Security check failed' );

		$options = $this->get_tournament_options_for_screens();

		wp_send_json_success( array(
			'options' => $options
		) );
	}

	/**
	 * AJAX handler for auto-assigning screen to running tournament
	 *
	 * @since 3.4.1
	 */
	public function ajax_auto_assign_screen() {
		check_ajax_referer( 'tdwp_display_nonce', 'nonce' );
		current_user_can( 'manage_options' ) || wp_die( 'Security check failed' );

		$screen_id = intval( $_POST['screen_id'] );
		if ( ! $screen_id ) {
			wp_send_json_error( 'Invalid screen ID' );
		}

		$result = $this->auto_assign_to_running_tournament( $screen_id );

		if ( $result ) {
			wp_send_json_success( array(
				'message' => __( 'Screen successfully assigned to running tournament', 'poker-tournament-import' )
			) );
		} else {
			wp_send_json_error( __( 'No running tournaments found', 'poker-tournament-import' ) );
		}
	}
}